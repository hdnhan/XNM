#include "stokes.h"

extern Info  info;


/* build right hand side vector and set boundary conds. */
void rhside_2d(pMesh mesh,pSol sol,double *F) {
  pTria    pt;
	pPoint   ppt;
	pCl      pcl;
  double   *a,*b,*c,aire,d1,d2,kappa,len,n[3],nu,rho;
  int      k,ig;
  char     i,off;

  if ( abs(info.imprim) > 5 )  fprintf(stdout,"     Gravity and body forces\n");

  /* gravity as external force */
  if ( info.load && (1<<0) ) {
    off = info.typ < P2P1 ? 0 : 3;
    for (k=1; k<=mesh->nt; k++) {
      pt = &mesh->tria[k];
      if ( !pt->v[0] )  continue;
      getMat(sol,pt->ref,&nu,&rho);

      a = &mesh->point[pt->v[0]].c[0];
      b = &mesh->point[pt->v[1]].c[0];
      c = &mesh->point[pt->v[2]].c[0];
      aire = area_2d(a,b,c);
      d1   = rho * aire / 3.0;
      d2   = rho * aire * 9.0 / 20.0;
      for (i=0; i<3; i++) {
        ig = 2*(pt->v[i+off]-1);
        F[ig+0] += d1 * info.gr[0];
        F[ig+1] += d1 * info.gr[1];
      }
      if ( info.typ == P1bP1 ) {
        /* bubble part */
        ig = 2*(pt->v[3]-1);
        F[ig+0] += d2 * info.gr[0];
        F[ig+1] += d2 * info.gr[1];
      }
    }
  }

  /* surface tension (method 1) */
  if ( sol->cltyp & ST_SuTe ) {
	  for (k=1; k<=mesh->np; k++) {
      ppt = &mesh->point[k];
      pcl = getCl(sol,ppt->ref,ST_SuTe);
      if ( !pcl )  continue;
      if ( pcl->typ == Tension ) {
        kappa = kappa_2d(mesh,k,n,&len);
        F[2*(k-1)+0] -= -0.5 * pcl->u[0] * len * kappa * n[0];
        F[2*(k-1)+1] -= -0.5 * pcl->u[0] * len * kappa * n[1];
      }
    }
	}
}

void taylorgreen(pPoint ppt,double *vp,double t) {
  double   x,y;

  x = ppt->c[0];
  y = ppt->c[1];
  if ( ppt->ref == 1 || ppt->ref == 3 ) {
    vp[0] = 0.0;
    vp[1] = sin(x)*exp(-2*t);
  }
  else if ( ppt->ref == 2 || ppt->ref == 4 ) {
    vp[0] = -sin(y)*exp(-2*t);
    vp[1] = 0.0;
  }
}


/* set Dirichlet boundary conditions using TGV */
void rhsTGV_2d(pMesh mesh,pSol sol,double *F) {
  pPoint   ppt;
  pEdge    pa;
  pCl      pcl;
  double  *vp,*va,pp[2],kappa,len,n[3];
  int      k,ig;
  char     i,idof;

  /* boundary conditions */
  if ( (sol->cltyp & ST_Ver) && (info.typ < P2P1) ) {
    for (k=1; k<=mesh->np; k++) {
      ppt = &mesh->point[k];
      pcl = getCl(sol,ppt->ref,ST_Ver);
			ig  = 2*(k-1);
      /* Dirichlet */
      if ( pcl && pcl->typ == Dirichlet ) {
        /* pointer to BC */
        if ( pcl->att == 'p' ) {
          //printf("boundary condition at%E\n:", sol->time);
          stokesCL(ppt,pp,sol->time);
          F[ig+0] = ST_TGV * pp[0];
          F[ig+1] = ST_TGV * pp[1];
        }
        else {
          vp = pcl->att == 'f' ? &sol->bc[ig] : &pcl->u[0];
          F[ig+0] = ST_TGV * vp[0];
          F[ig+1] = ST_TGV * vp[1];
        }
      }
			/* slip condition */
			else if ( pcl && pcl->typ == Slip ) {
			  F[ig+0] = ST_TGV * 0.0;
			  //F[ig+1] = ST_TGV * 0.0;  
			}
    }
  }

  if ( sol->cltyp & ST_Edg ) {
    idof = info.typ < P2P1 ? 2 : 3;
    for (k=1; k<=mesh->nai; k++) {
      pa = &mesh->edge[k];
      pcl = getCl(sol,pa->ref,ST_Edg);
      if ((pa->ref == 3)&& pcl && pcl->typ == Dirichlet ) {
        va = pcl->att == 'f' ? &sol->bc[2*(k-1)] : &pcl->u[0];
        for (i=0; i<idof; i++) {
          ig  = 2*(pa->v[i]-1);
          F[ig+0] = ST_TGV * va[0];
          F[ig+1] = ST_TGV * va[1];
        }
      }
    } 
    for (k=1; k<=mesh->nai; k++) {
      pa = &mesh->edge[k];
      pcl = getCl(sol,pa->ref,ST_Edg);
      if ((pa->ref == 1)||(pa->ref == 2)||(pa->ref == 4)&& pcl && pcl->typ == Dirichlet ) {
        va = pcl->att == 'f' ? &sol->bc[2*(k-1)] : &pcl->u[0];
        for (i=0; i<idof; i++) {
          ig  = 2*(pa->v[i]-1);
          F[ig+0] = ST_TGV * va[0];
          F[ig+1] = ST_TGV * va[1];
        }
      }
    }
  }
}
/* update RHS for unsteady NS: F^n = F + 1/dt u^n(X^n(x)) */
void rhsupd_2d(pMesh mesh,pSol sol, double *Fk) {
  pTria    pt;
  double  *a,*b,*c,aire,d1,d2,idt,rho,nu;
  int      k,ig,off;
  char     i,idof;
  static char ndof[4] = {3,4,3,6};
  
  idt  = 1.0 / info.dt;
  idof = ndof[info.typ];
    
  off = info.typ < P2P1 ? 0 : 3;
  for (k=1; k<=mesh->nt; k++) {
    pt = &mesh->tria[k];
    if ( !pt->v[0] )  continue;
    if ( !getMat(sol,pt->ref,&nu,&rho) )  continue;
    /* measure */
    a = &mesh->point[pt->v[0]].c[0];
    b = &mesh->point[pt->v[1]].c[0];
    c = &mesh->point[pt->v[2]].c[0];
    aire = area_2d(a,b,c);
    d1 = idt * rho * aire / 3.0;
    d2 = idt * rho * aire * 9.0 / 20.0;
    for (i=0; i<3; i++) {
      ig = 2*(pt->v[i+off]-1);
      Fk[ig+0] += d1*sol->u[ig+0];
      Fk[ig+1] += d1*sol->u[ig+1];
    }
    if ( info.typ == P1bP1 ) {
      /* bubble part */
      ig = 2*(pt->v[3]-1);
      Fk[ig+0] += d2*sol->u[ig+0];
      Fk[ig+1] += d2*sol->u[ig+1];
    }
  }
}

/* set TGV to diagonal coefficient when Dirichlet */
static void setTGV_2d(pMesh mesh,pSol sol,pCsr A) {
  pCl      pcl;
  pEdge    pa;
  pPoint   ppt;
  pTria    pt;
  double   *a,*b,*c,val,kappa,len,vol,ivo,x[3],y[3],n[3],penal;
  int      k,ig;
  char     i,idof;

  /* at vertices */
  if ( (sol->cltyp & ST_Ver) && (info.typ < P2P1) ) {
    for (k=1; k<=mesh->np; k++) {
      ppt = &mesh->point[k];
      pcl = getCl(sol,ppt->ref,ST_Ver);
			ig = 2*(k-1);
      if ( pcl && pcl->typ == Dirichlet ) {
        csrSet(A,ig+0,ig+0,ST_TGV);
        csrSet(A,ig+1,ig+1,ST_TGV);
      }
      /* set free-Slip boundary condition (only u.n = 0 on \Sigma_S because \alpha=0)*/
			else if ( pcl && pcl->typ == Slip ) {
				csrSet(A,ig+0,ig+0,ST_TGV);
				//csrSet(A,ig+1,ig+1,ST_TGV);
			}
	  }
  }
  
  /* at edge nodes */
  if ( sol->cltyp & ST_Edg ) {
    idof = info.typ < P2P1 ? 2 : 3;
    for (k=1; k<=mesh->nai; k++) {
      pa = &mesh->edge[k];
      pcl = getCl(sol,pa->ref,ST_Edg);
      //if ( pcl && pcl->typ == Dirichlet ) {
	    if ( pcl && pcl->typ == Dirichlet ) {
        for (i=0; i<idof; i++) {
          ig = 2*(pa->v[i]-1);
          csrSet(A,ig+0,ig+0,ST_TGV);
          csrSet(A,ig+1,ig+1,ST_TGV);
        }
      }
      
      
      /*
      if ( pcl && pcl->typ == Slip ) {
        p0 = &mesh-point[pa->v[0]];
        p1 = &mesh-point[pa->v[1]];
        alpha = pcl->u[0];
        penal = 1/ST_EPS;
        lx = p1->c[0] - p0->c[0];
        ly = p1->c[1] - p0->c[1];
        len = sqrt(lx*lx+ly*ly);
        for (i=0; i<idof; i++) {
          n = normal_2d(mesh,pa->v[i],*n);
          t[0] = n[1]; t[1] = -n[0];
          ig = 2*(pa->v[i]-1);
          val = 0.5 * len * (alpha*t[0]*t[0]+penal*n[0]*n[0]); 
          csrSet(A,ig+0,ig+0,val);
          val = 0.5 * len * (alpha*t[0]*t[1]+penal*n[0]*n[1]);
        	csrPut(A,ig+0,ig+1,val);
        	csrPut(A,ig+1,ig+0,val);
        	val = 0.5 * len * (alpha*t[1]*t[1]+penal*n[1]*n[1]);
        	csrPut(A,ig+1,ig+1,val);
        }
      }
      */
    }  
  }
      
  
  /* loop on triangles for condition of symmetry */    
  for (k=1; k<=mesh->nt; k++) {
    pt = &mesh->tria[k];
    if ( !pt->v[0] )  continue;
    /* measure of K */
    a  = &mesh->point[pt->v[0]].c[0]; 
    b  = &mesh->point[pt->v[1]].c[0]; 
    c  = &mesh->point[pt->v[2]].c[0]; 
    x[0] = c[0] - b[0];  y[0] = b[1] - c[1];
    x[1] = a[0] - c[0];  y[1] = c[1] - a[1];
    x[2] = b[0] - a[0];  y[2] = a[1] - b[1];
    vol  = 0.5 * (x[2]*y[1] - y[2]*x[1]);
    if ( vol < ST_EPSA )  vol = ST_EPSA;
    ivo = 1.0/4*vol;
    for (i=0; i<3; i++) {
      ppt = &mesh->point[pt->v[i]];
      pcl = getCl(sol,ppt->ref,ST_Ver);  
      if ( pcl && pcl->typ == Symmetry ) {
    	  ig = 2*(pt->v[i]-1);
        val = 1.e30 * y[i]*y[i];
        csrPut(A,ig+1,ig+1,val);
      }
    }
  }
}

/* local stiffness matrix */
static int matAe_P1(double *a,double *b,double *c,double nu, double rho, double Ae[12][12]) {
  double   m[2][2],mm[4][8],Dp[2][4],ph[4][8];
  double   det,idet,area,idt;
  char     i,j,p,s;
  static double w[3] = { 1./3., 1./3., 1./3.};
  static double q[3][2] = { {1./6.,1./6.}, {1./6.,2./3.}, {2./3.,1./6.} };

  if ( info.dt > 0 )  
    idt = 1.0 / info.dt;
  else
    idt = 1.0;

  Dp[0][0] = 1.0;  Dp[0][1] = 0.0;  Dp[0][2] = -1.0;  
  Dp[1][0] = 0.0;  Dp[1][1] = 1.0;  Dp[1][2] = -1.0;

  /* measure of K=(a,b,c) */
  //ux = b[0] - a[0];
  //uy = b[1] - a[1];
  //vx = c[0] - a[0];
  //vy = c[1] - a[1];
  //dd = 0.5 * (ux*vy - uy*vx);
	
	//det  = (b[1]-c[1])*(a[0]-c[0])-(a[1]-c[1])*(b[0]-c[0]);(old)
	det = (b[0] - a[0])*(c[1] - a[1])-(b[1] - a[1])*(c[0] - a[0]);
	if ( det < ST_EPSA )  return(0);

  /* m = tBT^-1 */
	idet = 1.0 / det;
	m[0][0] = idet*(b[1]-c[1]);    m[0][1] = idet*(c[1]-a[1]);
	m[1][0] = idet*(c[0]-b[0]);    m[1][1] = idet*(a[0]-c[0]);

  /* Ae:loop on 3 quadrature points */
  memset(Ae,0,12*12*sizeof(double));
  for (p=0; p<3; p++) {
	  /* Dp for bubble */
    Dp[0][3] = 27.0 * q[p][1]*(1.0-2.0*q[p][0]-q[p][1]); 
    Dp[1][3] = 27.0 * q[p][0]*(1.0-q[p][0]-2.0*q[p][1]);

    /* unsteady case */
    if ( info.dt > 0 ) {
      /* ph_basis function */
      memset(ph,0,32*sizeof(double));
      ph[0][0] = ph[2][4] = q[p][0];  
      ph[0][1] = ph[2][5] = q[p][1];  
      ph[0][2] = ph[2][6] = 1.0-q[p][0]-q[p][1];  
      ph[0][3] = ph[2][7] = 27.0 * q[p][0]*q[p][1]*(1.0-q[p][0]-q[p][1]);   
    }
    /* mm = (tBt^-1) Dp */
    memset(mm,0,4*8*sizeof(double));
    for (i=0; i<2; i++) {
      for (j=0; j<4; j++) {
        for (s=0; s<2; s++)
          mm[i][j]  += m[i][s] * Dp[s][j];
        mm[i+2][j+4] = mm[i][j];
      }
    }
	  /* Ae = area*wp*tmm N mm */
	  area = 0.5 * w[p] * det;
	  for (i=0; i<8; i++) {
	    for (j=i; j<8; j++) {
	      for (s=0; s<4; s++) {
	        Ae[i][j] += area * nu * mm[s][i] * mm[s][j];
	         if ( info.dt > 0)
	          Ae[i][j] += area * rho * idt * ph[s][i] * ph[s][j];
        }
	    }
	  }
  }
  return(1);
}

/* local stiffness matrix */
static int matAe_P2(double *a,double *b,double *c,double nu, double rho, double Ae[12][12]) {
  double   m[2][2],mi[2][2],mm[4][12],Dp[2][6],ph[4][12];
  double   det,det1,idet,area,idt,x[6],y[6];
  char     i,j,p,s;
  static double w[3] = { 1./3., 1./3., 1./3.};
  static double q[3][2] = { {1./6.,1./6.}, {1./6.,2./3.}, {2./3.,1./6.} };

  if ( info.dt > 0 )  
    idt = 1.0 / info.dt;
  else
    idt = 1.0;
  
  //measure of K=(a,b,c)
 	//det1  = (b[1]-c[1])*(a[0]-c[0])-(a[1]-c[1])*(b[0]-c[0]);
  det1  = area_2d(a,b,c);
	if ( det1 < ST_EPSA )  return(0);
  // m = tBT^-1
  /*
	idet = 1.0 / det;
	m[0][0] = idet*(b[1]-c[1]);    m[0][1] = idet*(c[1]-a[1]);
	m[1][0] = idet*(c[0]-b[0]);    m[1][1] = idet*(a[0]-c[0]);
 */
 
	x[0]=a[0]; x[1]=b[0]; x[2]=c[0]; x[3]=(a[0]+b[0])/2; x[4]=(b[0]+c[0])/2; x[5]=(c[0]+a[0])/2;
	y[0]=a[1]; y[1]=b[1]; y[2]=c[1]; y[3]=(a[1]+b[1])/2; y[4]=(b[1]+c[1])/2; y[5]=(c[1]+a[1])/2;
  /* Ae:loop on 3 quadrature points */
  memset(Ae,0,12*12*sizeof(double));
  for (p=0; p<3; p++) {
	  /* Dp for P2 */
	  /*
	  Dp[0][0] = 4*q[p][0]-1;              Dp[0][1] = 0;            
	  Dp[0][2] = 4*(q[p][0]+q[p][1])-3;    Dp[0][3] = 4*q[p][1];
    Dp[0][4] = -4*q[p][1];               Dp[0][5] = 4*(1-2*q[p][0]-q[p][1]);  
    Dp[1][0] = 0;                        Dp[1][1] = 4*q[p][1]-1;
    Dp[1][2] = 4*(q[p][0]+q[p][1])-3;    Dp[1][3] = 4*q[p][0];
    Dp[1][4] = 4*(1-q[p][0]-2*q[p][1]);  Dp[1][5] = -4*q[p][0];   
    */
  
     //new            
	    Dp[0][0] = 4*(q[p][0]+q[p][1])-3;    Dp[0][1] = 4*q[p][0]-1;            
		  Dp[0][2] = 0;                        Dp[0][3] = 4*(1-2*q[p][0]-q[p][1]);
	    Dp[0][4] = 4*q[p][1];                Dp[0][5] =  -4*q[p][1];
	    Dp[1][0] = 4*(q[p][0]+q[p][1])-3;    Dp[1][1] = 0;
	    Dp[1][2] = 4*q[p][1]-1;              Dp[1][3] = -4*q[p][0];
	    Dp[1][4] = 4*q[p][0];                Dp[1][5] = 4*(1-q[p][0]-2*q[p][1]);
	 
	  m[0][0]  = m[1][0] = m[0][1] = m[1][1] = 0.;
		for (i=0; i<6; i++) {
			m[0][0] += x[i]*Dp[0][i];          m[0][1]  +=x[i]*Dp[1][i];
			m[1][0] += y[i]*Dp[0][i];          
			m[1][1]  +=y[i]*Dp[1][i];
    }
		det = m[0][0]*m[1][1]-m[0][1]*m[1][0];
		if ( det < ST_EPSA )  return(0);
		mi[0][0] = m[1][1]/det;              mi[0][1] = -m[1][0]/det;
	 	mi[1][0] = -m[0][1]/det;             mi[1][1] = m[0][0]/det;
   
    /* unsteady case */
    if ( info.dt > 0 ) {
      /* ph_basis function */
      memset(ph,0,48*sizeof(double));
      /*
      ph[0][0] = ph[2][6]  = q[p][0]*(2.0*q[p][0]-1); 
      ph[0][1] = ph[2][7]  = q[p][1]*(2.0*q[p][1]-1);
      ph[0][2] = ph[2][8]  = (1.0-q[p][0]-q[p][1])*(1.0-2.0*q[p][0]-2.0*q[p][1]);
      ph[0][3] = ph[2][9]  = 4.0*q[p][0]*q[p][1];
      ph[0][4] = ph[2][10] = 4.0*q[p][1]*(1.0-q[p][0]-q[p][1]);
      ph[0][5] = ph[2][11] = 4.0*q[p][0]*(1.0-q[p][0]-q[p][1]);
      */
      //new
      ph[0][0] = ph[2][6]  = (1.0-q[p][0]-q[p][1])*(1.0-2.0*q[p][0]-2.0*q[p][1]); 
      ph[0][1] = ph[2][7]  = q[p][0]*(2.0*q[p][0]-1);
      ph[0][2] = ph[2][8]  = q[p][1]*(2.0*q[p][1]-1);
      ph[0][3] = ph[2][9]  = 4.0*q[p][0]*(1.0-q[p][0]-q[p][1]);
      ph[0][4] = ph[2][10] = 4.0*q[p][0]*q[p][1];
      ph[0][5] = ph[2][11] = 4.0*q[p][1]*(1.0-q[p][0]-q[p][1]);
    }
 
    /* mm = (tBt^-1) Dp */
    memset(mm,0,4*12*sizeof(double));
    for (i=0; i<2; i++) {
      for (j=0; j<6; j++) {
        for (s=0; s<2; s++)
          mm[i][j]  += mi[i][s]*Dp[s][j];
        mm[i+2][j+6] = mm[i][j];
      }
    }
	  /* Ae = area*wp*tmm N mm */
	  //area = 0.5 * w[p] * det1;
	  area = w[p] * det1;
	  for (i=0; i<12; i++) {
	    for (j=i; j<12; j++) {
	      for (s=0; s<4; s++) {
	        Ae[i][j] += area * nu * mm[s][i] * mm[s][j];
	        if ( info.dt > 0)
	          Ae[i][j] += area * rho *idt * ph[s][i] * ph[s][j];
	      }
	    }
	  }
  }
  return(1);
}

/* local mass matrix */
static int matBe_P1(double *a,double *b,double *c,double Be[6][6]) {
  double   Dp[2][4],m[2][2],ph[2][6],mm[2][4];
  double   det,idet,area;
  char     i,j,p,s;
  static double w[3] = { 1./3., 1./3., 1./3.};
  static double q[3][2] = { {1./6.,1./6.}, {1./6.,2./3.}, {2./3.,1./6.} };

  /* measure of K=(a,b,c) */
	det  = (b[1]-c[1])*(a[0]-c[0])-(a[1]-c[1])*(b[0]-c[0]);
	if ( det < ST_EPSA )  return(0);

  /* m = tBT^-1 */
	idet = 1.0 / det;
	m[0][0] = idet*(b[1]-c[1]);    m[0][1] = idet*(c[1]-a[1]);
	m[1][0] = idet*(c[0]-b[0]);    m[1][1] = idet*(a[0]-c[0]);

  Dp[0][0] = 1.0;  Dp[0][1] = 0.0;  Dp[0][2] = -1.0;  
  Dp[1][0] = 0.0;  Dp[1][1] = 1.0;  Dp[1][2] = -1.0;

  memset(Be,0,6*6*sizeof(double));
  for (p=0; p<3; p++) {
	  /* Dp for bubble */
    Dp[0][3] = 27.0 * q[p][1]*(1.0-2.0*q[p][0]-q[p][1]); 
    Dp[1][3] = 27.0 * q[p][0]*(1.0-q[p][0]-2.0*q[p][1]);

    /* ph_basis function */
    memset(ph,0,2*6*sizeof(double));
    ph[0][0] = ph[1][3] = -q[p][0];  
    ph[0][1] = ph[1][4] = -q[p][1];  
    ph[0][2] = ph[1][5] =  q[p][0]+q[p][1]-1.0;  

    /* mm = (tBt^-1) Dp */
    memset(mm,0,2*4*sizeof(double));
    for (i=0; i<2; i++) {
      for (j=0; j<4; j++) {
        for (s=0; s<2; s++)
          mm[i][j] += m[i][s]*Dp[s][j];
      }
    }
	  /* Be = area*wp*tmm N mm */
	  area = 0.5 * w[p] * det;
	  for (i=0; i<6; i++) { //6=d x P1
	    for (j=0; j<4; j++) { //4=idof
	      for (s=0; s<2; s++)
	        Be[i][j] += area * ph[s][i] * mm[s][j];
	    }
	  }
  }
  return(1);
}

/* local mass matrix */
static int matBe_P2(double *a,double *b,double *c,double Be[6][6]) {
  double   m[2][2],mi[2][2],mm[2][6],Dp[2][6],ph[2][6];
  double   det,det1,idet,area,x[6],y[6];
  char     i,j,p,s;
  static double w[3] = { 1./3., 1./3., 1./3.};
  static double q[3][2] = { {1./6.,1./6.}, {1./6.,2./3.}, {2./3.,1./6.} };

  
  // measure of K=(a,b,c)
	//det1  = (b[1]-c[1])*(a[0]-c[0])-(a[1]-c[1])*(b[0]-c[0]);
	det1  = area_2d(a,b,c);
	if ( det1 < ST_EPSA )  return(0);
  
  /*
  // m = tBT^-1
	idet = 1.0 / det;
	m[0][0] = idet*(b[1]-c[1]);    m[0][1] = idet*(c[1]-a[1]);
	m[1][0] = idet*(c[0]-b[0]);    m[1][1] = idet*(a[0]-c[0]);
 */
  x[0]=a[0]; x[1]=b[0]; x[2]=c[0]; x[3]=(a[0]+b[0])/2; x[4]=(b[0]+c[0])/2; x[5]=(c[0]+a[0])/2;
	y[0]=a[1]; y[1]=b[1]; y[2]=c[1]; y[3]=(a[1]+b[1])/2; y[4]=(b[1]+c[1])/2; y[5]=(c[1]+a[1])/2;

  /* Be:loop on 3 quadrature points */
  memset(Be,0,6*6*sizeof(double));
  for (p=0; p<3; p++) {
	  /* Dp for P2 */
	  /*
	  Dp[0][0] = 4*q[p][0]-1;              Dp[0][1] = 0;            
	  Dp[0][2] = 4*(q[p][0]+q[p][1])-3;    Dp[0][3] = 4*q[p][1];
    Dp[0][4] = -4*q[p][1];               Dp[0][5] = 4*(1-2*q[p][0]-q[p][1]);  
    Dp[1][0] = 0;                        Dp[1][1] = 4*q[p][1]-1;
    Dp[1][2] = 4*(q[p][0]+q[p][1])-3;    Dp[1][3] = 4*q[p][0];
    Dp[1][4] = 4*(1-q[p][0]-2*q[p][1]);  Dp[1][5] = -4*q[p][0];               
    */
    //new
    Dp[0][0] = 4*(q[p][0]+q[p][1])-3;    Dp[0][1] = 4*q[p][0]-1;            
	  Dp[0][2] = 0;                        Dp[0][3] = 4*(1-2*q[p][0]-q[p][1]);
    Dp[0][4] = 4*q[p][1];                Dp[0][5] =  -4*q[p][1];
    Dp[1][0] = 4*(q[p][0]+q[p][1])-3;    Dp[1][1] = 0;
    Dp[1][2] = 4*q[p][1]-1;              Dp[1][3] = -4*q[p][0];
    Dp[1][4] = 4*q[p][0];                Dp[1][5] = 4*(1-q[p][0]-2*q[p][1]);

    m[0][0]  = m[1][0] = m[0][1] = m[1][1] = 0.;
		for (i=0; i<6; i++) {
			m[0][0] += x[i]*Dp[0][i];          m[0][1]  += x[i]*Dp[1][i];
			m[1][0] += y[i]*Dp[0][i];          
			m[1][1]  +=y[i]*Dp[1][i];
    }
		det = m[0][0]*m[1][1]-m[0][1]*m[1][0];
		if ( det < ST_EPSA )  return(0);
		mi[0][0] = m[1][1]/det;              mi[0][1] = -m[1][0]/det;
	 	mi[1][0] = -m[0][1]/det;             mi[1][1] = m[0][0]/det;
	
    /* P1 ph_basis function */
    
    memset(ph,0,2*6*sizeof(double));
    /*
    ph[0][0] = ph[1][3] = -q[p][0];  
    ph[0][1] = ph[1][4] = -q[p][1];  
    ph[0][2] = ph[1][5] =  q[p][0]+q[p][1]-1.0;
    */

    //new
   	 ph[0][0] = ph[1][3] = q[p][0]+q[p][1]-1.0;  
	   ph[0][1] = ph[1][4] = -q[p][0];  
	   ph[0][2] = ph[1][5] =  -q[p][1];
	
    /* mm = (tBt^-1) Dp */
    memset(mm,0,2*6*sizeof(double));
    for (i=0; i<2; i++) {
      for (j=0; j<6; j++) {
        for (s=0; s<2; s++)
          mm[i][j] += mi[i][s]*Dp[s][j];
      }
    }
	  /* Be = area*wp*tmm N mm */
	  //area = 0.5 * det1 * w[p];
	  area = det1 * w[p];
	  for (i=0; i<6; i++) {
	    for (j=0; j<6; j++) { //6=idof
	      for (s=0; s<2; s++)
	        Be[i][j] += area * ph[s][i] * mm[s][j];
	    }
	  }
  }
  return(1);
}

/* local stiffness matrix */
static int matMe_P1(double *a,double *b,double *c,double nu, double rho, double Me[15][15]) {
  double   m[2][2],mm[5][11],nn[5][11],N[5][5],Dp[2][4],ph[5][11];
  double   det,idet,area,idt,eps;
  char     i,j,p,s;
  static double w[3] = { 1./3., 1./3., 1./3.};
  static double q[3][2] = { {1./6.,1./6.}, {1./6.,2./3.}, {2./3.,1./6.} };

  if ( info.dt > 0 )  
    idt = 1.0 / info.dt;
  else
    idt = 1.0;

  Dp[0][0] = 1.0;  Dp[0][1] = 0.0;  Dp[0][2] = -1.0;  
  Dp[1][0] = 0.0;  Dp[1][1] = 1.0;  Dp[1][2] = -1.0;

  /* measure of K=(a,b,c) */
	det  = (b[1]-c[1])*(a[0]-c[0])-(a[1]-c[1])*(b[0]-c[0]);
	if ( det < ST_EPSA )  return(0);

  /* m = tBT^-1 */
	idet = 1.0 / det;
	m[0][0] = idet*(b[1]-c[1]);    m[0][1] = idet*(c[1]-a[1]);
	m[1][0] = idet*(c[0]-b[0]);    m[1][1] = idet*(a[0]-c[0]);

  memset(N,0,5*5*sizeof(double));
  ///eps = info.hmin * 0.001;
	eps = 1e-4;
  for (i=0; i<4; i++)  N[i][i] = nu;
	N[0][4] = N[4][0] = N[3][4] = N[4][3] = -1.0;
	N[4][4] = eps;

  /* Me: loop on 3 quadrature points */
  memset(Me,0,15*15*sizeof(double));
  for (p=0; p<3; p++) {
	  /* Dp for bubble */
    Dp[0][3] = 27.0 * q[p][1]*(1.0-2.0*q[p][0]-q[p][1]); 
    Dp[1][3] = 27.0 * q[p][0]*(1.0-q[p][0]-2.0*q[p][1]);

    /* unsteady case */
    if ( info.dt > 0 ) {
      /* ph_basis function */
      memset(ph,0,5*11*sizeof(double));
      ph[0][0] = ph[2][4] = q[p][0];  
      ph[0][1] = ph[2][5] = q[p][1];  
      ph[0][2] = ph[2][6] = 1.0-q[p][0]-q[p][1];  
      ph[0][3] = ph[2][7] = 27.0 * q[p][0]*q[p][1]*(1.0-q[p][0]-q[p][1]);   
    }
    /* mm = (tBt^-1) Dp */
    memset(mm,0,5*11*sizeof(double));
    for (i=0; i<2; i++) {
      for (j=0; j<4; j++) {
        for (s=0; s<2; s++)
          mm[i][j]  += m[i][s] * Dp[s][j];
        mm[i+2][j+4] = mm[i][j];
      }
    }
		mm[4][8] = q[p][0];  mm[4][9] = q[p][1];  mm[4][10] = 1.0-q[p][0]-q[p][1];

    /* nn = N mm */
		for (i=0; i<5; i++) {
			for (j=0; j<11; j++) {
				nn[i][j] = 0.0;
				for (s=0; s<5; s++)
					nn[i][j] += N[i][s] * mm[s][j];
			}
		}

	  /* Me = area*wp*tmm N mm */
	  area = 0.5 * w[p] * det;
	  for (i=0; i<11; i++) {
	    for (j=i; j<11; j++) {
	      for (s=0; s<5; s++) {
	        Me[i][j] += area * mm[s][i] * nn[s][j];
	        if ( info.dt > 0)
	          Me[i][j] += area * rho * idt * ph[s][i] * ph[s][j];
        }
	    }
	  }
  }
  return(1);
}

static int matMe_P2(double *a,double *b,double *c,double nu, double rho, double Me[15][15]) {
  double   m[2][2],mi[2][2],mm[5][15],nn[5][15],N[5][5],Dp[2][6],ph[5][15];
  double   det,idet,det1,area,idt,eps,x[6],y[6];
  char     i,j,p,s;
  static double w[3] = { 1./3., 1./3., 1./3.};
  static double q[3][2] = { {1./6.,1./6.}, {1./6.,2./3.}, {2./3.,1./6.} };

  if ( info.dt > 0 )  
    idt = 1.0 / info.dt;
  else
    idt = 1.0;

  // measure of K=(a,b,c)
	det  = (b[1]-c[1])*(a[0]-c[0])-(a[1]-c[1])*(b[0]-c[0]);
	if ( det < ST_EPSA )  return(0);
  /*
  // m = tBT^-1
	idet = 1.0 / det;
	m[0][0] = idet*(b[1]-c[1]);    m[0][1] = idet*(c[1]-a[1]);
	m[1][0] = idet*(c[0]-b[0]);    m[1][1] = idet*(a[0]-c[0]);
  */
  memset(N,0,5*5*sizeof(double));
  //eps = info.hmin * 0.001;
	eps = 1.0e-4;
  for (i=0; i<4; i++)  N[i][i] = nu;
	N[0][4] = N[4][0] = N[3][4] = N[4][3] = -1.0;
	N[4][4] = eps;

  x[0]=a[0]; x[1]=b[0]; x[2]=c[0]; x[3]=(a[0]+b[0])/2; x[4]=(b[0]+c[0])/2; x[5]=(c[0]+a[0])/2;
	y[0]=a[1]; y[1]=b[1]; y[2]=c[1]; y[3]=(a[1]+b[1])/2; y[4]=(b[1]+c[1])/2; y[5]=(c[1]+a[1])/2;
	
  /* Me: loop on 3 quadrature points */
  memset(Me,0,15*15*sizeof(double));
  for (p=0; p<3; p++) {
	  /* Dp for P2 */
    Dp[0][0] = 4*q[p][0]-1;              Dp[0][1] = 0;            
	  Dp[0][2] = 4*(q[p][0]+q[p][1])-3;    Dp[0][3] = 4*q[p][1];
    Dp[0][4] = -4*q[p][1];               Dp[0][5] = 4*(1-2*q[p][0]-q[p][1]);  
    Dp[1][0] = 0;                        Dp[1][1] = 4*q[p][1]-1;
    Dp[1][2] = 4*(q[p][0]+q[p][1])-3;    Dp[1][3] = 4*q[p][0];
    Dp[1][4] = 4*(1-q[p][0]-2*q[p][1]);  Dp[1][5] = -4*q[p][0];               
    
    /* unsteady case */
    if ( info.dt > 0 ) {
      /* ph_basis function */
      memset(ph,0,48*sizeof(double));
      ph[0][0] = ph[2][6]  = q[p][0]*(2.0*q[p][0]-1); 
      ph[0][1] = ph[2][7]  = q[p][1]*(2.0*q[p][1]-1);
      ph[0][2] = ph[2][8]  = (1.0-q[p][0]-q[p][1])*(1.0-2.0*q[p][0]-2.0*q[p][1]);
      ph[0][3] = ph[2][9]  = 4.0*q[p][0]*q[p][1];
      ph[0][4] = ph[2][10] = 4.0*q[p][1]*(1.0-q[p][0]-q[p][1]);
      ph[0][5] = ph[2][11] = 4.0*q[p][0]*(1.0-q[p][0]-q[p][1]);
    }
    /* mm = (tBt^-1) Dp */
    m[0][0]  = m[1][0] = m[0][1] = m[1][1] = 0.;
		for (i=0; i<6; i++) {
			m[0][0] += x[i]*Dp[0][i];          m[0][1]  +=y[i]*Dp[0][i];//x[i]*Dp[1][i];
			m[1][0] += x[i]*Dp[1][i];//y[i]*Dp[0][i];          
			m[1][1]  +=y[i]*Dp[1][i];
    }
		det1 = m[0][0]*m[1][1]-m[0][1]*m[1][0];
		if ( det1 < ST_EPSA )  return(0);
		mi[0][0] = m[1][1]/det1;              mi[0][1] = -m[1][0]/det1;
	 	mi[1][0] = -m[0][1]/det1;             mi[1][1] = m[0][0]/det1;
		
    memset(mm,0,5*15*sizeof(double));
    for (i=0; i<2; i++) {
      for (j=0; j<6; j++) {
        for (s=0; s<2; s++)
          //mm[i][j]  += m[i][s] * Dp[s][j];
        mm[i][j]  += mi[i][s] * Dp[s][j];
        mm[i+2][j+6] = mm[i][j];
      }
    }
		mm[4][12] = q[p][0];  mm[4][13] = q[p][1];  mm[4][14] = 1.0-q[p][0]-q[p][1];

    /* nn = N mm */
		for (i=0; i<5; i++) {
			for (j=0; j<15; j++) {
				nn[i][j] = 0.0;
				for (s=0; s<5; s++)
					nn[i][j] += N[i][s] * mm[s][j];
			}
		}

	  /* Me = area*wp*tmm N mm */
	  area = 0.5 * w[p] * det;
	  for (i=0; i<15; i++) {
	    for (j=i; j<15; j++) {
	      for (s=0; s<5; s++) {
	        Me[i][j] += area * mm[s][i] * nn[s][j];
	        if ( info.dt > 0 )
	          Me[i][j] += area * rho * idt * ph[s][i] * ph[s][j];
        }
	    }
	  }
  }
  return(1);
}

/* stiffness+mass matrix function */
static int (*matAe)(double *a,double *b,double *c,double nu, double rho, double Ae[12][12]);
static int (*matMe)(double *a,double *b,double *c,double nu, double rho, double Me[15][15]);
static int (*matBe)(double *a,double *b,double *c,double Be[6][6]);

/* build stiffness and mass matrices */
void matAB_2d(pMesh mesh,pSol sol,pCsr A,pCsr B) {
  pTria    pt;
  double  *a,*b,*c,Ae[12][12],Be[6][6];
  double   rho,nu,mas,vol;
  int      k,nr,nc,nbe,ig,jg;
  char     i,j,idof;
  static int ndof[4] = {3,4,3,6};
	FILE     *mass;

  /* memory allocation */
  if ( info.typ < P2P1 ) {
    nr  = info.typ == P1P1 ? mesh->dim*mesh->np : mesh->dim*(mesh->np+mesh->nt);
    nbe = 13*mesh->nt;
    matAe = matAe_P1;
    matBe = matBe_P1;
  }
  else {
    nr  = mesh->dim*(mesh->np+mesh->na);
    nbe = 28*mesh->nt;
    matAe = matAe_P2;
    matBe = matBe_P2;
  }
printf("A.nbe %d\n",nbe);
  csrAlloc(A,nr,nr,nbe,CS_UT+CS_SYM);
  assert(A);

  if ( info.typ < P2P1 ) {
    nr  = mesh->np;
    nc  = info.typ == P1P1 ? mesh->dim*mesh->np : mesh->dim*(mesh->np+mesh->nt);
    nbe = info.typ == P1P1 ? 8*mesh->nt : 14*mesh->nt;
  }
  else {
    nr  = mesh->np;
    nc  = mesh->dim*(mesh->np + mesh->na);
    nbe = 22*mesh->nt;
  }
printf("B.nbe %d\n",nbe);
  csrAlloc(B,nr,nc,nbe,0);
  assert(B);

  /* matrix assembly */
  idof = ndof[info.typ];
	mas = 0.0;
	mass = fopen("masse.txt","a");
  for (k=1; k<=mesh->nt; k++) {
    pt = &mesh->tria[k];
    if ( !pt->v[0] )  continue;

    /* viscosity+density */
    if ( !getMat(sol,pt->ref,&nu,&rho) )  continue;
    /*if ( info.rhs )  nu = ST_NU - nu;*/
 
    a = &mesh->point[pt->v[0]].c[0]; 
    b = &mesh->point[pt->v[1]].c[0]; 
    c = &mesh->point[pt->v[2]].c[0]; 
    
    vol = area_2d(a,b,c);
    if (pt->ref==3) mas += vol;

    /* local stiffness matrix A */
    if ( !matAe(a,b,c,nu,rho,Ae) )  continue;

    /* global stiffness matrix */
    /*
	  for (i=0; i<2*idof; i++) {
	    ig = pt->v[i % idof];
	    ig = 2*(ig-1) + (i / idof);
	    for (j=i; j<2*idof; j++) {
	      if ( fabs(Ae[i][j]) < ST_EPSA )  continue;
	      jg = pt->v[j % idof];
	      jg = 2*(jg-1) + (j / idof);
	      if ( ig < jg )
	        csrPut(A,ig,jg,Ae[i][j]);
	      else
	        csrPut(A,jg,ig,Ae[i][j]);
	    }
	  }
    */
    for (i=0; i<2*idof; i++) {
	    //ig = pt->v[i % idof];
	    //ig = 2*(ig-1) + (i / idof);
	    for (j=i; j<2*idof; j++) {
		    ig = pt->v[i % idof];
		    ig = 2*(ig-1) + (i / idof);
	      if ( fabs(Ae[i][j]) < ST_EPSA )  continue;
	      jg = pt->v[j % idof];
	      jg = 2*(jg-1) + (j / idof);
	      if ( jg <= ig )
	        csrPut(A,jg,ig,Ae[i][j]);
	      else
	        csrPut(A,ig,jg,Ae[i][j]);
	    }
	  }
	  /* local mass matrix B */
    if ( !matBe(a,b,c,Be) )  continue;

    /* global mass matrix B */
	  for (i=0; i<6; i++) { //for both P2P1 and P1bP1
	    ig = pt->v[i % 3]-1;
	    for (j=0; j<idof; j++) {
	      if ( fabs(Be[i][j]) < ST_EPSA )  continue;
	      jg = 2*(pt->v[j]-1) + (i / 3);
        csrPut(B,ig,jg,Be[i][j]);
      }
    }
	}
  setTGV_2d(mesh,sol,A);
  csrPack(A);
  csrPack(B);
  if ( abs(info.imprim) > 4 || info.ddebug ) {
    fprintf(stdout,"     A: %6d x %6d  nze %8d,  sparsity %7.4f%%\n",A->nr,A->nc,A->nbe,100.0*A->nbe/A->nr/A->nc);
    fprintf(stdout,"     B: %6d x %6d  nze %8d,  sparsity %7.4f%%\n",B->nr,B->nc,B->nbe,100.0*B->nbe/B->nr/B->nc);
printf("A.nbe / ne = %d   / np = %d\n",A->nbe/mesh->nt,A->nbe/mesh->np);
printf("B.nbe / ne = %d   / np = %d\n",B->nbe/mesh->nt,B->nbe/mesh->np);
  }
  fprintf(mass,"%E\n",mas);
	fclose(mass);
}

/* build stiffness+mass matrix */
void matM_2d(pMesh mesh,pSol sol,pCsr M,pCsr B) {
  pTria    pt;
  double  *a,*b,*c,Me[15][15];
  double   rho,nu;
  int      k,nra,nrb,nbe,ig,jg;
  char     i,j,idof;
  static int ndof[4] = {3,4,3,6};

  /* memory allocation */
  if ( info.typ < P2P1 ) {
    nra = info.typ == P1P1 ? mesh->dim*mesh->np : mesh->dim*(mesh->np+mesh->nt);
		nrb = mesh->np;
    nbe = 54*mesh->np;
    matMe = matMe_P1;
  }
  else {
    nra = mesh->dim*(mesh->np+mesh->na);
		nrb = mesh->np;
    nbe = 40*(mesh->np + mesh->na);
    matMe = matMe_P2;
  }
	printf("M.nbe = %d\n",nbe);
  csrAlloc(M,nra+nrb,nra+nrb,nbe,CS_UT+CS_SYM);
  assert(M);

  /* matrix assembly */
  idof = ndof[info.typ];
  for (k=1; k<=mesh->nt; k++) {
    pt = &mesh->tria[k];
    if ( !pt->v[0] )  continue;

    /* viscosity+density */
    if ( !getMat(sol,pt->ref,&nu,&rho) )  continue;
    /*if ( info.rhs )  nu = ST_NU - nu;*/

    a  = &mesh->point[pt->v[0]].c[0]; 
    b  = &mesh->point[pt->v[1]].c[0]; 
    c  = &mesh->point[pt->v[2]].c[0]; 

    /* local stiffness matrix A */
    if ( !matMe(a,b,c,nu,rho,Me) )  continue;

    /* global stiffness matrix */
	  for (i=0; i<2*idof; i++) {
	    ig = pt->v[i % idof];
	    ig = 2*(ig-1) + (i / idof);
	    for (j=i; j<2*idof; j++) {
	      if ( fabs(Me[i][j]) < ST_EPSA )  continue;
	      jg = pt->v[j % idof];
	      jg = 2*(jg-1) + (j / idof);
	      if ( ig < jg )
	        csrPut(M,ig,jg,Me[i][j]);
	      else
	        csrPut(M,jg,ig,Me[i][j]);
	    }
	  }
    /* global mass matrix B^t */
	  for (i=0; i<2*idof; i++) {
	    ig = 2*(pt->v[i % idof]-1) + (i / idof);
	    for (j=2*idof; j<2*idof+3; j++) {
	      if ( fabs(Me[i][j]) < ST_EPSA )  continue;
	      jg = nra + (pt->v[j % idof]-1);
        csrPut(M,ig,jg,Me[i][j]);
      }
    }
		/* penalization matrix S */
		for (i=2*idof; i<2*idof+3; i++) {
			ig = nra + pt->v[i % idof]-1;
			for (j=i; j<2*idof+3; j++) {
				jg = nra + pt->v[j % idof]-1;
				if ( ig < jg )
				  csrPut(M,ig,jg,Me[i][j]);
				else
					csrPut(M,jg,ig,Me[i][j]);
			}
		}
  }
  setTGV_2d(mesh,sol,M);
  csrPack(M);
  if ( abs(info.imprim) > 4 || info.ddebug )
    fprintf(stdout,"     M: %6d x %6d  nze %8d,  sparsity %7.4f%%\n",M->nr,M->nc,M->nbe,100.0*M->nbe/M->nr/M->nc);
}

/* compute bubble value */
void updbub_2d(pMesh mesh,double *u) {
  pTria    pt;
  double  *u0,*u1,*u2;
  int      k,ig;

  for (k=1; k<=mesh->nt; k++) {
    pt = &mesh->tria[k];
    if ( !pt->v[0] )  continue;

    u0 = &u[2*(pt->v[0]-1)];
    u1 = &u[2*(pt->v[1]-1)];
    u2 = &u[2*(pt->v[2]-1)];
    ig = 2*(mesh->np+k-1);
    u[ig+0] = 27.0 * u0[0] * u1[0] * u2[0];
    u[ig+1] = 27.0 * u0[1] * u1[1] * u2[1];
  }
}

