#include "stokes.h"

extern Info  info;


/* Schur algorithm ( A Bt ) ( U ) = ( A    0   )(U*); (U*)=(I A^-1Bt)(U)
                   ( B  0 ) ( P ) = ( B BA^-1Bt)(pd); (dp)=(0   I   )(P)
*/
int ST_Schur(pSol sol,pCsr A,pCsr B,double *F,double *er,int *ni) {
	double   *u,*p,*d,*z,*w,*r,*Ad,*ru,*rp,*uf,dp,*pd,*ul,alpha,beta,err,lerr,llerr;
	double    rm,rmp,rmn,rm1,rm2,rm1n,rm2n;
  int       i,it,lit,nit,lnit,llnit,ier;
  FILE     *out;

  u  = sol->u;
  p  = sol->p;

  /* compute ru = F-Au_0-Btp_0 and rp=-Bu_0 */
  ru = (double*)malloc(A->nr*sizeof(double));
  assert(ru);
  rp = (double*)malloc(B->nr*sizeof(double));
  assert(rp);
  csrAxpy(A,u,F,ru,-1.0,1.0);
  csrAtxpy(B,p,ru,ru,-1.0,1.0);
  csrAx(B,u,rp);
	for (i=0; i<B->nr; i++)  rp[i] = -rp[i];

  /*compute rmu:=rm1 and rmp:=rm2*/
  rm1 = rm2 = 0.0;
  for (i=0; i<A->nr; i++)  rm1 += ru[i] * ru[i];
  for (i=0; i<B->nr; i++)  rm2 += rp[i] * rp[i];

  uf = (double*)calloc(A->nr,sizeof(double));
  assert(uf);
  ul = (double*)calloc(A->nr,sizeof(double));
  assert(ul);
  d = (double*)malloc(B->nr*sizeof(double));
  assert(d);
  pd = (double*)malloc(B->nr*sizeof(double));
  assert(pd);
  memset(pd,0.,B->nr*sizeof(double));
  w  = (double*)calloc(A->nr,sizeof(double));
  assert(w);
  memset(w,0.,A->nr*sizeof(double));
  z  = (double*)calloc(A->nr,sizeof(double));
  assert(z);
  r = (double*)calloc(B->nr,sizeof(double));
  assert(r);
  Ad = (double*)malloc(B->nr*sizeof(double));
  assert(Ad);

  it  = 0;
  err = *er;
  nit = *ni;
  do {
    /*--- 1. solve for uf: A uf=ru */
    if ( abs(info.imprim) > 5 )  fprintf(stdout,"     Compute uf = A^-1.ru\n");

    /* accuracy is fundamental here to cvg */
    lerr = *er * ST_EPS;
    lnit = *ni;
    ier  = csrPrecondGrad(A,uf,ru,&lerr,&lnit,1);
    if ( ier < 1 ) {
      fprintf(stdout,"  ## Incomplete CG for A^-1.ru: err %E   nit %d\n",lerr,lnit);
			free(uf); free(ru); free(rp); free(ul); free(d); free(pd); free(w); free(z);
			free(Ad); 
      return(0);
    }

    /*--- 2. solve for pd: B A^-1 Bt pd = Bu_f-r_p */
    /* compute R0 = d - B.W = Bu_f-r_p - B*(A^-1*Bt*pd) */
    csrAxpy(B,uf,rp,r,1.0,-1.0);
    memcpy(d,r,B->nr*sizeof(double));
    rmp = 0.0;
    for (i=0; i<B->nr; i++)  rmp += r[i] * r[i];
    lit  = 0;
    ier  = 1;
		err  = *er * ST_TGV;
    lerr = err * err * rmp;
    lnit = *ni;
    rm   = rmp;

    if ( info.ddebug ) {
      out = fopen("pcvg.dat","w");
      fprintf(out,"%e\n",rmp*ST_TGV);
    } 

    while ( (lerr <= rm) && (++lit < lnit) ) {
      csrAtx(B,d,z);
      llerr = *er * ST_TGV;
      llnit = *ni;
      /* compute w = A^-1.z = A^-1.Bt.d */
      ier = csrPrecondGrad(A,w,z,&llerr,&llnit,1);
      if ( ier < 1 )  break;

      /* compute Ad = B.(A^-1.Bt.d) = B.w */
      csrAx(B,w,Ad);
      dp = 0.0;
      for (i=0; i<B->nr; i++)  dp += d[i] * Ad[i];  
      if ( fabs(dp) <= ST_EPSD )  break;
	
      /* alpha_m = <R_m-1,R_m-1> / <AP_m,P_m> */
      alpha = rm / dp;
      rmn   = 0.0;
      /* update p, r, d */
      for (i=0; i<B->nr; i++) {
        pd[i] += alpha * d[i];
        r[i]  -= alpha * Ad[i];
        rmn   += r[i] * r[i];
      }
      if ( fabs(rm) <= ST_EPSA )  break;
      beta = rmn / rm;
      for (i=0; i<B->nr; i++) {
        d[i] = r[i] + beta * d[i];
      }
      rm = rmn;
      if ( info.ddebug )  fprintf(out," %e\n",rm);
    }

    if ( info.ddebug )  fclose(out);
    if ( ier < 1 || lit == lnit ) {
      fprintf(stdout,"  ## Incomplete CG for A^-1.Bt.dp: err %E   nit %d\n",rm,lit);
      return(-2);
    }
    lerr = sqrt(rm / rmp);
    if ( abs(info.imprim) > 4 )  fprintf(stdout,"     -> Pressure residual : err %E   it %d\n",lerr,lit);

    /*--- 3. update ud = uf-ul where ul=A^-1Bt*pd */
    /* compute ul = A^-1.(Bt.pd) */
    if ( abs(info.imprim) > 5 )  fprintf(stdout,"     Compute ul = A^-1.(Bt.pd)\n");
    csrAtx(B,pd,z);
    lerr = *er;
    lnit = *ni;
    ier = csrPrecondGrad(A,ul,z,&lerr,&lnit,1);
    if ( ier < 1 ) {
      fprintf(stdout,"  ## Incomplete CG for A^-1.Y: err %E   nit %d\n",lerr,lnit);
			free(uf); free(ru); free(rp); free(ul); free(d); free(pd); free(w); free(z);
      return(0);
    }

    /*--- 4. update u_(k+1) = u_k+ud */
    for (i=0; i<A->nr; i++) {
      u[i] = u[i] + uf[i] - ul[i];
    }

    /*--- 5. update p_(k+1) = p_k+pd */
    for (i=0; i<B->nr; i++) {
      p[i] += pd[i];
    }

    /*--- 6. update ru = f- Au_(k+1)-Bt p_(k+1) */
    csrAxpy(A,u,F,ru,-1.0,1.0);
    csrAtxpy(B,p,ru,ru,-1.0,1.0);

    /*--- 7. update rp = - Bu_(k+1) */
    csrAx(B,u,rp);
		for (i=0; i<B->nr; i++)  rp[i] = -rp[i];
	
    /*--- calculer rm */   
    rm1n = rm2n = 0.0;
    for (i=0; i<A->nr; i++)  rm1n += ru[i] * ru[i];
		for (i=0; i<B->nr; i++)  rm2n += rp[i] * rp[i];
    rm1 = rm1n;
    rm2 = rm2n;
		if ( abs(info.imprim) > 4 )  fprintf(stdout,"     it %d rm1 %e  rm2 %e   err %e\n",it,rm1*ST_TGV,rm2,err);
		if ( rm1*ST_TGV < ST_EPS && rm2 < ST_EPS )  break;
  }
  while ( ++it <= nit );

  free(uf); free(ru); free(rp); free(ul); free(d); free(pd); free(w); free(z);
  free(Ad); 

  if ( abs(info.imprim) > 4 )  {
    fprintf(stdout,"     -> Pressure: err %E   it %d\n",rm1,it);
    fprintf(stdout,"     -> Velocity: err %E   it %d\n",rm2,it);
  }
  return(1);
}





