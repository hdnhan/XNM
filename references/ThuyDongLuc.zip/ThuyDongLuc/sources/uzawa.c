#include "stokes.h"

extern Info  info;


/* Uzawa algorithm for solving ( A Bt ) ( U ) = ( F )
                               ( B  S ) ( P ) = ( 0 )
   solve B A^-1 Bt P = B A^-1 F - G  then  AU = F-Bt.P */
int ST_Uzawa(pMesh mesh,pSol sol,pCsr A,pCsr B,pCsr S,double *F,double *er,int *ni) {
  double   *d,*z,*w,*r,*Ad,*u,*p,dp,alpha,beta,err,lerr,rm,rmp,rmn,nn;
  int       m,n,it,nit,lnit,ier;
  FILE     *out = 0;

  u  = sol->u;
  p  = sol->p;
	n  = A->nr;
	m  = B->nr;
  nn = csrXY(p,p,m);

  /*--- 1. solve for p: B A^-1 Bt p = B A^-1 F */
  /* 1.a compute Az = F; z = A^-1.F */
  if ( abs(info.imprim) > 5 )  fprintf(stdout,"     Compute z = A^-1.F\n");
	/* w = F - Bt*p */
  w  = (double*)calloc(n,sizeof(double));
  assert(w);
	csrAtxpy(B,p,F,w,-1.0,1.0);
  z = (double*)calloc(n,sizeof(double));
  assert(z);

  /* z = A^-1*w = A^-1*(F - Bt*p) */
  err = *er;
  nit = *ni;
  ier = csrPrecondGrad(A,z,w,&err,&nit,1);
  if ( ier < 1 ) {
    fprintf(stdout,"  ## Incomplete CG for A^-1.w: err %E   nit %d\n",err,nit);
    free(z);  free(w);
    return(0);
  }
  if ( abs(info.imprim) > 5 )  fprintf(stdout,"     z = A^-1.F : err %E   it %d\n",err,nit);
  
  /* 1.b compute d = B.(A^-1.F) = B.z */
  if ( abs(info.imprim) > 5 )  fprintf(stdout,"     Compute d = B.(A^-1.F) - G\n");
  r = (double*)malloc(m*sizeof(double));
  assert(r);
  csrAx(B,z,r);

  /* compute R0 = b - Ax0, rm = (R0,R0) */
  rmp = csrXY(r,r,m);
  if ( sqrt(fabs(rmp)) < 5.0*err ) {
    free(z);  free(r);  free(w);
    return(1);
  }
  
  d = (double*)calloc(m,sizeof(double));
  assert(d);
  memset(w,0,n*sizeof(double));
  memcpy(d,r,m*sizeof(double));

  Ad = (double*)calloc(m,sizeof(double));
  assert(Ad);

  /* conjugate gradient: p1 = r0 */
  it  = 0;
  ier = 1;
  err = *er;
  err = err * err * rmp;
  nit = *ni;
  rm  = rmp;
  if ( info.ddebug ) {
    out = fopen("pcvg.dat","w");
    fprintf(out,"%e\n",rmp);
  }
  
  while ( ( err < rm) && (++it <= nit) ) {
    /* alpha_m = <R_m-1,R_m-1> / <AP_m,P_m> */
    csrAtx(B,d,z);
    lerr = *er;
    lnit = *ni;
    /* compute w = A^-1.z = A^-1.Bt.d */
	  //memset(w,0,n*sizeof(double));
    ier = csrPrecondGrad(A,w,z,&lerr,&lnit,0);
    if ( ier < 1 )  break;
    else if ( lnit == 1 )  exit(1); 
    /* compute Ad = B.(A^-1.Bt.d) - S.d = B.w - S.d */
    csrAx(B,w,Ad);
    dp = csrXY(d,Ad,m);
    if ( fabs(dp) <= ST_EPSA )  break;
    /* alpha_m = <R_m-1,R_m-1> / <AP_m,P_m> */
    alpha = rm / dp;  
    /*solution at the time t^(n+1)*/
		csrlXmY(p,d,p,1.0,alpha,m);
		/*new direction*/
		csrlXmY(r,Ad,r,1.0,-alpha,m);
		rmn = csrXY(r,r,m);
    if ( rmn <= ST_EPSA )  break;
    beta = rmn / rm;
		csrlXmY(r,d,d,1.0,beta,m);
    rm = rmn;
    //fprintf(stdout,"rm = %E\n", rm);
    //printf("  GC1: it  %d  err %E  rm %E  alpha %e   beta %e\n",it,err,rmn,alpha,beta);
    //printf("  for p: it %d dp %E rm %E rm/rmp %E \n",it,dp,rm,rm/rmp);
    if ( info.ddebug )  fprintf(out,"%e\n",rm);
  }
  if ( info.ddebug )  fclose(out);
  free(z);  free(d);  free(r);  free(Ad);
  
  if ( ier < 1 || it > nit ) {
    fprintf(stdout,"  ## Incomplete CG for A^-1.Bt.p: err %E   nit %d ier %d\n",rm,it,ier);
    return(-2);
  }
  err = sqrt(rm / rmp);
  if ( abs(info.imprim) > 4 )  fprintf(stdout,"     -> Pressure: err %E   it %d\n",err,it);
  
  /*--- 2. solve Au = F-Bt.p */

  /* 2.a compute w = F-Bt.p */
  if ( abs(info.imprim) > 5 )  fprintf(stdout,"     Compute G = F-Bt.p\n");
  csrAtxpy(B,p,F,w,-1.0,1.0);

  /* compute Au = w => u = A^-1.(F-Bt.p) */
  
  if ( abs(info.imprim) > 5 )  fprintf(stdout,"     Compute u = A^-1.G = A^-1.(F-Bt.p)\n");
  err = *er;
  nit = *ni;
  ier = csrPrecondGrad(A,u,w,&err,&nit,1);
  free(w);
  if ( ier < 1 ) {
    fprintf(stdout,"  ## Incomplete velocity: err %E   nit %d\n",err,nit);
    return(0);
  }
  if ( abs(info.imprim) > 4 )  fprintf(stdout,"     -> Velocity: err %E   it %d\n",err,nit);
  
  return(1);
}

