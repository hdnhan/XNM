#include "stokes.h"

extern Info  info;

/* build right hand side vector and set boundary conds. */
void rhside_3d(pMesh mesh,pSol sol,double *F) {
  pTetra   pt;
  double   nu,rho,*a,*b,*c,*d,vol,d1,d2,d3,d4;
  int      k,ig;
  char     i;

  if ( abs(info.imprim) > 5 )  fprintf(stdout,"     Gravity and body forces\n");

  /* gravity as external force */
  if ( info.load & (1<<0) ) {
    for (k=1; k<=mesh->ne; k++) {
      pt = &mesh->tetra[k];
      if ( !pt->v[0] )  continue;
      getMat(sol,pt->ref,&nu,&rho);

      a = &mesh->point[pt->v[0]].c[0]; 
      b = &mesh->point[pt->v[1]].c[0]; 
      c = &mesh->point[pt->v[2]].c[0]; 
      d = &mesh->point[pt->v[3]].c[0];
      vol = volu_3d(a,b,c,d);
      d1  = rho * vol / 4.0;
      d2  = rho * vol * 32.0 / 105.0;
			d3  = -rho * vol / 20.0;
			d4  = rho * vol / 5.0;
      for (i=0; i<4; i++) {
	      ig = 3*(pt->v[i]-1);
	      if ( info.typ < P2P1 ) {
          F[ig+0] += d1 * info.gr[0];
          F[ig+1] += d1 * info.gr[1];
          F[ig+2] += d1 * info.gr[2];
        }
        else {
	        F[ig+0] += d3 * info.gr[0];
          F[ig+1] += d3 * info.gr[1];
          F[ig+2] += d3 * info.gr[2];       
	      }
      }
      /* bubble part ; mid-point */
      if ( info.typ == P1bP1 ) {
        ig = 3*(pt->v[4]-1);
        F[ig+0] += d2 * info.gr[0];
        F[ig+1] += d2 * info.gr[1];
        F[ig+2] += d2 * info.gr[2];
      }
      else
        for (i=4; i<10; i++) {
					ig = 3*(pt->v[i]-1);
          F[ig+0] += d4 * info.gr[0];
          F[ig+1] += d4 * info.gr[1];
          F[ig+2] += d4 * info.gr[2];
        }
    }
  }
}

/* set Dirichlet boundary conditions using TGV */
void rhsTGV_3d(pMesh mesh,pSol sol,double *F) {
  pTria     ptt;
  pEdge     pa;
  pPoint    ppt;
  pCl       pcl;
  double   *vp,*va;
  int       k,ig;
	char      i,idof;

  /* nodal boundary conditions */
  if ( (sol->cltyp & ST_Ver) && (info.typ < P2P1) ) {
    for (k=1; k<=mesh->np; k++) {
      ppt = &mesh->point[k];
      pcl = getCl(sol,ppt->ref,ST_Ver);
      if ( pcl && pcl->typ == Dirichlet ) {
        vp = pcl->att == 'f' ? &sol->bc[3*(k-1)] : &pcl->u[0];
        F[3*(k-1)+0] = ST_TGV * vp[0];
        F[3*(k-1)+1] = ST_TGV * vp[1];
        F[3*(k-1)+2] = ST_TGV * vp[2];
      }
      if ( pcl && pcl->typ == Slip ) {
        vp = pcl->att == 'f' ? &sol->bc[3*(k-1)] : &pcl->u[0];
      if (ppt->ref == 300)      
        F[3*(k-1)+0] = ST_TGV * vp[0];
      else if (ppt->ref == 200) 
        F[3*(k-1)+1] = ST_TGV * vp[0];
        //F[3*(k-1)+2] = ST_TGV * vp[2];
      }
    }
  }

  if ( sol->cltyp & ST_Edg ) {
    idof = info.typ < P2P1 ? 2 : 3;
    for (k=1; k<=mesh->nai; k++) {
      pa = &mesh->edge[k];
      pcl = getCl(sol,pa->ref,ST_Edg);
      if ( pcl&& pcl->typ == Dirichlet ) {
        va = pcl->att == 'f' ? &sol->bc[3*(k-1)] : &pcl->u[0];
        for (i=0; i<idof; i++) {
          ig  = 3*(pa->v[i]-1);
          F[ig+0] = ST_TGV * va[0];
          F[ig+1] = ST_TGV * va[1];
          F[ig+2] = ST_TGV * va[2];
        }
      }
    }
  }

  if ( sol->cltyp & ST_Tri ) {
    for (k=1; k<=mesh->nt; k++) {
      ptt = &mesh->tria[k];
      pcl = getCl(sol,ptt->ref,ST_Tri);
      if ( pcl && pcl->typ == Dirichlet ) {
        vp = pcl->att == 'f' ? &sol->bc[3*(k-1)] : &pcl->u[0];
        for (i=0; i<3; i++) {
          F[3*(ptt->v[i]-1)+0] = ST_TGV * vp[0];
          F[3*(ptt->v[i]-1)+1] = ST_TGV * vp[1];
          F[3*(ptt->v[i]-1)+2] = ST_TGV * vp[2];
        }
      }
      if ( pcl && pcl->typ == Slip ) {
        vp = pcl->att == 'f' ? &sol->bc[3*(k-1)] : &pcl->u[0];
        if (ptt->ref == 300)
          for (i=0; i<3; i++) 
            F[3*(ptt->v[i]-1)+0] = ST_TGV * vp[0];
      	else if (ptt->ref == 200)
	        for (i=0; i<3; i++) 
	          F[3*(ptt->v[i]-1)+1] = ST_TGV * vp[0];
      }
    }
  }
}

/* update RHS for unsteady NS: F^n = F + 1/dt u^n(X^n(x)) */
void rhsupd_3d(pMesh mesh,pSol sol,double *Fk) {
  pTetra   pt;
  double  *a,*b,*c,*d,vol,d1,d2,idt,nu,rho;
  int      k,ig;
  char     i;

  idt = 1.0 / info.dt;
  for (k=1; k<=mesh->ne; k++) {
    pt = &mesh->tetra[k];
    if ( !pt->v[0] )  continue;
    getMat(sol,pt->ref,&nu,&rho);

    a = &mesh->point[pt->v[0]].c[0]; 
    b = &mesh->point[pt->v[1]].c[0]; 
    c = &mesh->point[pt->v[2]].c[0]; 
    d = &mesh->point[pt->v[3]].c[0];
    vol = volu_3d(a,b,c,d);
    d1  = idt * rho * vol / 4.0;
    d2  = idt * rho * vol * 32.0 / 105.0;
    
    for (i=0; i<4; i++) {
      ig = 3*(pt->v[i]-1);
      Fk[ig+0] += d1*sol->u[ig+0];
      Fk[ig+1] += d1*sol->u[ig+1];
      Fk[ig+2] += d1*sol->u[ig+2];
    }
    /* bubble part */
    if ( info.typ == P1bP1 ) {
      ig = 3*(pt->v[4]-1);
      Fk[ig+0] += d2*sol->u[ig+0];
      Fk[ig+1] += d2*sol->u[ig+1];
      Fk[ig+2] += d2*sol->u[ig+2];
    }
  }
}

/* set TGV to diagonal coefficient when Dirichlet */
static void setTGV_3d(pMesh mesh,pSol sol,pCsr A) {
  pCl      pcl;
  pTria    pt;
  pEdge    pa;
  pPoint   ppt;
  int      k,ig;
  char     i,idof;

  /* at nodes */
  if ( (sol->cltyp & ST_Ver) && (info.typ < P2P1) ) {
    for (k=1; k<=mesh->np; k++) {
      ppt = &mesh->point[k];
      pcl = getCl(sol,ppt->ref,ST_Ver);
      if ( pcl && pcl->typ == Dirichlet ) {
				ig = 3*(k-1);
        csrSet(A,ig+0,ig+0,ST_TGV);
        csrSet(A,ig+1,ig+1,ST_TGV);
        csrSet(A,ig+2,ig+2,ST_TGV);
      }
      if ( pcl && pcl->typ == Slip ) {
				ig = 3*(k-1);
        if (ppt->ref == 300) csrSet(A,ig+0,ig+0,ST_TGV);
        else if (ppt->ref == 200) csrSet(A,ig+1,ig+1,ST_TGV);
        //csrSet(A,ig+2,ig+2,ST_TGV);
      }
    }
  }

  /* at edge nodes */
  if ( sol->cltyp & ST_Edg ) {
    idof = info.typ < P2P1 ? 2 : 3;
    for (k=1; k<=mesh->nai; k++) {
      pa  = &mesh->edge[k];
      pcl = getCl(sol,pa->ref,ST_Edg);
      if ( pcl && pcl->typ == Dirichlet ) {
				for (i=0; i<idof; i++) {
          ig = 3*(pa->v[i]-1);
          csrSet(A,ig+0,ig+0,ST_TGV);
          csrSet(A,ig+1,ig+1,ST_TGV);
					csrSet(A,ig+2,ig+2,ST_TGV);
				}
      }
    }
  }

  /* at triangles nodes */
  if ( sol->cltyp & ST_Tri ) {
    for (k=1; k<=mesh->nt; k++) {
      pt  = &mesh->tria[k];
      pcl = getCl(sol,pt->ref,ST_Tri);
      if ( pcl && pcl->typ == Dirichlet ) {
        for (i=0; i<3; i++) {
					ig = 3*(pt->v[i]-1);
          csrSet(A,ig+0,ig+0,ST_TGV);
          csrSet(A,ig+1,ig+1,ST_TGV);
          csrSet(A,ig+2,ig+2,ST_TGV);
        }
      }
      if ( pcl && pcl->typ == Slip ) {
        for (i=0; i<3; i++) {
					ig = 3*(pt->v[i]-1);
          if (pt->ref == 300) csrSet(A,ig+0,ig+0,ST_TGV);
          else if (pt->ref == 200) csrSet(A,ig+1,ig+1,ST_TGV);
        }
      }
    }
  }
}

/* local stiffness matrix */
static int matAe_P1(double *a,double *b,double *c,double *d,double nu, double rho, double Ae[30][30]) {
  double   m[9],im[9],mm[9][15],Dp[3][5],ph[9][15];
  double   dd,idt,vol;
  char     i,j,p,s;
  static double w[5]    = { -4./5., 9./20., 9./20., 9./20.,  9./20. };
  static double q[5][3] = { {1./4.,1./4.,1./4.}, {1./2.,1./6.,1./6.}, {1./6.,1./2.,1./6.}, 
                            {1./6.,1./6.,1./2.}, {1./6.,1./6.,1./6.} };

  if ( info.dt > 0 )  
    idt = 1.0 / info.dt;
  else
    idt = 1.0;

  Dp[0][0] = 1;  Dp[0][1] = 0;  Dp[0][2] = 0;  Dp[0][3] = -1;  
  Dp[1][0] = 0;  Dp[1][1] = 1;  Dp[1][2] = 0;  Dp[1][3] = -1; 
  Dp[2][0] = 0;  Dp[2][1] = 0;  Dp[2][2] = 1;  Dp[2][3] = -1;

  /* measure of K(a,b,c,d) */
  vol = volu_3d(a,b,c,d);

  /* mm = tB^-1 */
  for (i=0; i<3; i++) {
    m[i+0] = a[i] - d[i];
    m[i+3] = b[i] - d[i];
    m[i+6] = c[i] - d[i];
  }
	if ( !invmatg(m,im) )  return(0);
    
  /* Ae: boucle sur les 5 points de quadrature */
  memset(Ae,0,30*30*sizeof(double));
  for (p=0; p<5; p++) {
    /* Dp for bubble*/
    Dp[0][4] = 256.0*q[p][1]*q[p][2]*(1.0-2.0*q[p][0]-q[p][1]-q[p][2]);
    Dp[1][4] = 256.0*q[p][0]*q[p][2]*(1.0-q[p][0]-2.0*q[p][1]-q[p][2]);
    Dp[2][4] = 256.0*q[p][1]*q[p][0]*(1.0-q[p][0]-q[p][1]-2.0*q[p][2]);
  
    /* unsteady case */
    if ( info.dt > 0 ) {
      /* ph_basis function */
      memset(ph,0,9*15*sizeof(double));
      ph[0][0] = ph[3][5] = ph[6][10] = q[p][0];  
      ph[0][1] = ph[3][6] = ph[6][11] = q[p][1];  
      ph[0][2] = ph[3][7] = ph[6][12] = q[p][2];  
      ph[0][3] = ph[3][8] = ph[6][13] = 1.0 - q[p][0]-q[p][1]-q[p][2];   
      ph[0][4] = ph[3][9] = ph[6][14] = 256.0 * q[p][0]*q[p][1]*q[p][2]*(1.0-q[p][0]-q[p][1]-q[p][2]);  
    }

    /* mm = (tBt^-1) Dp */
    memset(mm,0,9*15*sizeof(double));
    for (i=0; i<3; i++) {
      for (j=0; j<5; j++) {
        for (s=0; s<3; s++) 
          mm[i][j]   += im[i*3+s] * Dp[s][j];
        mm[i+3][j+5]  = mm[i][j];
        mm[i+6][j+10] = mm[i][j];
      }
    } 
    /* Ae = vol tmm nn */
    dd = vol * w[p];
    for (i=0; i<15; i++) {
      for (j=i; j<15; j++) {
        for (s=0; s<9; s++) {
          Ae[i][j] += dd * nu * mm[s][i] * mm[s][j];
				  if ( info.dt > 0 ) 
						Ae[i][j] += dd * rho * idt * ph[s][i] * ph[s][j];
			  }
      }
    }         
  }
  return(1);
}

/* local stiffness matrix */
static int matAe_P2(double *a,double *b,double *c,double *d,double nu, double rho, double Ae[30][30]) {
	double   m[9],im[9],mm[9][30],Dp[3][10],ph[9][30];
  double   dd,idt,vol;
  char     i,j,p,s;
  static double w[5]    = { -4./5., 9./20., 9./20., 9./20.,  9./20. };
  static double q[5][3] = { {1./4.,1./4.,1./4.}, {1./2.,1./6.,1./6.}, {1./6.,1./2.,1./6.}, 
                            {1./6.,1./6.,1./2.}, {1./6.,1./6.,1./6.} };

  if ( info.dt > 0 )  
    idt = 1.0 / info.dt;
  else
    idt = 1.0;

  /* measure of K(a,b,c,d) */
  vol = volu_3d(a,b,c,d);

  /* mm = tB^-1 */
  for (i=0; i<3; i++) {
    m[i+0] = a[i] - d[i];
    m[i+3] = b[i] - d[i];
    m[i+6] = c[i] - d[i];
  }
	if ( !invmatg(m,im) )  return(0);
    
  /* Ae: boucle sur les 5 points de quadrature */
  memset(Ae,0,30*30*sizeof(double));
  for (p=0; p<5; p++) {
    /* Dp for P2*/
    Dp[0][0]=4*q[p][0]-1; Dp[0][1]=0;            Dp[0][2]=0;           Dp[0][3]=4*(q[p][0]+q[p][1]+q[p][2])-3; 
    Dp[1][0]=0;           Dp[1][1]=4*q[p][1]-1;  Dp[1][2]=0;           Dp[1][3]=4*(q[p][0]+q[p][1]+q[p][2])-3; 
    Dp[2][0]=0;           Dp[2][1]=0;            Dp[2][2]=4*q[p][2]-1; Dp[2][3]=4*(q[p][0]+q[p][1]+q[p][2])-3; 
    
    Dp[0][4]=4*q[p][1];   Dp[0][5]=4*q[p][2];    Dp[0][6]=4*(1-2*q[p][0]-q[p][1]-q[p][2]); 
    Dp[1][4]=4*q[p][0];   Dp[1][5]=0;            Dp[1][6]=-4*q[p][0]; 
    Dp[2][4]=0;           Dp[2][5]=4*q[p][0];    Dp[2][6]=-4*q[p][0];   
  
    Dp[0][7]=0;           Dp[0][8]=-4*q[p][1];                         Dp[0][9]=-4*q[p][2];
    Dp[1][7]=4*q[p][2];   Dp[1][8]=4*(1-q[p][0]-2*q[p][1]-q[p][2]);    Dp[1][9]=-4*q[p][2];
    Dp[2][7]=4*q[p][1];   Dp[2][8]=-4*q[p][1];                         Dp[2][9]=4*(1-q[p][0]-q[p][1]-2*q[p][2]);
		
		/* unsteady case */
    if ( info.dt > 0 ) {
      /* ph_basis function */
      memset(ph,0,9*30*sizeof(double));
      ph[0][0] = ph[3][10] = ph[6][20] = q[p][0]*(2*q[p][0]-1);  
      ph[0][1] = ph[3][11] = ph[6][21] = q[p][1]*(2*q[p][1]-1);  
      ph[0][2] = ph[3][12] = ph[6][22] = q[p][2]*(2*q[p][2]-1);  
      ph[0][3] = ph[3][13] = ph[6][23] = (1.0 - q[p][0]-q[p][1]-q[p][2])*(1.0 - 2*q[p][0]-2*q[p][1]-2*q[p][2]);   
      ph[0][4] = ph[3][14] = ph[6][24] = 4 * q[p][0]*q[p][1];
      ph[0][5] = ph[3][15] = ph[6][25] = 4 * q[p][0]*q[p][2];
      ph[0][6] = ph[3][16] = ph[6][26] = 4 * q[p][0]*(1.0 - q[p][0]-q[p][1]-q[p][2]);
      ph[0][7] = ph[3][17] = ph[6][27] = 4 * q[p][1]*q[p][2]; 
      ph[0][8] = ph[3][18] = ph[6][28] = 4 * q[p][1]*(1.0 - q[p][0]-q[p][1]-q[p][2]);
      ph[0][9] = ph[3][19] = ph[6][29] = 4 * q[p][2]*(1.0 - q[p][0]-q[p][1]-q[p][2]); 
    }  
    /* mm = (tBt^-1) Dp */
    memset(mm,0,9*30*sizeof(double));
    for (i=0; i<3; i++) {
      for (j=0; j<10; j++) {
        for (s=0; s<3; s++) 
          mm[i][j]   += im[i*3+s] * Dp[s][j];
        mm[i+3][j+10] = mm[i][j];
        mm[i+6][j+20] = mm[i][j];
      }
    } 
    /* Ae = vol tmm nn */
    dd = vol*w[p];
    for (i=0; i<30; i++) {
      for (j=i; j<30; j++) {
        for (s=0; s<9; s++)
          Ae[i][j] += dd * nu * mm[s][i] * mm[s][j];
          if ( info.dt > 0 ) 
						Ae[i][j] += dd * rho*idt * ph[s][i] * ph[s][j];
      }
    }         
  }
  return(1);
}

/* local mass matrix */
static int matBe_P1(double *a,double *b,double *c,double *d,double Be[12][10]) {
  double   m[9],im[9],mm[3][5],ph[3][12],Dp[3][5];
  double   dd,vol;
  char     i,j,p,s;
  static double w[5]    = { -4./5., 9./20., 9./20., 9./20.,  9./20. };
  static double q[5][3] = { {1./4.,1./4.,1./4.}, {1./2.,1./6.,1./6.}, {1./6.,1./2.,1./6.}, 
                            {1./6.,1./6.,1./2.}, {1./6.,1./6.,1./6.} };

  Dp[0][0]=1;  Dp[0][1]=0;  Dp[0][2]=0;  Dp[0][3]=-1;  
  Dp[1][0]=0;  Dp[1][1]=1;  Dp[1][2]=0;  Dp[1][3]=-1; 
  Dp[2][0]=0;  Dp[2][1]=0;  Dp[2][2]=1;  Dp[2][3]=-1;

  /* measure of K(a,b,c,d) */
  vol = volu_3d(a,b,c,d);

  /* mm = tB^-1 */
  for (i=0; i<3; i++) {
    m[i+0] = a[i] - d[i];
    m[i+3] = b[i] - d[i];
    m[i+6] = c[i] - d[i];
  }
	if ( !invmatg(m,im) )  return(0);

  memset(Be,0,12*10*sizeof(double));
  for (p=0; p<5; p++) {
	  /* Dp for bubble */
    Dp[0][4] = 256.0*q[p][1]*q[p][2]*(1-2*q[p][0]-q[p][1]-q[p][2]);
    Dp[1][4] = 256.0*q[p][0]*q[p][2]*(1-q[p][0]-2*q[p][1]-q[p][2]);
    Dp[2][4] = 256.0*q[p][1]*q[p][0]*(1-q[p][0]-q[p][1]-2*q[p][2]);

    /* ph_basis function */
    memset(ph,0,3*12*sizeof(double));
    ph[0][0] = ph[1][4] = ph[2][8] = -q[p][0];  
    ph[0][1] = ph[1][5] = ph[2][9] = -q[p][1];  
    ph[0][2] = ph[1][6] = ph[2][10] = -q[p][2];  
    ph[0][3] = ph[1][7] = ph[2][11] = q[p][0]+q[p][1]+q[p][2]-1.0;
    /* mm = (tBt^-1) Dp */
    memset(mm,0,3*5*sizeof(double));
    for (i=0; i<3; i++) {
      for (j=0; j<5; j++) {
        for (s=0; s<3; s++) 
          mm[i][j]   += im[i*3+s] * Dp[s][j];
      }
    }
	  /* Be = area*wp*tmm N mm */
	  dd = vol * w[p];
	  for (i=0; i<12; i++) {
	    for (j=0; j<5; j++) {
	      for (s=0; s<3; s++)
	        Be[i][j] += dd * ph[s][i] * mm[s][j];
	    }
	  }
  }
	return(1);
}

/* local mass matrix */
static int matBe_P2(double *a,double *b,double *c,double *d,double Be[12][10]) {
	double   m[9],im[9],mm[3][10],ph[3][12],Dp[3][10];
  double   dd,vol;
  char     i,j,p,s;
  static double w[5]    = { -4./5., 9./20., 9./20., 9./20.,  9./20. };
  static double q[5][3] = { {1./4.,1./4.,1./4.}, {1./2.,1./6.,1./6.}, {1./6.,1./2.,1./6.}, 
                            {1./6.,1./6.,1./2.}, {1./6.,1./6.,1./6.} };

  /* measure of K(a,b,c,d) */
  vol = volu_3d(a,b,c,d);

  /* mm = tB^-1 */
  for (i=0; i<3; i++) {
    m[i+0] = a[i] - d[i];
    m[i+3] = b[i] - d[i];
    m[i+6] = c[i] - d[i];
  }
	if ( !invmatg(m,im) )  return(0);

  memset(Be,0,12*10*sizeof(double));
  for (p=0; p<5; p++) {
	  /* Dp for bubble */
    Dp[0][0]=4*q[p][0]-1; Dp[0][1]=0;            Dp[0][2]=0;           Dp[0][3]=4*(q[p][0]+q[p][1]+q[p][2])-3; 
    Dp[1][0]=0;           Dp[1][1]=4*q[p][1]-1;  Dp[1][2]=0;           Dp[1][3]=4*(q[p][0]+q[p][1]+q[p][2])-3; 
    Dp[2][0]=0;           Dp[2][1]=0;            Dp[2][2]=4*q[p][2]-1; Dp[2][3]=4*(q[p][0]+q[p][1]+q[p][2])-3; 
    
    Dp[0][4]=4*q[p][1];   Dp[0][5]=4*q[p][2];    Dp[0][6]=4*(1-2*q[p][0]-q[p][1]-q[p][2]); 
    Dp[1][4]=4*q[p][0];   Dp[1][5]=0;            Dp[1][6]=-4*q[p][0]; 
    Dp[2][4]=0;           Dp[2][5]=4*q[p][0];    Dp[2][6]=-4*q[p][0];   
  
    Dp[0][7]=0;           Dp[0][8]=-4*q[p][1];                         Dp[0][9]=-4*q[p][2];
    Dp[1][7]=4*q[p][2];   Dp[1][8]=4*(1-q[p][0]-2*q[p][1]-q[p][2]);    Dp[1][9]=-4*q[p][2];
    Dp[2][7]=4*q[p][1];   Dp[2][8]=-4*q[p][1];                         Dp[2][9]=4*(1-q[p][0]-q[p][1]-2*q[p][2]);
		
    /* ph_basis function */
    memset(ph,0,3*12*sizeof(double));
    ph[0][0] = ph[1][4] = ph[2][8] = -q[p][0];  
    ph[0][1] = ph[1][5] = ph[2][9] = -q[p][1];  
    ph[0][2] = ph[1][6] = ph[2][10] = -q[p][2];  
    ph[0][3] = ph[1][7] = ph[2][11] = q[p][0]+q[p][1]+q[p][2]-1.0;
    /* mm = (tBt^-1) Dp */
    memset(mm,0,3*10*sizeof(double));
    for (i=0; i<3; i++) {
      for (j=0; j<10; j++) {
        for (s=0; s<3; s++) 
          mm[i][j]   += im[i*3+s] * Dp[s][j];
      }
    }
	  /* Be = area*wp*tmm N mm */
	  dd = vol * w[p];
	  for (i=0; i<12; i++) {
	    for (j=0; j<10; j++) {
	      for (s=0; s<3; s++)
	        Be[i][j] += dd * ph[s][i] * mm[s][j];
	    }
	  }
  }
	return(1);
}

/* local stiffness matrix */
static int matMe_P1(double *a,double *b,double *c,double *d,double nu, double rho, double Me[34][34]) {
  double   m[9],im[9],mm[10][19],nn[10][19],N[10][10],Dp[3][5],ph[10][19];
  double   dd,idt,vol,eps;
  char     i,j,p,s;
  static double w[5]    = { -4./5., 9./20., 9./20., 9./20.,  9./20. };
  static double q[5][3] = { {1./4.,1./4.,1./4.}, {1./2.,1./6.,1./6.}, {1./6.,1./2.,1./6.}, 
                            {1./6.,1./6.,1./2.}, {1./6.,1./6.,1./6.} };
	
  if ( info.dt > 0 )  
    idt = 1.0 / info.dt;
  else
    idt = 1.0;

  Dp[0][0] = 1;  Dp[0][1] = 0;  Dp[0][2] = 0;  Dp[0][3] = -1;  
  Dp[1][0] = 0;  Dp[1][1] = 1;  Dp[1][2] = 0;  Dp[1][3] = -1; 
  Dp[2][0] = 0;  Dp[2][1] = 0;  Dp[2][2] = 1;  Dp[2][3] = -1;
  
  /* measure of K(a,b,c,d) */
  vol = volu_3d(a,b,c,d);

  /* mm = tB^-1 */
  for (i=0; i<3; i++) {
    m[i+0] = a[i] - d[i];
    m[i+3] = b[i] - d[i];
    m[i+6] = c[i] - d[i];
  }
	if ( !invmatg(m,im) )  return(0);
	
  memset(N,0,10*10*sizeof(double));
  eps = info.hmin * 0.001;
  for (i=0; i<9; i++)  N[i][i] = nu;
	N[0][9] = N[9][0] = N[4][9] = N[9][4] = N[8][9] = N[9][8] =-1.0;
	N[9][9] = eps;

  /* Me: loop on 5 quadrature points */
  memset(Me,0,34*34*sizeof(double));
  for (p=0; p<5; p++) {
	  /* Dp for bubble*/
    Dp[0][4] = 256.0*q[p][1]*q[p][2]*(1.0-2.0*q[p][0]-q[p][1]-q[p][2]);
    Dp[1][4] = 256.0*q[p][0]*q[p][2]*(1.0-q[p][0]-2.0*q[p][1]-q[p][2]);
    Dp[2][4] = 256.0*q[p][1]*q[p][0]*(1.0-q[p][0]-q[p][1]-2.0*q[p][2]);
    /* unsteady case */
	  if ( info.dt > 0 ) {
	    /* ph_basis function */
	    memset(ph,0,10*19*sizeof(double));
	    ph[0][0] = ph[3][5] = ph[6][10] = q[p][0];  
	    ph[0][1] = ph[3][6] = ph[6][11] = q[p][1];  
			ph[0][2] = ph[3][7] = ph[6][12] = q[p][2];  
			ph[0][3] = ph[3][8] = ph[6][13] = 1.0-q[p][0]-q[p][1]-q[p][2];
			ph[0][4] = ph[3][9] = ph[6][14] = 256.0 * q[p][0]*q[p][1]*q[p][2]*(1.0-q[p][0]-q[p][1]-q[p][2]); 
	  }
		
    /* mm = (tBt^-1) Dp */
    memset(mm,0,10*19*sizeof(double));
    for (i=0; i<3; i++) {
      for (j=0; j<5; j++) {
        for (s=0; s<3; s++) 
          mm[i][j]   += im[i*3+s] * Dp[s][j];
        mm[i+3][j+5]  = mm[i][j];
        mm[i+6][j+10] = mm[i][j];
      }
    } 		
		mm[9][15] = q[p][0];  mm[9][16] = q[p][1];  mm[9][17] = q[p][2]; mm[9][18] = 1.0-q[p][0]-q[p][1]-q[p][2];

    /* nn = N mm */
		for (i=0; i<10; i++) {
			for (j=0; j<19; j++) {
				nn[i][j] = 0.0;
				for (s=0; s<10; s++)
					nn[i][j] += N[i][s] * mm[s][j];
			}
		}

	  /* Me = area*wp*tmm N mm */
	  dd = w[p] * vol;
	  for (i=0; i<19; i++) {
	    for (j=i; j<19; j++) {
	      for (s=0; s<10; s++) {
	        Me[i][j] += dd * mm[s][i] * nn[s][j];
	        if ( info.nit > 0 )
	          Me[i][j] += dd * rho * idt * ph[s][i] * ph[s][j];
        }
	    }
	  }
  }
  return(1);
}

static int matMe_P2(double *a,double *b,double *c,double *d,double nu,double rho,double Me[34][34]) {
  double   m[9],im[9],mm[10][19],nn[10][19],N[10][10],Dp[3][10],ph[10][30];
  double   dd,idt,vol,eps;
  char     i,j,p,s;
  static double w[5]    = { -4./5., 9./20., 9./20., 9./20.,  9./20. };
  static double q[5][3] = { {1./4.,1./4.,1./4.}, {1./2.,1./6.,1./6.}, {1./6.,1./2.,1./6.}, 
                            {1./6.,1./6.,1./2.}, {1./6.,1./6.,1./6.} };
	
  if ( info.dt > 0 )  
    idt = 1.0 / info.dt;
  else
    idt = 1.0; 
  /* measure of K(a,b,c,d) */
  vol = volu_3d(a,b,c,d);

  /* mm = tB^-1 */
  for (i=0; i<3; i++) {
    m[i+0] = a[i] - d[i];
    m[i+3] = b[i] - d[i];
    m[i+6] = c[i] - d[i];
  }
	if ( !invmatg(m,im) )  return(0);
	
  memset(N,0,10*10*sizeof(double));
  eps = info.hmin * 0.001;
  for (i=0; i<9; i++)  N[i][i] = nu;
	N[0][9] = N[9][0] = N[4][9] = N[9][4] = N[8][9] = N[9][8] =-1.0;
	N[9][9] = eps;

  /* Me: loop on 5 quadrature points */
  memset(Me,0,34*34*sizeof(double));
  for (p=0; p<5; p++) {
	   /* Dp for P2*/
      Dp[0][0]=4*q[p][0]-1; Dp[0][1]=0;            Dp[0][2]=0;           Dp[0][3]=4*(q[p][0]+q[p][1]+q[p][2])-3; 
      Dp[1][0]=0;           Dp[1][1]=4*q[p][1]-1;  Dp[1][2]=0;           Dp[1][3]=4*(q[p][0]+q[p][1]+q[p][2])-3; 
      Dp[2][0]=0;           Dp[2][1]=0;            Dp[2][2]=4*q[p][2]-1; Dp[2][3]=4*(q[p][0]+q[p][1]+q[p][2])-3; 

      Dp[0][4]=4*q[p][1];   Dp[0][5]=4*q[p][2];    Dp[0][6]=4*(1-2*q[p][0]-q[p][1]-q[p][2]); 
      Dp[1][4]=4*q[p][0];   Dp[1][5]=0;            Dp[1][6]=-4*q[p][0]; 
      Dp[2][4]=0;           Dp[2][5]=4*q[p][0];    Dp[2][6]=-4*q[p][0];   

      Dp[0][7]=0;           Dp[0][8]=-4*q[p][1];                         Dp[0][9]=-4*q[p][2];
      Dp[1][7]=4*q[p][2];   Dp[1][8]=4*(1-q[p][0]-2*q[p][1]-q[p][2]);    Dp[1][9]=-4*q[p][2];
      Dp[2][7]=4*q[p][1];   Dp[2][8]=-4*q[p][1];                         Dp[2][9]=4*(1-q[p][0]-q[p][1]-2*q[p][2]);
    /* unsteady case */
    if ( info.dt > 0 ) {
      /* ph_basis function */
      memset(ph,0,9*30*sizeof(double));
      ph[0][0] = ph[3][10] = ph[6][20] = q[p][0]*(2*q[p][0]-1);  
      ph[0][1] = ph[3][11] = ph[6][21] = q[p][1]*(2*q[p][1]-1);  
      ph[0][2] = ph[3][12] = ph[6][22] = q[p][2]*(2*q[p][2]-1);  
      ph[0][3] = ph[3][13] = ph[6][23] = (1.0 - q[p][0]-q[p][1]-q[p][2])*(1.0 - 2*q[p][0]-2*q[p][1]-2*q[p][2]);   
      ph[0][4] = ph[3][14] = ph[6][24] = 4 * q[p][0]*q[p][1];
      ph[0][5] = ph[3][15] = ph[6][25] = 4 * q[p][0]*q[p][2];
      ph[0][6] = ph[3][16] = ph[6][26] = 4 * q[p][0]*(1.0 - q[p][0]-q[p][1]-q[p][2]);
      ph[0][7] = ph[3][17] = ph[6][27] = 4 * q[p][1]*q[p][2]; 
      ph[0][8] = ph[3][18] = ph[6][28] = 4 * q[p][1]*(1.0 - q[p][0]-q[p][1]-q[p][2]);
      ph[0][9] = ph[3][19] = ph[6][29] = 4 * q[p][2]*(1.0 - q[p][0]-q[p][1]-q[p][2]); 
    }

    /* mm = (tBt^-1) Dp */
    memset(mm,0,10*19*sizeof(double));
    for (i=0; i<3; i++) {
      for (j=0; j<5; j++) {
        for (s=0; s<3; s++) 
          mm[i][j]   += im[i*3+s] * Dp[s][j];
        mm[i+3][j+5]  = mm[i][j];
        mm[i+6][j+10] = mm[i][j];
      }
    } 		
		mm[9][15] = q[p][0];  mm[9][16] = q[p][1];  mm[9][17] = q[p][2]; mm[9][18] = 1.0-q[p][0]-q[p][1]-q[p][2];

    /* nn = N mm */
		for (i=0; i<10; i++) {
			for (j=0; j<19; j++) {
				nn[i][j] = 0.0;
				for (s=0; s<10; s++)
					nn[i][j] += N[i][s] * mm[s][j];
			}
		}

	  /* Me = area*wp*tmm N mm */
	  dd = w[p] * vol;
	  for (i=0; i<19; i++) {
	    for (j=i; j<19; j++) {
	      for (s=0; s<10; s++) {
	        Me[i][j] += dd * mm[s][i] * nn[s][j];
	        if ( info.dt > 0 )
	          Me[i][j] += dd * rho * idt * ph[s][i] * ph[s][j];
        }
	    }
	  }
  }
  return(1);
}

/* stiffness+mass matrix function */
static int (*matAe)(double *a,double *b,double *c,double *d,double nu, double rho, double Ae[30][30]);
static int (*matBe)(double *a,double *b,double *c,double *d,double Be[12][10]);
static int (*matMe)(double *a,double *b,double *c,double *d,double nu, double rho, double Me[34][34]);

void matAB_3d(pMesh mesh,pSol sol,pCsr A,pCsr B) {
  pTetra   pt;
  double  *a,*b,*c,*d,Ae[30][30],Be[12][10];
  double   rho,nu,mas,vol;
  int      k,nr,nc,nbe,ig,jg;
  char     i,j,idof;
  static int ndof[4] = {4,5,4,10};
	FILE     *mass;

  /* memory allocation */
  if ( info.typ < P2P1 ) {
    nr  = info.typ == P1P1 ? mesh->dim*mesh->np : mesh->dim*(mesh->np+mesh->ne);
    nbe = info.typ == P1P1 ? 8*mesh->ne : 20*mesh->ne;
    matAe = matAe_P1;
    matBe = matBe_P1;
  }
  else {
    nr  = mesh->dim*(mesh->np+mesh->na);
    nbe = 60*(mesh->np + mesh->na);
    matAe = matAe_P2;
    matBe = matBe_P2;
  }
printf("A.nbe = %d\n",nbe);
  csrAlloc(A,nr,nr,nbe,CS_UT+CS_SYM);
  assert(A);

  if ( info.typ < P2P1 ) {
    nr  = mesh->np;
    nc  = info.typ == P1P1 ? mesh->dim*mesh->np : mesh->dim*(mesh->np+mesh->ne);
    nbe = info.typ == P1P1 ? 9*mesh->ne : 21*mesh->ne;
  }
  else {
    nr  = mesh->np;
    nc  = mesh->dim*(mesh->np + mesh->na);
    nbe = 180*mesh->np;
  }
printf("B.nbe = %d\n",nbe);
  csrAlloc(B,nr,nc,nbe,0);
  assert(B);

  /* matrix assembly */
  idof = ndof[info.typ];

	mas = 0.0;
	mass = fopen("masse.txt","a");
  for (k=1; k<=mesh->ne; k++) {
    pt = &mesh->tetra[k];
    if ( !pt->v[0] )  continue;

    /* viscosity+density */
    if ( !getMat(sol,pt->ref,&nu,&rho) )  continue;
    /*if ( info.rhs )  nu = ST_NU - nu;*/
 
    a = &mesh->point[pt->v[0]].c[0]; 
    b = &mesh->point[pt->v[1]].c[0]; 
    c = &mesh->point[pt->v[2]].c[0]; 
    d = &mesh->point[pt->v[3]].c[0];

    vol = volu_3d(a,b,c,d);
    if (pt->ref==3) mas += vol;
		

    /* local stiffness matrix A */
    if ( !matAe(a,b,c,d,nu,rho,Ae) )  continue;

    /* global stiffness matrix */
	  for (i=0; i<3*idof; i++) {
	    ig = pt->v[i % idof];
	    ig = 3*(ig-1) + (i / idof);
	    for (j=i; j<3*idof; j++) {
	      if ( fabs(Ae[i][j]) < ST_EPSA )  continue;
	      jg = pt->v[j % idof];
	      jg = 3*(jg-1) + (j / idof);
	      if ( ig < jg )
	        csrPut(A,ig,jg,Ae[i][j]);
	      else
	        csrPut(A,jg,ig,Ae[i][j]);
	    }
	  }

	  /* local mass matrix B */
    if ( !matBe(a,b,c,d,Be) )  continue;

    /* global mass matrix B */
	  for (i=0; i<12; i++) { //(12=mesh->dim*4)
	    ig = pt->v[i % 4]-1;
	    for (j=0; j<idof; j++) { //(idof=5 for P1bP2; =10 for P2P1)
	      if ( fabs(Be[i][j]) < ST_EPSA )  continue;
	      jg = 3*(pt->v[j]-1) + (i / 4);
        csrPut(B,ig,jg,Be[i][j]);
      }
    }
	}
  setTGV_3d(mesh,sol,A);
  csrPack(A);
  csrPack(B);
  if ( abs(info.imprim) > 4 || info.ddebug ) {
    fprintf(stdout,"     A: %6d x %6d  nze %8d,  sparsity %7.4f%%\n",A->nr,A->nc,A->nbe,100.0*A->nbe/A->nr/A->nc);
    fprintf(stdout,"     B: %6d x %6d  nze %8d,  sparsity %7.4f%%\n",B->nr,B->nc,B->nbe,100.0*B->nbe/B->nr/B->nc);
printf("A.nbe / ne = %d   / np = %d\n",A->nbe/mesh->ne,A->nbe/mesh->np);
printf("B.nbe / ne = %d   / np = %d\n",B->nbe/mesh->ne,B->nbe/mesh->np);
  }

  fprintf(mass,"%E\n",mas);
	fclose(mass);
}

void matM_3d(pMesh mesh,pSol sol,pCsr M,pCsr B) {
	pTetra   pt;
  double  *a,*b,*c,*d,Me[34][34];
  double   rho,nu;
  int      k,nra,nrb,nbe,ig,jg;
  char     i,j,idof;
  static int ndof[4] = {4,5,4,10};

	/* memory allocation */
  if ( info.typ < P2P1 ) {
    nra = info.typ == P1P1 ? mesh->dim*mesh->np : mesh->dim*(mesh->np+mesh->ne);
		nrb = mesh->np;
    nbe = 195*mesh->np;
    matMe = matMe_P1;
  }
  else {
    nra = mesh->dim*(mesh->np+mesh->na);
		nrb = mesh->np;
    nbe = 40*(mesh->np + mesh->na);
    matMe = matMe_P2;
  }
	printf("M.nbe = %d\n",nbe);
  csrAlloc(M,nra+nrb,nra+nrb,nbe,CS_UT+CS_SYM);
  assert(M);

	/* matrix assembly */
  idof = ndof[info.typ];
  for (k=1; k<=mesh->ne; k++) {
    pt = &mesh->tetra[k];
    if ( !pt->v[0] )  continue;

    /* viscosity+density */
    if ( !getMat(sol,pt->ref,&nu,&rho) )  continue;
    /*if ( info.rhs )  nu = ST_NU - nu;*/

    a  = &mesh->point[pt->v[0]].c[0]; 
    b  = &mesh->point[pt->v[1]].c[0]; 
    c  = &mesh->point[pt->v[2]].c[0];
    d  = &mesh->point[pt->v[3]].c[0]; 

    /* local stiffness matrix M */
    if ( !matMe(a,b,c,d,nu,rho,Me) )  continue;

    /* global stiffness matrix */
	  for (i=0; i<3*idof; i++) {
	    ig = pt->v[i % idof];
	    ig = 3*(ig-1) + (i / idof);
	    for (j=i; j<3*idof; j++) {
	      if ( fabs(Me[i][j]) < ST_EPSA )  continue;
	      jg = pt->v[j % idof];
	      jg = 3*(jg-1) + (j / idof);
	      if ( ig < jg )
	        csrPut(M,ig,jg,Me[i][j]);
	      else
	        csrPut(M,jg,ig,Me[i][j]);
	    }
	  }
    /* global mass matrix B^t */
	  for (i=0; i<3*idof; i++) {
	    ig = 3*(pt->v[i % idof]-1) + (i / idof);
	    for (j=3*idof; j<3*idof+4; j++) {
	      if ( fabs(Me[i][j]) < ST_EPSA )  continue;
	      jg = nra + (pt->v[j % idof]-1);
        csrPut(M,ig,jg,Me[i][j]);
      }
    }
		/* penalization matrix S */
		for (i=3*idof; i<3*idof+4; i++) {
			ig = nra + pt->v[i % idof]-1;
			for (j=i; j<3*idof+4; j++) {
				jg = nra + pt->v[j % idof]-1;
				if ( ig < jg )
				  csrPut(M,ig,jg,Me[i][j]);
				else
					csrPut(M,jg,ig,Me[i][j]);
			}
		}
  }
  setTGV_3d(mesh,sol,M);
  csrPack(M);
  if ( abs(info.imprim) > 4 || info.ddebug )
    fprintf(stdout,"     M: %6d x %6d  nze %8d,  sparsity %7.4f%%\n",M->nr,M->nc,M->nbe,100.0*M->nbe/M->nr/M->nc);	
}

/* compute bubble value */
void updbub_3d(pMesh mesh,double *u) {
  pTetra   pt;
  double  *u1,*u2,*u3,*u4;
  int      k,ig;

  for (k=1; k<=mesh->ne; k++) {
    pt = &mesh->tetra[k];
    if ( !pt->v[0] )  continue;

    u1 = &u[3*(pt->v[0]-1)];
    u2 = &u[3*(pt->v[1]-1)];
    u3 = &u[3*(pt->v[2]-1)];
    u4 = &u[3*(pt->v[3]-1)];
    ig = 3*(mesh->np+k-1);
    u[ig+0] = 256*u1[0]*u2[0]*u3[0]*u4[0];
    u[ig+1] = 256*u1[1]*u2[1]*u3[1]*u4[1];
    u[ig+2] = 256*u1[2]*u2[2]*u3[2]*u4[2];
  }
}



