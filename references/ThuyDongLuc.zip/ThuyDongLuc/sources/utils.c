#include "stokes.h"

#define   A  ((5.0-sqrt(5.0))/20.0)     /* for P2 quadrature */


/* find all triangles sharing P
   in:  start: triangle containing p, ip: index of p in start
   out: list of triangles, 0,..,ilist-1 */
int boulep_2d(pMesh mesh,int start,int ip,int *list,char *open) {
  pTria    pt;
  int     *adja,iadr,ilist,iel;
  char     ii,i1,voy;

  pt = &mesh->tria[start];
  if ( !pt->v[0] )  return(0);
  list[0] = 3*start + ip;
  ilist = 1;
  *open = 0;
  iadr  = 3*(start-1) + 1;
  adja  = &mesh->adja[iadr];

  /* store neighbors */
  i1  = inxt[ip];
  iel = adja[i1] / 3;
  while ( iel && (iel != start) ) {
    pt  = &mesh->tria[iel]; 
    voy = adja[i1] % 3;
    i1  = iprv[voy];
    ii  = inxt[voy];
    if ( ilist > ST_LMAX2D-1 )  return(-ilist);
    list[ilist] = 3*iel + ii;
    ++ilist;
    iadr = 3*(iel-1) + 1;
    adja = &mesh->adja[iadr];
    iel  = adja[i1] / 3;
  }

  /* reverse loop */
  if ( iel != start ) {
    i1   = iprv[ip];
    iadr = 3*(start-1) + 1;
    adja = &mesh->adja[iadr];
    iel  = adja[i1] / 3;
    *open = 1;
    while ( iel && (iel != start) ) {
      pt  = &mesh->tria[iel];
      voy = adja[i1] % 3;
      i1  = inxt[voy];
      ii  = iprv[voy];
      if ( ilist > ST_LMAX2D-1 )  return(-ilist);
      list[ilist] = 3*iel + ii;
      ++ilist;
      iadr = 3*(iel-1) + 1;
      adja = &mesh->adja[iadr];
      iel  = adja[i1] / 3;
    }
  }

  return(ilist);
}

/* find boundary conds in list */
pCl getCl(pSol sol,int ref,int elt) {
  pCl     pcl;
  int     i;

  for (i=0; i<sol->nbcl; i++) {
    pcl = &sol->cl[i];
    if ( (pcl->ref == ref) && (pcl->elt == elt) )  return(pcl);
  }
  return(0);
}

/* retrieve physical properties in list */
int getMat(pSol sol,int ref,double *nu,double *rho) {
  pMat   pm;
  int    i;

  *nu  = ST_NU;
  *rho = ST_RHO;
  for (i=0; i<sol->nmat; i++) {
    pm = &sol->mat[i];
    if ( pm->ref == ref ) {
      *nu  = pm->nu;
      *rho = pm->rho;
      return(1);
    }
  }
  return(0);
}

/* triangle area */
double area_2d(double *a,double *b,double *c) {
  double    ux,uy,vx,vy,dd;

  ux = b[0] - a[0];
  uy = b[1] - a[1];
  vx = c[0] - a[0];
  vy = c[1] - a[1];
  dd = 0.5 * (ux*vy - uy*vx);
  return(dd);
}

/* tetrahedron volume */
double volu_3d(double *a,double *b,double *c,double *d) {
  double    bx,by,bz,cx,cy,cz,dx,dy,dz,vx,vy,vz,dd;

  bx  = b[0] - a[0];
  by  = b[1] - a[1];
  bz  = b[2] - a[2];
  cx  = c[0] - a[0];
  cy  = c[1] - a[1];
  cz  = c[2] - a[2];
  dx  = d[0] - a[0];
  dy  = d[1] - a[1];
  dz  = d[2] - a[2];
  
  /* test volume */
  vx  = cy*dz - cz*dy;
  vy  = cz*dx - cx*dz;
  vz  = cx*dy - cy*dx; 
  dd  = (bx*vx + by*vy + bz*vz) / 6.0;
  return(dd);
}

/* invert 3x3 non-symmetric matrix */
int invmatg(double m[9],double mi[9]) {
  double  aa,bb,cc,det,vmin,vmax,maxx;
  int     k;

  /* check ill-conditionned matrix */
  vmin = vmax = fabs(m[0]);
  for (k=1; k<9; k++) {
    maxx = fabs(m[k]);
    if ( maxx < vmin )  vmin = maxx;
    else if ( maxx > vmax )  vmax = maxx;
  }
  if ( vmax == 0.0 )  return(0);

  /* compute sub-dets */
  aa = m[4]*m[8] - m[5]*m[7];
  bb = m[5]*m[6] - m[3]*m[8];
  cc = m[3]*m[7] - m[4]*m[6];
  det = m[0]*aa + m[1]*bb + m[2]*cc;
  if ( fabs(det) < ST_EPSD )  return(0);
  det = 1.0 / det;

  mi[0] = aa*det;
  mi[3] = bb*det;
  mi[6] = cc*det;
  mi[1] = (m[2]*m[7] - m[1]*m[8])*det;
  mi[4] = (m[0]*m[8] - m[2]*m[6])*det;
  mi[7] = (m[1]*m[6] - m[0]*m[7])*det;
  mi[2] = (m[1]*m[5] - m[2]*m[4])*det;
  mi[5] = (m[2]*m[3] - m[0]*m[5])*det;
  mi[8] = (m[0]*m[4] - m[1]*m[3])*det;

  return(1);
}

/* compute normal to curve ref at point ip w/r edge reference ref */
int normal_2d(pMesh mesh,int ip,int ref,double *n) {
  pPoint   p[4],ppt;
  pTria    pt;
  double   n1[2],n2[2],dd;
  int     *adja,iel,start,ip1;
  char     i0,i1,voy,ni;

  p[0]  = &mesh->point[ip];
  start = p[0]->s;
  assert(start);
  pt   = &mesh->tria[start];

  /* index of vertex ip in triangle iel */
  for (i0=0; i0<3; i0++)
		if ( pt->v[i0] == ip )  break;
  assert(i0<3);
	voy = i0;
  i1  = inxt[i0];
  iel = start;
  ni  = 1;
  do {
    pt  = &mesh->tria[iel];
		ip1 = pt->v[i1];
		ppt = &mesh->point[ip1];
		if ( ppt->ref == ref ) {
			p[ni] = ppt;
			ni++;
      if ( ni == 3 )  break;
		}
	  adja = &mesh->adja[3*(iel-1)+1];
		iel  = adja[i1] / 3;
    voy  = adja[i1] % 3;
    i1   = iprv[voy];
  }
  while ( iel && (iel != start) );

  /* reverse loop */
  if ( iel != start ) {
		ppt = &mesh->point[voy];
		if ( ppt->ref == ref ) {
			p[ni] = ppt;
			ni++;
		}
		if ( ni < 3 ) {
      iel  = start;
      voy  = iprv[i0];
		  adja = &mesh->adja[3*(iel-1)+1];
      iel  = adja[voy] / 3;
			voy  = adja[voy] % 3;
      while ( iel ) {
      	pt  = &mesh->tria[iel];
				ip1 = pt->v[voy];
				ppt = &mesh->point[ip1];
				if ( ppt->ref == ref ) {
					p[ni] = ppt;
					ni++;
		      if ( ni == 3 )  break;
				}
				voy  = inxt[voy];
			  adja = &mesh->adja[3*(iel-1)+1];
	      iel  = adja[voy] / 3;
				voy  = adja[voy] % 3;
      }
    }
	}

  if ( ni < 2 )
		return(0);
  /* only one edge incident to ip */
  else if ( ni == 2 ) {
  	n[0] = p[0]->c[1] - p[1]->c[1];
    n[1] = p[1]->c[0] - p[0]->c[0];
  }
	else {
  	n1[0] = p[0]->c[1] - p[1]->c[1];
    n1[1] = p[1]->c[0] - p[0]->c[0];
		dd = sqrt(n1[0]*n1[0] + n1[1]*n1[1]);
	  if ( dd > ST_EPSA ) {
	    dd = 1.0 / dd;
	    n1[0] *= dd; 
	    n1[1] *= dd;
		}
	  n2[0] = p[1]->c[1] - p[2]->c[1];
	  n2[1] = p[2]->c[0] - p[1]->c[0];
		dd = sqrt(n2[0]*n2[0] + n2[1]*n2[1]);
	  if ( dd > ST_EPSA ) {
	    dd = 1.0 / dd;
	    n2[0] *= dd; 
	    n2[1] *= dd;
		}
		n[0] = n1[0] + n2[0];
		n[1] = n1[1] + n2[1];
  }
  dd = sqrt(n[0]*n[0] + n[1]*n[1]);
  if ( dd < ST_EPSA )  return(0);
  dd = 1.0 / dd;
  n[0] *= dd; 
  n[1] *= dd;

  return(1);
}

/* curvature approximation at point ip */
double kappa_2d(pMesh mesh,int ip,double *n,double *len) {
  pPoint   p0,p1,p2;
  pTria    pt,pt1;
  double   dd,ux,uy,vx,vy,k1,k2,dd1,dd2,nx,ny,kappa;
  int     *adja,k,adj,iad,ip1,ip2;
  char     i1;

  p0 = &mesh->point[ip];
  k  = p0->s;
  assert(k);

  pt   = &mesh->tria[k];
  iad  = 3*(k-1)+1;
  adja = &mesh->adja[iad];

  i1 = 1;
  if ( pt->v[1] == ip )       i1 = 2;
  else if ( pt->v[2] == ip )  i1 = 0;
  ip1 = pt->v[i1];
  p1  = &mesh->point[ip1];
  ip2 = 0;

  iad  = 3*(k-1)+1;
  adja = &mesh->adja[iad];
  adj  = adja[i1] / 3;
  pt1  = pt;
  while ( adj && adj != k ) {
    pt  = pt1;
    pt1 = &mesh->tria[adj];
    if ( pt1->ref != pt->ref ) {
      i1  = inxt[i1];
      ip2 = pt->v[i1];
      break;
    }
    i1   = adja[i1] % 3;
    i1   = iprv[i1];
    iad  = 3*(adj-1)+1;
    adja = &mesh->adja[iad];
    adj  = adja[i1] / 3;
  }
  p2 = &mesh->point[ip2];
  
  /* outer normal */
  ux = p1->c[0] - p0->c[0];
  uy = p1->c[1] - p0->c[1];
  if ( ip2 ) {
    vx = p2->c[0] - p0->c[0];
    vy = p2->c[1] - p0->c[1];
  }
  else {
    vx = vy = 0.0;
  }

  dd1  = sqrt(ux*ux + uy*uy);
  dd2  = sqrt(vx*vx + vy*vy);
  *len = dd1 + dd2;
  n[0] = uy - vy;
  n[1] = vx - ux;
  dd = sqrt(n[0]*n[0] + n[1]*n[1]);
  n[0] /= dd;
  n[1] /= dd;

  /* free interface (not closed) */
  if ( p2->ref != p0->ref || p1->ref != p0->ref ) {
    return(0.);
  }
  nx = ux / dd1 + vx / dd2;
  ny = uy / dd1 + vy / dd2;

  /* compute curvature */
  kappa = 0.0;
  if ( ip2 ) {
    dd1 = ux*n[0] + uy*n[1];
    dd2 = vx*n[0] + vy*n[1];
    if ( (fabs(dd1) > ST_EPSD) && (fabs(dd2) > ST_EPSD) ) {
      k1 = (ux*ux + uy*uy) / dd1;
      k2 = (vx*vx + vy*vy) / dd2;
      kappa = 4.0 / (k1+k2);
    }
  }
  return(kappa);
}

/* compute L^1,L^2 and L^\infty errors betwwen two solutions */
void errors_3d(pMesh mesh,int size,double *u1,double *u2,double *eli,double *el1,double *el2) {
  pTetra  pt;
  pPoint  p0,p1,p2,p3;
  double  d1,d2,d3,d4,errLi,errL1,errL2,vol;
  int     k,i0,i1,i2,i3;

  errLi = errL1 = errL2 = 0.0;

  /* Computation of L^\infty error */ 
  for (k=0; k<size; k++)
    errLi = ST_MAX(errLi,fabs(fabs(u1[k]) - u2[k]));

  /* Computation of L^1 and L^2 errors */
  for (k=1; k<=mesh->nt; k++) {
    pt = &mesh->tetra[k];
    if ( !pt->v[0] )  continue;
    i0 = pt->v[0];
    i1 = pt->v[1];
    i2 = pt->v[2];
    i3 = pt->v[3];

    /* measure of element */
    p0 = &mesh->point[i0];
    p1 = &mesh->point[i1];
    p2 = &mesh->point[i2];
    p3 = &mesh->point[i3];
		vol = volu_3d(p0->c,p1->c,p2->c,p3->c);

    /* Exact quadrature formula for \mathbb{P}^1 functions */
    i0 = 3*(i0-1);
    i1 = 3*(i1-1);
    i2 = 3*(i2-1);
		i3 = 3*(i3-1);
    errL1 += vol * fabs(u1[i0+0]-u2[i0+0] + u1[i1+0]-u2[i1+0] + u1[i2+0]-u2[i2+0] + u1[i3+0]-u2[i3+0]);  
    errL1 += vol * fabs(u1[i0+1]-u2[i0+1] + u1[i1+1]-u2[i1+1] + u1[i2+1]-u2[i2+1] + u1[i3+1]-u2[i3+1]);  

/*/ A VERIFIER --------------------------------------------/*/
    /* Exact quadrature formula for \mathbb{P}^2 functions */
    d1 = A*(u1[i0]-u2[i0] + u1[i1]-u2[i1] + u1[i2]-u2[i2]) + 1.0-3.0*A*(u1[i3]-u2[i3]); 
    d2 = A*(u1[i0]-u2[i0] + u1[i1]-u2[i1] + u1[i3]-u2[i3]) + 1.0-3.0*A*(u1[i2]-u2[i2]); 
    d3 = A*(u1[i0]-u2[i0] + u1[i2]-u2[i2] + u1[i3]-u2[i3]) + 1.0-3.0*A*(u1[i1]-u2[i1]); 
    d4 = A*(u1[i1]-u2[i1] + u1[i2]-u2[i2] + u1[i3]-u2[i3]) + 1.0-3.0*A*(u1[i0]-u2[i0]); 
    errL2 += vol / 4.0 * (d1*d1 + d2*d2 + d3*d3 + d4*d4);
  }
  *eli = errLi;
  *el1 = errL1;
  *el2 = sqrt(errL2);
}

/* compute L^1,L^2 and L^\infty errors betwwen two solutions */
void errors_2d(pMesh mesh,int size,double *u1,double *u2,double *eli,double *el1,double *el2) {
  pTria   pt;
  pPoint  p0,p1,p2;
  double  d1,d2,d3,errLi,errL1,errL2,area;
  int     k,i0,i1,i2;

  errLi = errL1 = errL2 = 0.0;

  /* Computation of L^\infty error */ 
  for (k=0; k<size; k++)
    errLi = ST_MAX(errLi,fabs(fabs(u1[k]) - u2[k]));

  /* Computation of L^1 and L^2 errors */
  for (k=1; k<=mesh->nt; k++) {
    pt = &mesh->tria[k];
    if ( !pt->v[0] )  continue;
    i0 = pt->v[0];
    i1 = pt->v[1];
    i2 = pt->v[2];

    /* measure of element */
    p0 = &mesh->point[i0];
    p1 = &mesh->point[i1];
    p2 = &mesh->point[i2];
  
    area = (p1->c[0]-p0->c[0])*(p2->c[1]-p0->c[1]) - (p1->c[1]-p0->c[1])*(p2->c[0]-p0->c[0]);
    area = 0.5 / 3.0 * fabs(area);

    /* Exact quadrature formula for \mathbb{P}^1 functions */
    i0 = 2*(i0-1);
    i1 = 2*(i1-1);
    i2 = 2*(i2-1);
    errL1 += area * fabs(u1[i0+0]-u2[i0+0] + u1[i1+0]-u2[i1+0] + u1[i2+0]-u2[i2+0]);  
    errL1 += area * fabs(u1[i0+1]-u2[i0+1] + u1[i1+1]-u2[i1+1] + u1[i2+1]-u2[i2+1]);  

    /* Exact quadrature formula for \mathbb{P}^2 functions */
    d1 = 0.5*(u1[i0]-u2[i0] + u1[i1]-u2[i1]);
    d2 = 0.5*(u1[i0]-u2[i0] + u1[i2]-u2[i2]);
    d3 = 0.5*(u1[i1]-u2[i1] + u1[i2]-u2[i2]);
    errL2 += area * (d1*d1 + d2*d2 + d3*d3);  
  }
  *eli = errLi;
  *el1 = errL1;
  *el2 = sqrt(errL2);
}
