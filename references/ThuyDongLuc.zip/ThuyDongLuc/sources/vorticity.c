#include "stokes.h"

extern Info  info;

/* right hand side for vorticity */
static double *rhsFv_P1_2d(pMesh mesh,pSol sol) {
  pTria    pt;
  pPoint   ppt;
  double  *F,*a,*b,*c,*u0,*u1,*u2,dd,x[3],y[3];
  int      k,ig;
  char     i;

  F = (double*)calloc(sol->np,sizeof(double));
  assert(F);

  for (k=1; k<=mesh->nt; k++) {
    pt = &mesh->tria[k];
    if ( !pt->v[0] )  continue;

    a = &mesh->point[pt->v[0]].c[0];
    b = &mesh->point[pt->v[1]].c[0];
    c = &mesh->point[pt->v[2]].c[0];
    x[0] = c[0] - b[0];  y[0] = b[1] - c[1];
    x[1] = a[0] - c[0];  y[1] = c[1] - a[1];
    x[2] = b[0] - a[0];  y[2] = a[1] - b[1];

    u0 = &sol->u[2*(pt->v[0]-1)+0];
    u1 = &sol->u[2*(pt->v[1]-1)+0];
    u2 = &sol->u[2*(pt->v[2]-1)+0];
    
    dd = u0[0]*x[0]+u1[0]*x[1]+u2[0]*x[2] - (u0[1]*y[0]+u1[1]*y[1]+u2[1]*y[2]);
    dd = dd / 6.0;
    for (i=0; i<3; i++) {
      ig = pt->v[i]-1;
      F[ig] += dd;
    }
  }
  /* set homogeneous boundary condition */
  for (k=1; k<=mesh->np; k++) {
    ppt = &mesh->point[k];
    if ( ppt->ref )  F[k-1] = 0.0;
  }
  return(F);
}

/* set TGV to diagonal coefficient when Dirichlet */
static void setTGVv_2d(pMesh mesh,pSol sol,pCsr A) {
  pPoint   ppt;
  int      k;

  for (k=1; k<=mesh->np; k++) {
    ppt = &mesh->point[k];
    if ( ppt->ref ) {
      csrSet(A,k-1,k-1,ST_TGV);
    }
  }
}

/* Laplacian matrix (for vorticity computation) */
static pCsr matLap_P1_2d(pMesh mesh,pSol sol) {
  pCsr     A;
  pTria    pt;
  double  *a,*b,*c,val,x[3],y[3],vol,ivo;
  int      i,j,k,ig,jg,nr,nc,nbe;

  if ( abs(info.imprim) > 4 || info.ddebug )
    fprintf(stdout,"\n     computing vorticity\n");

  /* memory allocation (rough estimate) */
  nr  = mesh->np;
  nc  = nr;
  nbe = 8*mesh->np;
  A   = csrNew(nr,nc,nbe,CS_UT+CS_SYM);

  /* store values in A */
  for (k=1; k<=mesh->nt; k++) {
    pt = &mesh->tria[k];
    if ( !pt->v[0] )  continue;

    /* measure of K */
    a  = &mesh->point[pt->v[0]].c[0]; 
    b  = &mesh->point[pt->v[1]].c[0]; 
    c  = &mesh->point[pt->v[2]].c[0]; 
    x[0] = c[0] - b[0];  y[0] = b[1] - c[1];
    x[1] = a[0] - c[0];  y[1] = c[1] - a[1];
    x[2] = b[0] - a[0];  y[2] = a[1] - b[1];
    vol  = 0.5 * (x[2]*y[1] - y[2]*x[1]);
    if ( vol < ST_EPSA )  vol = ST_EPSA;
    ivo = 1.0 / (4.0*vol);

    /* vertices */
    for (i=0; i<3; i++) {
      ig = pt->v[i]-1;
      for (j=0; j<3; j++) {
        jg  = pt->v[j]-1;
        if ( jg < ig )   continue; 
        val = ivo * (y[i]*y[j] + x[i]*x[j]);
        csrPut(A,ig,jg,val);
      }
    }
  }
  setTGVv_2d(mesh,sol,A);
  csrPack(A);
  if ( abs(info.imprim) > 4 || info.ddebug )
    fprintf(stdout,"     A: %6d x %6d  nze %8d,  sparsity %7.4f%%\n",nr,nc,A->nbe,100.0*A->nbe/nr/nc);
  return(A);
}

  /* compute vorticity: -Delta psi = \nabla \times u */
/*
if ( ier > 0 && info.ns ) {
    sol->u0 = (double*)calloc(sol->np,sizeof(double));
    assert(sol->u0);
    F = rhsFv_P1_2d(mesh,sol);
    A = matLap_P1_2d(mesh,sol);
    err = sol->err;
    nit = sol->nit;
    csrPrecondGrad(A,sol->u0,F,&err,&nit);
    free(F);
    saveVor(sol);
  }
*/