#include "stokes.h"
#include "compil.date"

Info  info;

static void excfun(int sigid) {
  fprintf(stdout,"\n Unexpected error:");  fflush(stdout);
  switch(sigid) {
    case SIGABRT:
      fprintf(stdout,"  Abnormal stop\n");  break;
    case SIGBUS:
      fprintf(stdout,"  Code error...\n");  break;
    case SIGFPE:
      fprintf(stdout,"  Floating-point exception\n"); break;
    case SIGILL:
      fprintf(stdout,"  Illegal instruction\n"); break;
    case SIGSEGV:
      fprintf(stdout,"  Segmentation fault.\n");  break;
    case SIGTERM:
    case SIGINT:
      fprintf(stdout,"  Programm killed.\n");  break;
  }
  fprintf(stdout," No data file saved.\n"); 
  exit(1);
}

static void usage(char *prog) {
  fprintf(stdout,"\n usage: %s [-v[n]] [-h] [opts..] filein[.mesh]\n",prog);
  
  fprintf(stdout,"\n** Generic options :\n");
  fprintf(stdout," -d      Turn on debug mode\n");
  fprintf(stdout," -h      Print this message\n");
  fprintf(stdout," -v [n]  Tune level of verbosity [-10,10]\n");
  fprintf(stdout," -ns     Navier-Stokes solver\n");
  fprintf(stdout," -t n    FE type: 1.P1bP1 (default), 2.P1P1st, 3.P2P1, 4.P2P2st\n");
  fprintf(stdout," -m n    Numerical method: 0.Single, 1.Uzawa (default), 2.Penalty, 3.Schur\n");

  fprintf(stdout,"\n**  File specifications\n");
  fprintf(stdout," -in  file  input triangulation\n");
  fprintf(stdout," -bc  file  boundary conditions\n");
  fprintf(stdout," -sol file  load initial solution\n");

  fprintf(stdout,"\n**  Parameters\n");
  fprintf(stdout," -dt step  time step\n");
  fprintf(stdout," -it n     number of time steps\n");
  fprintf(stdout," -mt n     max physical time\n");
  fprintf(stdout," -err e    accuracy (default: %E)\n",ST_RES);
  fprintf(stdout," -nit n    iterations for solving CG (default: %d)\n",ST_MAXIT);
  fprintf(stdout," -sav n    save solution after n time steps\n");
  fprintf(stdout," -cpu n    CPUs\n");

  exit(1);
}

static int parsar(int argc,char *argv[],pMesh mesh,pSol sol) {
  int      i;
  char    *ptr;

  i = 1;
  while ( i < argc ) {
    if ( *argv[i] == '-' ) {
      switch(argv[i][1]) {
      case 'h':  /* on-line help */
      case '?':
        usage(argv[0]);
        break;

      case 'b': /* boundary conditions given in file */
        if ( !strcmp(argv[i],"-bc") ) {
          ++i;
          sol->data = argv[i];
          ptr = strstr(sol->data,".sol");
          if ( !ptr )  strcat(sol->data,".sol");
        }
        break;
      case 'c':
        if ( !strcmp(argv[i],"-cpu") ) {
          ++i;
          if ( i == argc )
            fprintf(stderr,"  ** missing argument\n");
          else {
            if ( isdigit(argv[i][0]) )
              info.ncpu = atoi(argv[i]);
            else
              fprintf(stderr,"  ** argument [%s] discarded, use default: %d\n",argv[i],info.ncpu);
          }
        }
        break;
      case 'd':
        if ( !strcmp(argv[i],"-dt") ) {
          ++i;
          if ( i == argc )
            fprintf(stderr,"  ** missing argument\n");
          else {
            if ( isdigit(argv[i][0]) )
              info.dt   = atof(argv[i]);
            else
              fprintf(stderr,"  ** argument [%s] discarded, use default: %g\n",argv[i],info.dt);
          }
        }
        else
          info.ddebug = 1;
        break;
      case 'e':
        if ( !strcmp(argv[i],"-err") ) {
          ++i;
          if ( i == argc )
            fprintf(stderr,"  ** missing argument\n");
          else {
            if ( isdigit(argv[i][0]) )
              sol->err = atof(argv[i]);
            else
              fprintf(stderr,"  ** argument [%s] discarded, use default: %g\n",argv[i],sol->err); 
          }
        }
        break;
      case 'i':
        if ( !strcmp(argv[i],"-in") ) {
          ++i;
          mesh->name = argv[i];
        }
        else if ( !strcmp(argv[i],"-it") ) {
          ++i;
          if ( i == argc )
            fprintf(stderr,"  ** missing argument\n");
          else {
            if ( isdigit(argv[i][0]) )
              info.nit = atoi(argv[i]);
            else
              fprintf(stderr,"  ** argument [%s] discarded, use default: %d\n",argv[i],info.nit);
          }
        }
        break;
      case 'm':
        if ( !strcmp(argv[i],"-mt") ) {
          ++i;
          if ( i == argc )
            fprintf(stderr,"  ** missing argument\n");
          else {
            if ( isdigit(argv[i][0]) )
              info.maxtim = atof(argv[i]);
            else
              fprintf(stderr,"  ** argument [%s] discarded, use default: %f\n",argv[i],info.maxtim);
          }
        }
        else if ( !strcmp(argv[i],"-m") ) {
          ++i;
          if ( i == argc )
            fprintf(stderr,"  ** missing argument\n");
          else {
            if ( isdigit(argv[i][0]) )
              info.solver = atoi(argv[i]);
            else
              fprintf(stderr,"  ** argument [%s] discarded, use default: %d\n",argv[i],info.solver);
          }
        }
        break;
      case 'n':
        if ( !strcmp(argv[i],"-nit") ) {
          ++i;
          if ( i == argc )
            fprintf(stderr,"  ** missing argument\n");
          else {
            if ( isdigit(argv[i][0]) )
              sol->nit = atoi(argv[i]);
            else
              fprintf(stderr,"  ** argument [%s] discarded, use default: %d\n",argv[i],sol->nit);
          }
        }
        else if ( !strcmp(argv[i],"-ns") ) {
          info.ns = 1;
        }
        break;
      case 'o':
        if ( !strcmp(argv[i],"-out") ) {
          ++i;
          sol->nameout = argv[i];
        }
        break;
      case 's':
        if ( !strcmp(argv[i],"-sav") ) {
          ++i;
          if ( i < argc && isdigit(argv[i][0]) )
            info.sav = atoi(argv[i]);
          else
            i--;
        }
        else if ( !strcmp(argv[i],"-sol") ) {
          ++i;
          sol->namein = argv[i];
          ptr = strstr(sol->namein,".sol");
          if ( !ptr )  strcat(sol->namein,".sol");
        }
        break;
      case 't':
        if ( ++i < argc ) {
          if ( isdigit(argv[i][0]) )
            info.typ = atoi(argv[i]);
          else { 
            fprintf(stderr,"Missing argument option %c\n",argv[i-1][1]);
            usage(argv[0]);
            i--;
          }
        }
        else {
          fprintf(stderr,"Missing argument option %c\n",argv[i-1][1]);
          usage(argv[0]);
        }
        break;
      case 'v':
        if ( ++i < argc ) {
          if ( argv[i][0] == '-' || isdigit(argv[i][0]) )
            info.imprim = atoi(argv[i]);
          else 
            i--;
        }
        else {
          fprintf(stderr,"Missing argument option %c\n",argv[i-1][1]);
          usage(argv[0]);
        }
        break;

      default:
        fprintf(stderr,"  Unrecognized option %s\n",argv[i]);
        usage(argv[0]);
      }
    }
    else {
      if ( mesh->name == NULL ) {
        mesh->name = argv[i];
        if ( info.imprim == -99 )  info.imprim = 5;
      }
      else {
        fprintf(stdout,"  Argument %s ignored\n",argv[i]);
        usage(argv[0]);
      }
    }
    i++;
  }

  /* check file names */
  if ( info.imprim == -99 ) {
    fprintf(stdout,"\n  -- PRINT (0 10(advised) -10) ?\n");
    fflush(stdin);
    fscanf(stdin,"%d",&i);
    info.imprim = i;
  }

  if ( mesh->name == NULL ) {
    mesh->name = (char *)calloc(128,sizeof(char));
    assert(mesh->name);
    fprintf(stdout,"  -- FILE BASENAME ?\n");
    fflush(stdin); 
    fscanf(stdin,"%s",mesh->name);
  }
  if ( sol->nameout == NULL ) {
    sol->nameout = (char *)calloc(128,sizeof(char));
    assert(sol->nameout);
    strcpy(sol->nameout,mesh->name);
    ptr = strstr(sol->nameout,".mesh");
    if ( ptr ) *ptr = '\0';
    strcat(sol->nameout,".sol");
  }

  return(1);
}

static int parsop(pMesh mesh,pSol sol) {
  Cl         *pcl;
  Mat        *pm;
  float       fp1,fp2;
  int         i,j,ncld,ret;
  char       *ptr,buf[256],data[256];
  FILE       *in;

  /* check for parameter file */
  strcpy(data,mesh->name);
  ptr = strstr(data,".mesh");
  if ( ptr )  *ptr = '\0';
  strcat(data,".stokes");
  in = fopen(data,"r");
  if ( !in ) {
    sprintf(data,"%s","DEFAULT.stokes");
    in = fopen(data,"r");
    if ( !in )  return(1);
  }
  fprintf(stdout,"  %%%% %s OPENED\n",data);

  /* read flow parameters */
  sol->nbcl = 0;
  while ( !feof(in) ) {
    /* scan line */
    ret = fscanf(in,"%s",data);
    if ( !ret || feof(in) )  break;
    for (i=0; i<strlen(data); i++) data[i] = tolower(data[i]);

    /* check for condition type */
    if ( !strcmp(data,"dirichlet") || !strcmp(data,"neumann") ) {
      fscanf(in,"%d",&ncld);
      for (i=sol->nbcl; i<sol->nbcl+ncld; i++) {
        pcl = &sol->cl[i];
        if ( !strcmp(data,"dirichlet") )     pcl->typ = Dirichlet; 
        else if ( !strcmp(data,"neumann") )  pcl->typ = Neumann;
        else {
          fprintf(stdout,"  %%%% Unknown condition: %s\n",data);
          continue;
        }

        /* check for entity */
        fscanf(in,"%d %s ",&pcl->ref,buf);
        for (j=0; j<strlen(buf); j++)  buf[j] = tolower(buf[j]);
        if ( !strcmp(buf,"vertices") || !strcmp(buf,"vertex") )          pcl->elt = ST_Ver;
        else if ( !strcmp(buf,"edges") || !strcmp(buf,"edge") )          pcl->elt = ST_Edg;
        else if ( !strcmp(buf,"triangles") || !strcmp(buf,"triangle") )  pcl->elt = ST_Tri;
        else {
          fprintf(stdout,"  %%%% Wrong format: %s\n",buf);
          continue;
        }
				if ( info.ddebug )
          fprintf(stdout,"     found %s cond. on %d  %s\n",data,pcl->ref,buf);
        fscanf(in,"%c",&pcl->att);
        pcl->att = tolower(pcl->att);
        if ( pcl->att == 'v' ) {
          for (j=0; j<mesh->dim; j++) {
            fscanf(in,"%f ",&fp1);
            pcl->u[j] = fp1;
          }
        }
        else if ( pcl->att == 's' ) {
          fscanf(in,"%f %f",&fp1,&fp2);
          pcl->u[0] = fp1;
          pcl->u[1] = fp2;
        }
        else if ( pcl->att == 'p' ) {
          stokesCL = taylorgreen;
        }
        else if ( pcl->att == 'l' ) {
          fscanf(in,"%f ",&fp1);
          pcl->u[0] = fp1;
        }
      }
      sol->nbcl += ncld;
    }
		/* slip condition: normal component vanishes */
    else if ( !strcmp(data,"slip") ) {
      fscanf(in, "%d",&ncld);
      ///fscanf(in,"%d %f",&ncld,&fp1);
      ///pcl->u[0] = fp1;//alpha
      for (i=sol->nbcl; i<sol->nbcl+ncld; i++) {
        pcl = &sol->cl[i];
        pcl->typ = Slip;
        /* check for entity */
        fscanf(in,"%d %s ",&pcl->ref,buf);
				if ( info.ddebug )
          fprintf(stdout,"     found Slip cond. on %d  %s\n",pcl->ref,buf);
        for (j=0; j<strlen(buf); j++)  buf[j] = tolower(buf[j]);
        if ( !strcmp(buf,"vertices") || !strcmp(buf,"vertex") )          pcl->elt = ST_Ver;
        else if ( !strcmp(buf,"edges") || !strcmp(buf,"edge") )          pcl->elt = ST_Edg;
        else if ( !strcmp(buf,"triangles") || !strcmp(buf,"triangle") )  pcl->elt = ST_Tri;
        else {
          fprintf(stdout,"  %%%% Wrong format: %s\n",buf);
          continue;
        } 
			}
      sol->nbcl += ncld;
    }
	  
	  else if ( !strcmp(data,"symmetry") ) {
      fscanf(in, "%d",&ncld);
      for (i=sol->nbcl; i<sol->nbcl+ncld; i++) {
        pcl = &sol->cl[i];
        pcl->typ = Symmetry;
        /* check for entity */
        fscanf(in,"%d %s ",&pcl->ref,buf);
				if ( info.ddebug )
          fprintf(stdout,"     found Symmetry cond. on %d  %s\n",pcl->ref,buf);
        for (j=0; j<strlen(buf); j++)  buf[j] = tolower(buf[j]);
        if ( !strcmp(buf,"vertices") || !strcmp(buf,"vertex") )          pcl->elt = ST_Ver;
        else if ( !strcmp(buf,"edges") || !strcmp(buf,"edge") )          pcl->elt = ST_Edg;
        else if ( !strcmp(buf,"triangles") || !strcmp(buf,"triangle") )  pcl->elt = ST_Tri;
        else {
          fprintf(stdout,"  %%%% Wrong format: %s\n",buf);
          continue;
        } 
			}
      sol->nbcl += ncld;
    }
    
	  /* gravity or body force */
    else if ( !strcmp(data,"gravity") ) {
      info.load |= (1 << 0);
      for (j=0; j<sol->dim; j++) {
        fscanf(in,"%f ",&fp1);
        info.gr[j] = fp1;
      }
    }
    /* RHS body force */
    else if ( !strcmp(data,"load") ) {
      info.load |= (1 << 1);
      printf("--> for now analytical function... \n");
      /* to be implemented...*/
    }
    /* surface tension: ref + gamma */
    else if ( !strcmp(data,"tension") ) {
      pcl = &sol->cl[sol->nbcl];
      pcl->typ = Tension;
      pcl->elt = ST_SuTe;
      fscanf(in,"%d %f",&pcl->ref,&fp1);
      pcl->u[0] = fp1;
      sol->nbcl++;
			if ( info.ddebug )
        fprintf(stdout,"     found Tension cond. on %d  %f\n",pcl->ref,fp1);
    }
    /* flow coefficients */
    else if ( !strcmp(data,"domain") ) {
      fscanf(in,"%d",&ncld);
      sol->nmat = ncld;
      for (i=0; i<ncld; i++) {
        pm = &sol->mat[i];
        fscanf(in,"%d %f %f",&pm->ref,&fp1,&fp2);
        pm->nu  = fp1;
        pm->rho = fp2;
      }
    }
    else if ( !strcmp(data,"maxtime") ) {
      fscanf(in,"%f",&fp1);
      info.maxtim = fp1;
    }
  }
  fclose(in);

  for (i=0; i<sol->nbcl; i++) {
    pcl = &sol->cl[i];
    sol->cltyp |= pcl->elt;
  }

  if ( ! sol->nmat ) {
  	fprintf(stderr,"  %%%% Warning: no domain specified.\n");
		sol->nmat = 1;
		pm = &sol->mat[0];
		pm->nu  = ST_NU;
		pm->rho = ST_RHO;
  }
  return(1);
}

static void endcod() {
  char   stim[32];
  
  chrono(OFF,&info.ctim[0]);
  printim(info.ctim[0].gdif,stim);
  fprintf(stdout,"\n   ELAPSED TIME  %s\n",stim);
}

/* set function pointers */
static void setfunc(pSol sol) {
  if ( sol->dim == 2 ) {
    hashel = hashel_2d;
    hashar = hashar_2d;
    seedel = seedel_2d;
		rhside = rhside_2d;
		rhsTGV = rhsTGV_2d;
		rhsupd = rhsupd_2d;
		updbub = updbub_2d;
		advect = (info.typ < P2P1) ? advectRK4_P1_2d : advectRK4_P2_2d;
		assmat = (info.solver == Mono) ? matM_2d : matAB_2d;
  }
  else {
    hashel = hashel_3d;
    hashar = hashar_3d;
    seedel = seedel_3d;
		rhside = rhside_3d;
		rhsTGV = rhsTGV_3d;
		rhsupd = rhsupd_3d;
		updbub = updbub_3d;
		advect = (info.typ < P2P1) ? advectRK4_P1_3d : advectRK4_P2_3d;
		assmat = (info.solver == Mono) ? matM_3d : matAB_3d;
  }
}

/* set TGV to diagonal coefficient when Dirichlet */
/*
static int setTGVv_2d(pMesh mesh,pSol sol,pCsr A) {
  pPoint   ppt;
  int      k;

  for (k=1; k<=mesh->np; k++) {
    ppt = &mesh->point[k];
    if ( ppt->ref ) {
      csrSet(A,k-1,k-1,ST_TGV);
    }
  }
}
*/
/*
// Laplacian matrix (for vorticity computation)
static pCsr matLap_P1_2d(pMesh mesh,pSol sol) {
  pCsr     A;
  pTria    pt;
  double  *a,*b,*c,val,x[3],y[3],vol,ivo;
  int      i,j,k,ig,jg,nr,nc,nbe;

  if ( abs(info.imprim) > 4 || info.ddebug )
		fprintf(stdout,"\n     computing vorticity\n");
		
  //memory allocation (rough estimate)
  nr  = mesh->np;
  nc  = nr;
  nbe = 8*mesh->np;
  A   = csrNew(nr,nc,nbe,CS_UT+CS_SYM);

  //store values in A
  for (k=1; k<=mesh->nt; k++) {
    pt = &mesh->tria[k];
    if ( !pt->v[0] )  continue;

    //measure of K
    a  = &mesh->point[pt->v[0]].c[0]; 
    b  = &mesh->point[pt->v[1]].c[0]; 
    c  = &mesh->point[pt->v[2]].c[0]; 
    x[0] = c[0] - b[0];  y[0] = b[1] - c[1];
    x[1] = a[0] - c[0];  y[1] = c[1] - a[1];
    x[2] = b[0] - a[0];  y[2] = a[1] - b[1];
    vol  = 0.5 * (x[2]*y[1] - y[2]*x[1]);
    if ( vol < ST_EPSA )  vol = ST_EPSA;
    ivo = 1.0 / (4.0*vol);

    //vertices
    for (i=0; i<3; i++) {
      ig = pt->v[i]-1;
      for (j=0; j<3; j++) {
        jg  = pt->v[j]-1;
        if ( jg < ig )   continue; 
        val = ivo * (y[i]*y[j] + x[i]*x[j]);
        csrPut(A,ig,jg,val);
      }
    }
  }
  setTGVv_2d(mesh,sol,A);
  csrPack(A);
  if ( abs(info.imprim) > 4 || info.ddebug )
    fprintf(stdout,"     A: %6d x %6d  nze %8d,  sparsity %7.4f%%\n",nr,nc,A->nbe,100.0*A->nbe/nr/nc);
  return(A);
}
*/
/*
static double *rhsFv_P1_2d(pMesh mesh,pSol sol) {
  pTria    pt;
	pPoint   ppt;
  double  *F,*a,*b,*c,*u0,*u1,*u2,dd,x[3],y[3];
  int      k,ig;
	char     i;

  F = (double*)calloc(sol->np,sizeof(double));
  assert(F);

  for (k=1; k<=mesh->nt; k++) {
    pt = &mesh->tria[k];
    if ( !pt->v[0] )  continue;

    a = &mesh->point[pt->v[0]].c[0];
    b = &mesh->point[pt->v[1]].c[0];
    c = &mesh->point[pt->v[2]].c[0];
    x[0] = c[0] - b[0];  y[0] = b[1] - c[1];
    x[1] = a[0] - c[0];  y[1] = c[1] - a[1];
    x[2] = b[0] - a[0];  y[2] = a[1] - b[1];

    u0 = &sol->u[2*(pt->v[0]-1)+0];
    u1 = &sol->u[2*(pt->v[1]-1)+0];
    u2 = &sol->u[2*(pt->v[2]-1)+0];
    
		dd = u0[0]*x[0]+u1[0]*x[1]+u2[0]*x[2] - (u0[1]*y[0]+u1[1]*y[1]+u2[1]*y[2]);
		dd = dd / 6.0;
    for (i=0; i<3; i++) {
			ig = pt->v[i]-1;
			F[ig] += dd;
    }
  }

  //set homogeneous boundary condition
	for (k=1; k<=mesh->np; k++) {
		ppt = &mesh->point[k];
	  if ( ppt->ref )  F[k-1] = 0.0;
	}
  return(F);
}
*/

/* standard (un)steady [Navier-]Stokes */
static int stokes1(pMesh mesh,pSol sol) {
  Csr      A,B,S;
	pCsr     Av;
  double  *F,*Fk,err,li,l1,l2,res,*Fv;
  int      ier,it,jt,nit,ne,sizf,sizu,sizp;
  char     stim[32],verb,evl;
  static char fem[5][8] = {"P1P1", "P1bP1", "P1P1st", "P2P1", "P2P2st"};
  static char met[4][8] = {"Mono", "Uzawa", "Penalty", "Schur"};

  /* setup parameters */
  if ( (info.maxtim < 0.1*ST_TGV) || info.nit ) {
    if ( info.dt < 0.0 )  info.dt   = 17 * info.hmin;
    info.step = info.step * info.hmin;
    info.step = ST_MIN(info.step,0.5*info.dt);
    if ( !info.nit ) {
      info.nit = (int)(info.maxtim / info.dt);
      info.dt  = info.maxtim / info.nit;
    }
    else {
      info.maxtim = info.nit * info.dt;
    }
  }

  if ( abs(info.imprim) > 4 ) {
    fprintf(stdout,"  ** %s: %s PROBLEM\n",
      info.ns ? "NAVIER-STOKES" : "STOKES",info.nit > 0 ? "UNSTEADY" : "STEADY-STATE");
    if ( info.nit > 0 )
      fprintf(stdout,"     Phys.Time: %6.2f   Dt: %7.4f   iter: %5d   hmin: %7.4f\n",
              info.maxtim,info.dt,info.nit,info.hmin);  
    fprintf(stdout,"  1.1 ASSEMBLY\n");
  }

  /* -- Part I: matrix assembly */
  chrono(ON,&info.ctim[3]);
  if ( abs(info.imprim) > 4 )  fprintf(stdout,"     Assembly FE matrices: %s\n",fem[info.typ]);

  sol->dim = mesh->dim;
  sol->ver = mesh->ver;
  sol->np  = mesh->np;
  sol->ne  = sol->na = 0;

	ne = mesh->dim == 2 ? mesh->nt : mesh->ne;
  if ( info.typ < P2P1 ) {
    sizu = info.typ == P1bP1 ? mesh->dim*(mesh->np+ne) : mesh->dim*mesh->np;
    sizp = mesh->np;
  }
  else {
    sizu = mesh->dim*(mesh->np+mesh->na);
    sizp = mesh->np;
  }
	sizf = (info.solver == Mono) ? sizu+sizp : sizu;

  /* right-hand side */
	F = (double*)calloc(sizf,sizeof(double));
	assert(F);
  rhside(mesh,sol,F);
  
  
  //vorticity
  Fv = (double*)calloc(mesh->dim*mesh->np,sizeof(double));
	Av = 0;
	
  /* build matrices */
  assmat(mesh,sol,&A,&B);

  /* steady-state: free mesh + boundary conditions */
  if ( info.dt < 0 ) {
    rhsTGV(mesh,sol,F);
    if ( mesh->nai )  free(mesh->edge); 
    mesh->nai = 0;
    if ( sol->bc )  free(sol->bc);
  }

  /* memory for velocity and pressure */
  if ( info.solver == Mono ) {
	  sol->u = (double*)calloc(sizf,sizeof(double));
	  assert(sol->u);
  	sol->p = &sol->u[sizu];
  }
  else {
	  sol->u = (double*)calloc(sizu,sizeof(double));
	  assert(sol->u);
	  sol->p = (double*)calloc(sizp,sizeof(double));
    assert(sol->p);
  } 
  /* initial (given) velocity+pressure */
  if ( sol->u0 ) {
    if ( info.typ == P1bP1 ) {
      if ( sol->ne == 0 ) {
        sol->u0 = realloc(sol->u0,mesh->dim*(mesh->np+ne)*sizeof(double));
        sol->ne = ne;
      }
      updbub(mesh,sol->u0);
    }
    memcpy(sol->u,sol->u0,sizu*sizeof(double));
    if ( info.nit > 0 )
      memset(sol->u0,0,sizu*sizeof(double));
    else {
      free(sol->u0);
      sol->u0 = 0;
    }
  }
  else if ( info.nit > 0 ) {
    sol->u0 = (double*)calloc(sizu,sizeof(double));
    assert(sol->u0);
  }
  if ( sol->p0 ) {
    memcpy(sol->p,sol->p0,sizp*sizeof(double));
    free(sol->p0);
    sol->p0 = 0;
  }
  chrono(OFF,&info.ctim[3]);
  printim(info.ctim[3].gdif,stim);
  if ( abs(info.imprim) > 4 )  fprintf(stdout,"     [Time: %s]\n",stim);

  /* -- Part II: solving */
  chrono(ON,&info.ctim[4]);
  if ( abs(info.imprim) > 4 )  fprintf(stdout,"  1.2 SOLVING (%s)\n",met[info.solver]);

  if ( info.ncpu > 1 )  csrInit(info.ncpu);
  err = sol->err;
  nit = sol->nit;
  ier = 0;

  /* 1.2.a steady state case */
  if ( info.dt < 0 ) {
    if ( info.solver == Mono ) {
			ier = csrPrecondGrad(&A,sol->u,F,&err,&nit,1);
	    if ( abs(info.imprim) > 4 )
	      fprintf(stdout,"     -> Velocity+pressure: err %E   it %d\n",err,nit);
		}
	  else if ( info.solver == Penalty )
      ier = ST_Penalty(mesh,sol,&A,&B,F,&err,&nit);
    else {
      ier = ST_Uzawa(mesh,sol,&A,&B,&S,F,&err,&nit);
    }
  }

  /* 1.2.b unsteady case */
  else {
    /* memory for RHS and residual */
    Fk = (double*)calloc(sizf,sizeof(double));
    assert(Fk);
    verb = info.imprim;

    it  = jt = 0;
    res = 1.0;
    evl = info.nit > 50 ? 2 : 1;
   while ( (++it <= info.nit) && (res > ST_CVG) ) {
	  //while ( (++it <= info.nit) && (res > 1.e-4) ) {
      sol->time += info.dt;
      if ( abs(info.imprim) > 4 )
        fprintf(stdout,"   [%3d/%3d]   time %.2f   dt %.3f\n",it,info.nit,sol->time,info.dt);
      else {
        fprintf(stdout,"   [%3d/%3d]   time %.2f   dt %.3f   res %e\r",it,info.nit,sol->time,info.dt,res);
        fflush(stdout);
      }
      /* save solution u^n in u0 */
      memcpy(sol->u0,sol->u,sizu*sizeof(double));
      /* discretisation of total derivative u_t + u\nabla u */ 
      if ( info.ns ) {  
        ier = advect(mesh,sol);
        if ( !ier )  break;
      }   
      /* update Fk = F + 1.0/dt * u^n(X^n(x)) */
      memcpy(Fk,F,sizf*sizeof(double));
      rhsupd(mesh,sol,Fk);
      rhsTGV(mesh,sol,Fk);
      /* solve Stokes, init using u^{n} */
      err = sol->err;
      nit = sol->nit;
      if ( info.solver == Mono ) {
				memset(sol->u,0,sizu*sizeof(double));
				//memset(sol->u,sol->u0,sizu*sizeof(double));
				///ier = csrPrecondGrad(&A,sol->u,Fk,&err,&nit,1);
				ier = csrConjGrad(&A,sol->u,Fk,&err,&nit);
				//int csrGMRES(pCsr A,double *x,double *b,double *er,int *ni,int krylov,int prec)
				//ier = csrGMRES(&A,sol->u,Fk,&err,&nit,1,0);
	      if ( abs(info.imprim) > 4 )
	        fprintf(stdout,"     -> Velocity+pressure: err %E   it %d\n",err,nit);
			}
			else if ( info.solver == Penalty ) {
	      memcpy(sol->u,sol->u0,sizu*sizeof(double));
        ier = ST_Penalty(mesh,sol,&A,&B,Fk,&err,&nit);
			}
      else {
	      memcpy(sol->u,sol->u0,sizu*sizeof(double));
        ier = ST_Uzawa(mesh,sol,&A,&B,&S,Fk,&err,&nit);
			}
      if ( ier < 1 )  break;
      /* evaluate residual: u^{n+1}s-u^n */
      if ( (it % evl == 0) || (it == info.nit) ) {
        errors_2d(mesh,sizu,sol->u,sol->u0,&li,&l1,&l2);
        res = l2;
        if ( abs(info.imprim) > 4 )  fprintf(stdout,"     residual %e\n",res);
      }
      /* save current solution */
      if ( (info.sav > 0) && (it % info.sav == 0) )
        saveIt(sol,++jt);
    }
    free(Fk);    
    
    /*
    fprintf(stdout,"  calcul the exact solution at time %E\n",sol->time);
    for (i=1; i<=mesh->np; i++) {
      ppt = &mesh->point[i];
      sol->u0[mesh->dim*(i-1)+0] = -cos(ppt->c[0])*sin(ppt->c[1])*exp(-2*sol->time);
      sol->u0[mesh->dim*(i-1)+1] = cos(ppt->c[1])*sin(ppt->c[0])*exp(-2*sol->time);
      //sol.p[i-1] = -0.25*(cos(2*ppt->c[1])+cos(2*ppt->c[0]))*exp(-4*0.1*10); 
    }
    */
    /* evaluate residual: u^{n+1}s-u^n */
    /*
    if ( (it % evl == 0) || (it == info.nit) ) {
      errors_2d(mesh,sizu,sol->u,sol->u0,&li,&l1,&l2);
      res = l2;
      if ( abs(info.imprim) > 4 )  fprintf(stdout,"     err_L2 %e\n",res);
    }
    */
    info.imprim = verb;
  }
  if  ( info.ncpu > 1 )  csrStop();
  if ( ier < 1 )  fprintf(stdout,"  ## SOL NOT CONVERGED: ier= %d\n",ier);
  
	  /* compute vorticity: -Delta psi = \nabla \times u */
/*	 
	  if ( ier > 0 && info.ns ) {
		  //setBC_P1_2d(mesh,sol,&hash);
	    sol->u0 = (double*)calloc(sol->np,sizeof(double));
	    assert(sol->u0);
	    Fv = rhsFv_P1_2d(mesh,sol);
	    Av = matLap_P1_2d(mesh,sol);
	    err = sol->err;
	    nit = sol->nit;
	    csrPrecondGrad(Av,sol->u0,Fv,&err,&nit,0);
	    free(Fv);
	    saveVor(sol);
	  }
*/	
  /* free memory */
  free(F);
  if ( sol->u0 ) {
    free(sol->u0);
    sol->u0 = 0;
  }
  chrono(OFF,&info.ctim[4]);
  printim(info.ctim[4].gdif,stim);
  if ( abs(info.imprim) > 4 )
    fprintf(stdout,"     [Time: %s]\n",stim);

  return(ier > 0);
}

int main(int argc,char *argv[]) {
  Mesh      mesh;
  Sol       sol;
  int       ier;
  char      stim[32];

  fprintf(stdout,"  -- STOKES, Release %s (%s) \n",ST_VER,ST_REL);
  fprintf(stdout,"     %s\n",ST_CPY);
  fprintf(stdout,"    %s\n",COMPIL);

  /* interrupts */
  signal(SIGABRT,excfun);
  signal(SIGFPE,excfun);
  signal(SIGILL,excfun);
  signal(SIGSEGV,excfun);
  signal(SIGTERM,excfun);
  signal(SIGINT,excfun);
  signal(SIGBUS,excfun);
  atexit(endcod);

  tminit(info.ctim,TIMEMAX);
  chrono(ON,&info.ctim[0]);

  /* default values */
  memset(&mesh,0,sizeof(Mesh));
  memset(&sol,0,sizeof(Sol));
  sol.cl  = (Cl*)calloc(ST_CL,sizeof(Cl));
  sol.mat = (Mat*)calloc(ST_MAT,sizeof(Mat));
  sol.err = ST_RES;
  sol.nit = ST_MAXIT;

  info.imprim = -99;
  info.ddebug = 0;
  info.rhs    = 0;
  info.maxtim = ST_TGV;
  info.step   = 0.01;
  //info.step   = 0.001;
  info.dt     = -1;
  info.nit    = 0;        /* steady-state */
  info.ns     = 0;        /* 0.Stokes, 1.Navier-Stokes */
  info.ncpu   = 1;
  info.sav    = 0;        /* no temp saving */
  info.typ    = P1bP1;    /* mini element */
  info.solver = Uzawa;

  /* command line */
  if ( !parsar(argc,argv,&mesh,&sol) )  return(1);

  /* load data (initial sol, boundary conditions) */
  fprintf(stdout,"\n  -- INPUT DATA\n");
  chrono(ON,&info.ctim[1]);
  if ( !loadMesh(&mesh) )  return(1);
  ier = loadSol(&sol);
  if ( !ier )
    return(1);
  else if ( ier > 0 && sol.np != mesh.np ) {
    fprintf(stdout,"  ## WARNING: WRONG SOLUTION NUMBER. IGNORED\n");
    free(sol.u0);
    sol.np = sol.ne = 0;
  }
  ier = loadBC(&sol);
  if ( !ier )
    return(1);
  else if ( ier > 0 && sol.np != mesh.np ) {
    fprintf(stdout,"  ## WARNING: WRONG SOLUTION NUMBER. IGNORED\n");
    free(sol.bc);
    sol.np = sol.ne = 0;
  }
  if ( !sol.dim )  sol.dim = mesh.dim;
  if ( !parsop(&mesh,&sol) )     return(1);
  if ( !scaleMesh(&mesh,&sol) )  return(1);
  chrono(OFF,&info.ctim[1]);
  printim(info.ctim[1].gdif,stim);
  fprintf(stdout,"  -- DATA READING COMPLETED.     %s\n",stim);

  /* resolution */
  chrono(ON,&info.ctim[2]);
  setfunc(&sol);
  fprintf(stdout,"\n  %s\n   MODULE STOKES-LJLL : %s (%s)\n  %s\n",ST_STR,ST_VER,ST_REL,ST_STR);
  if ( info.imprim )   fprintf(stdout,"\n  -- PHASE 1 : SOLVING\n");
  if ( !hashel(&mesh) )        return(1);
  if ( !seedel(&mesh,&sol) )   return(1);
  if ( !hashar(&mesh) )        return(1);
  if ( !stokes1(&mesh,&sol) )  return(1);
  chrono(OFF,&info.ctim[2]);
  printim(info.ctim[2].gdif,stim);
  if ( info.imprim )  fprintf(stdout,"  -- PHASE 1 COMPLETED.     %s\n",stim);
  fprintf(stdout,"\n  %s\n   END OF MODULE STOKES \n  %s\n",ST_STR,ST_STR);

  /* save file */
  if ( info.imprim )  fprintf(stdout,"\n  -- WRITING DATA FILE %s\n",sol.nameout);
  chrono(ON,&info.ctim[1]);
  if ( !saveSol(&sol) )      return(1);
  //ghiaProf(&mesh,&sol);
  chrono(OFF,&info.ctim[1]);
  if ( info.imprim )  fprintf(stdout,"  -- WRITING COMPLETED\n");

  /* free mem */
  if ( mesh.adja )   free(mesh.adja);
  if ( mesh.tria )   free(mesh.tria);
  if ( mesh.point )  free(mesh.point);
  if ( sol.u )  free(sol.u);
  if ( sol.p && info.solver > Mono )  free(sol.p);

  return(0);
}

