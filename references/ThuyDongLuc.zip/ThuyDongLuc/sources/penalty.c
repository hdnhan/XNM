#include "stokes.h"

extern Info  info;

/* Penalization method for solving ( A    B ) ( U ) = ( F )
                                   ( Bt -eI ) ( P ) = ( 0 )
   solve (A + 1/e BB^t) U = F and then P = 1/e B^t U 
   here matrix A = (A - 1/e B^tB) */
int ST_Penalty(pMesh mesh,pSol sol,pCsr A,pCsr B,double *F,double *er,int *ni) {
  double  *u,*p,err,eps;
  int      k,nit,ier;

  u = sol->u;
  p = sol->p;

  /*--- 1. solve for u:  U = (A+1/e B^tB)^-1 F */
  if ( abs(info.imprim) > 5 )  fprintf(stdout,"     Compute (A+1/e B^tB) U = C U = F\n");
  err = *er;
  nit = *ni;
  ///ier = csrPrecondGrad(A,u,F,&err,&nit,1);
  ier = csrConjGrad(A,u,F,&err,&nit);
  *er = err;
  *ni = nit;
  if ( ier < 1 ) {
    fprintf(stdout,"  ## Incomplete CG for (A+1/e B^tB)^-1.F: err %E   nit %d\n",err,nit);
    return(0);
  }

  /*--- 2. solve P = -1/e B U */
  csrAx(B,u,p);
  eps = 1.0 / (info.hmin * 0.001);
  for (k=0; k<B->nr; k++)  p[k] *= eps; 	

  if ( abs(info.imprim) > 4 )
    fprintf(stdout,"     -> Velocity+pressure: err %E   it %d\n",err,nit);

  return(1);
}


