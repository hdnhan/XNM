#include "stokes.h"

extern Info  info;

// barycentric coordinates of point c[] in iel=p0,p1,p2
static inline int bar_2d(pPoint pp[3],double *c,int iel,double *cb) {
  double    det;
  char      i,i1,i2;

  det = (pp[1]->c[0] - pp[0]->c[0]) * (pp[2]->c[1] - pp[0]->c[1])
      - (pp[1]->c[1] - pp[0]->c[1]) * (pp[2]->c[0] - pp[0]->c[0]);
  if ( fabs(det) < ST_EPSA )  return(0);
  det = 1.0 / det;

  /* barycentric coordinate, by use of Cramer's formulas */
  for (i=0; i<2; i++) {
    i1 = inxt[i];
    i2 = iprv[i];
    cb[i] = (pp[i1]->c[0]-c[0])*(pp[i2]->c[1]-c[1]) - (pp[i1]->c[1]-c[1])*(pp[i2]->c[0]-c[0]);
    cb[i] *= det;
  }
  cb[2] = 1.0 - cb[0] - cb[1];
  return(1);
}

//find local point (saved in *cloc) corresponds global point (*c) containing in triangle (*x,*y,*z) 
//by the iterative method of Newton: cl_(n+1) = cl_n - (JaF)^-1*F_n
static int ptloc_2d(double *x,double *y,double *z,double *c,double *cloc) {
	double  InJa[2][2],JaF[2][2],F[2],er,cc[2],cl[2],co[2],s,s1,s2,detJa,nn,a[6],b[6],ph[6],dp[2][6];
  int     i,it;  
  
	s = area_2d(x,y,z);
	if (s<1.e-200) return(0);
	s1 = area_2d(z,x,c);
	s2 = area_2d(x,y,c);
  //initiation of cl 
	cl[0]=s1/s;
	cl[1]=s2/s;
	//P2_local functions
	ph[0] = (1-cl[0]-cl[1])*(1-2*cl[0]-2*cl[1]);
	ph[1] = cl[0]*(2*cl[0]-1);
	ph[2] = cl[1]*(2*cl[1]-1);
  ph[3] = 4*cl[0]*(1-cl[0]-cl[1]);
	ph[4] = 4*cl[0]*cl[1];
	ph[5] = 4*cl[1]*(1-cl[0]-cl[1]);
	//global coordinate of dof
	a[0] = x[0]; a[3] = (x[0]+y[0])/2;  b[0] = x[1]; b[3] = (x[1]+y[1])/2; 
	a[1] = y[0]; a[4] = (y[0]+z[0])/2;  b[1] = y[1]; b[4] = (y[1]+z[1])/2;
	a[2] = z[0]; a[5] = (z[0]+x[0])/2;  b[2] = z[1]; b[5] = (z[1]+x[1])/2;
	//F_n
	F[0] = F[1] = 0.;
	for (i=0; i<6; i++) {
		F[0] += a[i]*ph[i];
	  F[1] += b[i]*ph[i];
	}
	F[0] -= c[0];
	F[1] -= c[1];
	//er_n
	er = F[0]*F[0]+F[1]*F[1];
	
//fprintf(stdout, "er1=%E\n", er);
//fprintf(stdout, "F[0]=%E,F[1]=%E\n",F[0],F[1]);
	it = 0;
  while ( (er > 1e-7) && (++it <= 200) ) {
//fprintf(stdout, "-----------cl[0]=%E,cl[1]=%E\n",cl[0],cl[1]);
    //dp
		dp[0][0] = 4*(cl[0]+cl[1])-3;      dp[1][0] = 4*(cl[0]+cl[1])-3;
		dp[0][1] = 4*cl[0]-1;              dp[1][1] = 0;
		dp[0][2] = 0;                      dp[1][2] = 4*cl[1]-1;
		dp[0][3] = 4*(1-2*cl[0]-cl[1]);    dp[1][3] = -4*cl[0];
		dp[0][4] = 4*cl[1];                dp[1][4] = 4*cl[0];
		dp[0][5] = -4*cl[1];               dp[1][5] = 4*(1-cl[0]-2*cl[1]);
    // Jacobien of F
		for (i=0; i<6; i++) {
		  JaF[0][0] += a[i]*dp[0][i];      JaF[1][0] += a[i]*dp[1][i];
	    JaF[0][1] += b[i]*dp[0][i];      JaF[1][0] += b[i]*dp[1][i];
	  }
		//cl_n is save in co
		co[0] = cl[0]; co[1] = cl[1];
		
		// Compute cc_n = JaF^_1*F_n
		detJa     = JaF[0][0]*JaF[1][1] - JaF[0][1]*JaF[1][0];	
		//if (fabs(detJa) < 1.e-200) return(0);
		InJa[0][0]= JaF[1][1]/detJa;  InJa[0][1]= -JaF[1][0]/detJa; 
		InJa[1][0]= -JaF[0][1]/detJa; InJa[1][1]= JaF[0][0]/detJa;
		cc[0]     = InJa[0][0]*F[0] + InJa[0][1]*F[1];
		cc[1]     = InJa[1][0]*F[0] + InJa[1][1]*F[1];
//fprintf(stdout, "cc[0]=%E,cc[1]=%E\n",cc[0],cc[1]);

		//cl_(n+1) = cl_n- JaF^-1.F_n
		cl[0] -= cc[0];
		cl[1] -= cc[1];
		
		if ((cl[0]<-1.e-200)||(cl[0]>1.+1.e-200)) {cl[0]=co[0];cl[1]=co[1]; break;}
		if ((cl[1]<-1.e-200)||(cl[1]>1.+1.e-200)) {cl[1]=co[1];cl[0]=co[0]; break;}
		if (cl[1]+cl[0]>1.+1.e-200) {cl[1]=co[1];cl[0]=co[0]; break;}
//fprintf(stdout, "cl[0]=%E,cl[1]=%E\n",cl[0],cl[1]);
   	//ph_(n+1)
		  ph[0] = (1-cl[0]-cl[1])*(1-2*cl[0]-2*cl[1]);
		  ph[1] = cl[0]*(2*cl[0]-1);
		  ph[2] = cl[1]*(2*cl[1]-1);
	  	ph[3] = 4*cl[0]*(1-cl[0]-cl[1]);
		  ph[4] = 4*cl[0]*cl[1];
		  ph[5] = 4*cl[1]*(1-cl[0]-cl[1]);
		//F_(n+1)
			F[0] = F[1] = 0.;
			for (i=0; i<6; i++) {
		    F[0] += a[i]*ph[i];
	      F[1] += b[i]*ph[i];
	    }
	    F[0] -= c[0];
	    F[1] -= c[1];
	  //er_(n+1)  
	  	er = F[0]*F[0]+F[1]*F[1];
//fprintf(stdout, "F[0]=%E,F[1]=%E\n",F[0],F[1]);
//fprintf(stdout, "er2=%E\n", er);
  }		
	cloc[0]=cl[0];
	cloc[1]=cl[1];
//fprintf(stdout, "---------cloc[0]=%E,cloc[1]=%E\n",cloc[0],cloc[1]);
  return(1);
}


static int ptlocGC_2d(double *x,double *y,double *z,double *c,double *cloc) {
	double  JaF[2][2],F[2],r[2],ap[2],p[2],dp,nn,rm,rmp,rmn,alpha,beta,err,er,cc[2],cl[2];
  int     it,itg,ier,nit;  
  //F(cl_n);
	cl[0]=cl[1]=0.;
	F[0] = x[0]*cl[0]*(2*cl[0]-1) + y[0]*cl[1]*(2*cl[1]-1) + z[0]*(1-cl[0]-cl[1])*(1-2*cl[0]-2*cl[1])
		+ (x[0]+y[0])*2*cl[0]*cl[1] + (z[0]+y[0])*2*cl[1]*(1-cl[0]-cl[1]) + (x[0]+z[0])*2*cl[0]*(1-cl[0]-cl[1]) - c[0];
	F[1] = x[1]*cl[0]*(2*cl[0]-1) + y[1]*cl[1]*(2*cl[1]-1) + z[1]*(1-cl[0]-cl[1])*(1-2*cl[0]-2*cl[1])
		+ (x[1]+y[1])*2*cl[0]*cl[1] + (z[1]+y[1])*2*cl[1]*(1-cl[0]-cl[1]) + (x[1]+z[1])*2*cl[0]*(1-cl[0]-cl[1]) - c[1];
	er = F[0]*F[0]+F[1]*F[1];
	itg = 0;
  while ( (er > 1e-7) && (++itg <= 200) ) {	
		//JaF(cl_n);
		JaF[0][0] = x[0]*(4*cl[0]-1) + 0 + z[0]*(4*(cl[0]+cl[1])-3) + (x[0]+y[0])*2*cl[1] + (z[0]+y[0])*(-2*cl[1]) + (x[0]+z[0])*(2*(1-2*cl[0]-cl[1]));
		JaF[1][0] = x[1]*(4*cl[0]-1) + 0 + z[1]*(4*(cl[0]+cl[1])-3) + (x[1]+y[1])*2*cl[1] + (z[1]+y[1])*(-2*cl[1]) + (x[1]+z[1])*(2*(1-2*cl[0]-cl[1]));
		JaF[0][1] = 0 + y[0]*(4*cl[1]-1) + z[0]*(4*(cl[0]+cl[1])-3) + (x[0]+y[0])*2*cl[0] + (z[0]+y[0])*2*(1-cl[0]-2*cl[1]) + (x[0]+z[0])*(-2*cl[0]);
		JaF[1][1] = 0 + y[1]*(4*cl[1]-1) + z[1]*(4*(cl[0]+cl[1])-3) + (x[1]+y[1])*2*cl[0] + (z[1]+y[1])*2*(1-cl[0]-2*cl[1]) + (x[1]+z[1])*(-2*cl[0]);
		//compute cc
		r[0]=F[0];
		r[1]=F[1];
		rm  = sqrt(r[0]*r[0]+r[1]*r[1]);
	  rmp = rm;
	  if ( fabs(rmp) < 1.e-200 ) {
	    free(r);
	    return(1);
	  }
	  else if ( rmp > CS_TGV2 )
	    rmp /= CS_TGV2;
	  /* p1 = r0 */
		p[0] = r[0]; p[1] = r[1]; 
	  err = 1.e-3;
	  err = err*err*rmp;
	  it  = 0;
	  //ier = 1;
	  while ( (err < rm) && (++it <= 1000) ) {
	    /* alpha_m = <R_m-1,R_m-1> / <AP_m,P_m> */
	    ap[0]=JaF[0][0]*p[0] + JaF[0][1]*p[1];
			ap[1]=JaF[1][0]*p[0] + JaF[1][1]*p[1];
			dp = (p[0]*ap[0]+p[1]*ap[1]);
	    if ( fabs(dp) <= 1.e-200 )  break;

	    /* X_m = X_m-1 + alpha_m.P_m; R_m = R_m-1 - alpha_m AP_m */ 
	    alpha = rm / dp;
	    rmn   = 0.0;
	    //new solution
			cc[0] += alpha*p[0];
			cc[1] += alpha*p[1];
			//new direction
			r[0] -= alpha*ap[0];
			r[1] -= alpha*ap[1];
			rmn  = sqrt(r[0]*r[0]+r[1]*r[1]);
	    /* P_m+1 = R_m + beta_m P_m */
	    beta = rmn / rm;
	    p[0] = r[0] + beta * p[0];
	    p[1] = r[1] + beta * p[1];
	    rm = rmn;
	  }
		//cl_(n+1) = cl_n- JaF^-1.F(cl_n)=cl_n - cc
		cl[0] -= cc[0];
		cl[1] -= cc[1];
		
		F[0] = x[0]*cl[0]*(2*cl[0]-1) + y[0]*cl[1]*(2*cl[1]-1) + z[0]*(1-cl[0]-cl[1])*(1-2*cl[0]-2*cl[1])
			+ (x[0]+y[0])*2*cl[0]*cl[1] + (z[0]+y[0])*2*cl[1]*(1-cl[0]-cl[1]) + (x[0]+z[0])*2*cl[0]*(1-cl[0]-cl[1]) - c[0];
		F[1] = x[1]*cl[0]*(2*cl[0]-1) + y[1]*cl[1]*(2*cl[1]-1) + z[1]*(1-cl[0]-cl[1])*(1-2*cl[0]-2*cl[1])
			+ (x[1]+y[1])*2*cl[0]*cl[1] + (z[1]+y[1])*2*cl[1]*(1-cl[0]-cl[1]) + (x[1]+z[1])*2*cl[0]*(1-cl[0]-cl[1]) - c[1];
		er = F[0]*F[0]+F[1]*F[1];
  }	
	cloc[0]=cl[0];
	cloc[1]=cl[1];
  return(1);
}


// return velocity P1_interpolation in v in element iv[3]
static inline double vecint_2d(pSol sol,int *iv,double *cb,double *v) {
  double   *u0,*u1,*u2,dd;

  u0 = &sol->u0[2*(iv[0]-1)];
  u1 = &sol->u0[2*(iv[1]-1)];
  u2 = &sol->u0[2*(iv[2]-1)];

  /* P1 interpolate of the speed */   
  v[0] = cb[0]*u0[0] + cb[1]*u1[0] + cb[2]*u2[0];  
  v[1] = cb[0]*u0[1] + cb[1]*u1[1] + cb[2]*u2[1];
  dd = sqrt(v[0]*v[0] + v[1]*v[1]);
  return(dd);
}

// return velocity P2_interpolation in v in element *iel
static inline double vecintP2_2d(pMesh mesh,pSol sol,int *iel,double *cb,double *v) {
	pTria    pt; 
	pPoint   p[3];
  double   *u0,*u1,*u2,*u3,*u4,*u5,x[2],y[2],z[2],cl[2],cg[2],dd;
	int      i,k;
  
	k = *iel; 
	pt = &mesh->tria[k];
  u0 = &sol->u0[2*(pt->v[0]-1)];
  u1 = &sol->u0[2*(pt->v[1]-1)];
  u2 = &sol->u0[2*(pt->v[2]-1)];
  u3 = &sol->u0[2*(pt->v[3]-1)];
  u4 = &sol->u0[2*(pt->v[4]-1)];
  u5 = &sol->u0[2*(pt->v[5]-1)]; 

	for (i=0; i<3; i++) p[i] = &mesh->point[pt->v[i]];
	
	x[0] = p[0]->c[0]; y[0] = p[1]->c[0]; z[0] = p[2]->c[0];
  x[1] = p[0]->c[1]; y[1] = p[1]->c[1]; z[1] = p[2]->c[1];

  cg[0] = cb[0]*x[0] + cb[1]*y[0] + cb[2]*z[0];
  cg[1] = cb[0]*x[1] + cb[1]*y[1] + cb[2]*z[1];
//fprintf (stdout, "check for iel:%i; cg:%E,%E,\n",iel,cg[0],cg[1]);

  if (ptloc_2d(x,y,z,cg,cl)<1) return(0);

  /* P2 interpolate of the speed */   
 	v[0] = u0[0]*(1-cl[0]-cl[1])*(1-2*cl[0]-2*cl[1])+u1[0]*cl[0]*(2*cl[0]-1)+u2[0]*cl[1]*(2*cl[1]-1)
                       +u3[0]*4*cl[0]*(1-cl[0]-cl[1]) + u4[0]*4*cl[0]*cl[1]+ u5[0]*4*cl[1]*(1-cl[0]-cl[1]) ;      
	v[1] = u0[1]*(1-cl[0]-cl[1])*(1-2*cl[0]-2*cl[1])+u1[1]*cl[0]*(2*cl[0]-1)+u2[1]*cl[1]*(2*cl[1]-1)
							         +u3[1]*4*cl[0]*(1-cl[0]-cl[1]) + u4[1]*4*cl[0]*cl[1]+ u5[1]*4*cl[1]*(1-cl[0]-cl[1]) ;    	 

  dd = sqrt(v[0]*v[0] + v[1]*v[1]);
  return(dd);
}



// find element containing c, starting from nsdep, return baryc. coord
static int locelt_2d(pMesh mesh,int nsdep,double *c,double *cb) {
  pTria     pt;
  pPoint    p0,p1,p2;
  double    ax,ay,bx,by,cx,cy,eps;
  double    aire1,aire2,aire3,dd; 
  int      *adj,base,iadr,it,isign,nsfin,nsprv;
  char      i;

  for (i=0; i<mesh->dim; i++) {
    if ( c[i] < -ST_EPST*info.delta )
			return(-1);
	  else if ( c[i] < 0.0 )
			c[i] = 0.0;
	  if ( c[i] > info.max[i]+ST_EPST*info.delta )
		  return(-1);
		else if ( c[i] > info.max[i] )
			c[i] = info.max[i];
	}
   
  it    = 0;
  nsfin = nsdep;
  nsprv = 0;
  base  = ++mesh->mark;
  do {
    pt = &mesh->tria[nsfin];
    if ( !pt->v[0] || (it > 0 && nsfin == nsdep) )  return(nsprv);
    else if ( pt->mark == base )  break;
    pt->mark = base;
    iadr = 3*(nsfin-1)+1;
    adj  = &mesh->adja[iadr];

    /* area of triangle */
    p0 = &mesh->point[pt->v[0]];
    p1 = &mesh->point[pt->v[1]];
    p2 = &mesh->point[pt->v[2]];
    ax = p1->c[0] - p0->c[0];
    ay = p1->c[1] - p0->c[1];
    bx = p2->c[0] - p0->c[0];
    by = p2->c[1] - p0->c[1];
    dd = ax*by - ay*bx;
    isign = dd > 0.0 ? 1 : -1;
    eps   = isign == 1 ? ST_EPST*dd : -ST_EPST*dd;
    ///eps = 0.0;
    /* barycentric */
    bx = p1->c[0] - c[0];
    by = p1->c[1] - c[1];
    cx = p2->c[0] - c[0];
    cy = p2->c[1] - c[1];

    /* p in half-plane lambda_0 > 0 */
    aire1 = isign*(bx*cy - by*cx);
    if ( aire1 < eps ) {
      nsprv = nsfin;
      nsfin = adj[0] / 3;
      continue;
    }
    ax = p0->c[0] - c[0];
    ay = p0->c[1] - c[1];
    aire2 = isign*(cx*ay - cy*ax);
    if ( aire2 < eps ) {
      nsprv = nsfin;
      nsfin = adj[1] / 3;
      continue;
    }
    aire3 = isign*dd - aire1 - aire2;
    if ( aire3 < eps ) {
      nsprv = nsfin;
      nsfin = adj[2] / 3;
      continue;
    }
    aire1 = ST_MAX(aire1,0.0);
    aire2 = ST_MAX(aire2,0.0);
    aire3 = ST_MAX(aire3,0.0);
    dd    = aire1 + aire2 + aire3;
    if ( dd > ST_EPSA ) {
      dd = 1.0 / dd;
      cb[0] = aire1 * dd;
      cb[1] = aire2 * dd;
      cb[2] = aire3 * dd;
    }
    return(nsfin);
  }
  while ( nsfin && ++it <= mesh->nt );

  /* no need for exhaustive search */
  return(nsprv);
}

/* computes the characteristic line emerging from point with barycentric coordinates cb
 in triangle iel and follows the characteristic on a length dt at most. Most often has to 
 cross the boundary of the current triangle, thus stores in it the new triangle, in cb
 the barycentric coordinates in the new triangle of the crossing point, and updates dt 
 with the remaining time to follow characteristic line */
static int travel_2d(pMesh mesh,pSol sol,double *cb,int *iel,double *dt) {
  pTria       pt;
  pPoint      p[3];
  double     *u0,*u1,*u2,m[3],ddt,tol,ux,uy,c[2],cb1[3];
  int         k,*adj;
  char        i,i0,i1,i2;

  if ( *dt < ST_EPS * info.step )  return(0);
  tol = ST_MIN(info.step,*dt);
  k   = *iel;
  pt  = &mesh->tria[k];

  p[0] = &mesh->point[pt->v[0]];
  p[1] = &mesh->point[pt->v[1]];
  p[2] = &mesh->point[pt->v[2]];

  /* the speed at each vertex of iel */
  u0 = &sol->u0[2*(pt->v[0]-1)+0];
  u1 = &sol->u0[2*(pt->v[1]-1)+0];
  u2 = &sol->u0[2*(pt->v[2]-1)+0];

  /* u = P1 velocity at the point of barycentric coordinates cb */
  ux = cb[0]*u0[0] + cb[1]*u1[0] + cb[2]*u2[0];
  uy = cb[0]*u0[1] + cb[1]*u1[1] + cb[2]*u2[1];
  if ( ux*ux+uy*uy < ST_EPSD )  return(0);

  /* endpoint of the characteristic line starting from cb */
  /* segment is of norm sqrt(ux*ux+uy*uy), and is to be followed for time dt, in the - direction */
  c[0] = (cb[0]*p[0]->c[0] + cb[1]*p[1]->c[0] + cb[2]*p[2]->c[0]) - tol*ux;   
  c[1] = (cb[0]*p[0]->c[1] + cb[1]*p[1]->c[1] + cb[2]*p[2]->c[1]) - tol*uy;

  /* barycentric coordinate of uu in the current triangle */
  if ( !bar_2d(p,c,k,cb1) )  return(0);

  /* check if endpoint is in k */
  for (i=0; i<3; i++)
    if ( cb1[i] < 0.0 )  break;
  if ( i == 3 ) {
    memcpy(cb,cb1,3*sizeof(double));
    *dt -= tol;
    return(*dt > 0.0);
  }

  /* argument of the smallest value among 3 */
  ddt = ST_TGV;
  i0  = -1;
  for (i=0; i<3; i++) {
    m[i] = cb[i] - cb1[i]; 
    if ( m[i] > 0.0 ) {
      if ( tol*cb[i]/m[i] < ddt ) {
        ddt = tol*cb[i]/m[i];
        i0  = i;
      } 
    }
  }
  /* case when advection stays in same triangle */
  if ( ddt > tol ) {
    memcpy(cb,cb1,3*sizeof(double));
    *dt -= tol;
  }
  /* advection goes out of triangle*/  
    /* advect a minimum value */
    if ( ddt < ST_EPS*tol ) {
      c[0] = cb[0]*p[0]->c[0] + cb[1]*p[1]->c[0] + cb[2]*p[2]->c[0] - ST_EPS*ux;
      c[1] = cb[0]*p[0]->c[1] + cb[1]*p[1]->c[1] + cb[2]*p[2]->c[1] - ST_EPS*uy;
      /* find the new triangle */
      k = locelt_2d(mesh,k,c,cb); 
      if ( !k )  return(0);
      *iel = k;
      *dt -= ST_EPS;
    }
    else {
      /* barycentric coordinates of the exit point */   
      for (i=0; i<3; i++)
        cb1[i] = cb[i] - ddt* m[i]/tol;
      *dt -= ddt;

      /* find output triangle */
      i1 = inxt[i0];
      i2 = iprv[i0];
      adj = &mesh->adja[3*(k-1) + 1];
      if ( !adj[i0] ) {
        memcpy(cb,cb1,3*sizeof(double));
        return(0);
      }
      else {
        *iel = adj[i0] / 3;
        i0   = adj[i0] % 3; 
        cb[i0]         = 0;
        cb[inxt[i0]] = cb1[i2];
        cb[iprv[i0]] = cb1[i1];
      }
    }
  return(*dt > 0.0);
}


//4th order Runge-Kutta: for backtracking characteristic line, step is <0
//v = initial speed at point c
static int nxtptRK4_2d(pMesh mesh,pSol sol,int *iel,double *c,double *cb,double step,double *v) {
  double  h6,v1[2],v2[2],v3[2];
  double  xp1[2],xp2[2],xp3[2],cc[2];
  int     k;

  /* first integration point = middle point*/
  k = *iel;
  xp1[0] = c[0] - 0.5*step*v[0];   
  xp1[1] = c[1] - 0.5*step*v[1];
  k = locelt_2d(mesh,k,xp1,cb);
  if ( k < 1 )   return(k);
  vecint_2d(sol,mesh->tria[k].v,cb,v1);  

  xp2[0] = c[0] - 0.5*step*v1[0];
  xp2[1] = c[1] - 0.5*step*v1[1];
  k = locelt_2d(mesh,k,xp2,cb);
  if ( k < 1 )  return(k);
  vecint_2d(sol,mesh->tria[k].v,cb,v2);

  xp3[0] = c[0] - step*v2[0];
  xp3[1] = c[1] - step*v2[1];
  k = locelt_2d(mesh,k,xp3,cb);
  if ( k < 1 )   return(k);
  vecint_2d(sol,mesh->tria[k].v,cb,v3);

  /* final RK4 step */  
  h6 = step / 6.0;
  cc[0] = c[0] - h6 * (v[0] + 2*(v1[0] + v2[0]) + v3[0]);
  cc[1] = c[1] - h6 * (v[1] + 2*(v1[1] + v2[1]) + v3[1]);
  k = locelt_2d(mesh,k,cc,cb);
  if ( k < 1 )   return(k);

  /* update */  
  c[0] = cc[0];
  c[1] = cc[1];
  vecint_2d(sol,mesh->tria[k].v,cb,v);

  *iel = k;
  return(1);
}


static int nxtptEu_2d(pMesh mesh,pSol sol,int *iel,double *c,double *cb,double step,double *v) {
	double  cc[2];
  int     k;

  k = *iel;
  cc[0] = c[0] - step * v[0];
  cc[1] = c[1] - step * v[1];
  k = locelt_2d(mesh,k,cc,cb);
  if ( k < 1 )   return(k);

  /* update */  
  c[0] = cc[0];
  c[1] = cc[1];
  vecint_2d(sol,mesh->tria[k].v,cb,v);

  *iel = k;
  return(1);
}



//advect P1 solution u0, result in u
int advectRK4_P1_2d(pMesh mesh,pSol sol) {
  pTria    pt,pt1;
  pPoint   ppt;
  double  *u0,*u1,*u2,cb[3],v[2],c[2],dt,dte,norm,tol,step;  
  int      j,k,ip,iel,kprv,nstep;
  char     i;

  dt    = info.dt;
  tol   = info.step;
  nstep = (int)(dt / tol);
  step  = dt / nstep;

  //reset field 
  for (k=1; k<=mesh->np; k++)  mesh->point[k].flag = 0;
  ++mesh->mark;

  for (k=1; k<=mesh->nt; k++) {
    pt = &mesh->tria[k];  
    if ( !pt->v[0] )  continue;

    for (i=0; i<3; i++) {
      ip  = pt->v[i];
      ppt = &mesh->point[ip];
      if ( ppt->flag )  continue;   
      ppt->flag = 1;
      kprv = k;

      // coordinate and velocity at starting point
      v[0] = sol->u0[2*(ip-1)+0];
      v[1] = sol->u0[2*(ip-1)+1];
      norm = sqrt(v[0]*v[0] + v[1]*v[1]);
      if ( norm < ST_EPSD )  continue;

      // barycentric coordinates of point p in triangle k
      cb[i]  = 1.0;
      cb[inxt[i]] = 0.0;
      cb[iprv[i]] = 0.0;

      //next point = foot of the characteristic line
      c[0] = ppt->c[0];
      c[1] = ppt->c[1];
      dte  = dt;
      for (iel=k,j=0; j<nstep; j++) {
        kprv = iel;
        if ( nxtptEu_2d(mesh,sol,&iel,c,cb,step,v) < 1 )  break;
        //if ( nxtptRK4_2d(mesh,sol,&iel,c,cb,step,v) < 1 )  break;
        dte -= step;
      }
      if ( j < nstep && !iel ) {
        iel = kprv;
        while ( travel_2d(mesh,sol,cb,&iel,&dte) );
      }

      /*
      //check if characteristic remains inside domain
      if ( dte > ST_EPS ) {
        if ( iel < 0 )  iel = kprv;
        iel = locelt_2d(mesh,iel,c,cb);
        assert(iel>0);
      }
      */
      //interpolate value at foot
      pt1 = &mesh->tria[iel];
      assert(pt1->v[0]);
      
      u0 = &sol->u0[2*(pt1->v[0]-1)];
      u1 = &sol->u0[2*(pt1->v[1]-1)];
      u2 = &sol->u0[2*(pt1->v[2]-1)];
      sol->u[2*(ip-1)+0] = cb[0]*u0[0] + cb[1]*u1[0] + cb[2]*u2[0];
      sol->u[2*(ip-1)+1] = cb[0]*u0[1] + cb[1]*u1[1] + cb[2]*u2[1];
      
      /*
      vecint_2d(sol,mesh->tria[iel].v,cb,v);
			sol->u[2*(ip-1)+0] = v[0];
			sol->u[2*(ip-1)+1] = v[1];
			*/
    }
  }
  return(1);
}

//advect P2 solution u0, result in u
int advectRK4_P2_2d(pMesh mesh,pSol sol) {
  pTria    pt,pt1;
  pPoint   ppt,p1,p[3];
	double  x[3],y[3],z[3],*u0,*u1,*u2,*u3,*u4,*u5,cb[3],v[2],vu[2],c[2],cg[2],cl[2],dt,dte,norm,tol,step;  
  int      j,k,ip,iel,kprv,nstep,ier;
  char    *flg,i,i1;
  static double cbs[6][3] = {{1.0,0.0,0.0}, {0.0,1.0,0.0}, {0.0,0.0,1.0}, \
                         	  {0.5,0.5,0.0}, {0.0,0.5,0.5}, {0.5,0.0,0.5}};                           
  dt    = info.dt;
  tol   = info.step;
  nstep = (int)(dt / tol);
  step  = dt / nstep;

  //reset field 
  for (k=1; k<=mesh->np; k++)  mesh->point[k].flag = 0;
  flg = (char*)calloc(mesh->na+1,sizeof(char));
	for (k=1; k<=mesh->na; k++) flg[k] = 0;
  assert(flg);
  ++mesh->mark; 
  
  for (k=1; k<=mesh->nt; k++) {
    pt = &mesh->tria[k];  
    if ( !pt->v[0] )  continue;
    for (i=0; i<6; i++) {
      ip = pt->v[i];
			if ( i < 3 ) {
			  ppt = &mesh->point[ip];
			  if ( ppt->flag )  continue;
				ppt->flag = 1;
	    }
	    else {
				if ( flg[ip-mesh->np] )  continue;
				flg[ip-mesh->np] = 1;
		  }  
      //coordinate and velocity at starting point
      v[0] = sol->u0[2*(ip-1)+0];
      v[1] = sol->u0[2*(ip-1)+1];
      norm = sqrt(v[0]*v[0] + v[1]*v[1]);
      if ( norm < ST_EPSD )  continue;

      //barycentric coordinates of point p in triangle k
        cb[i%3]  = cbs[i][0];
        cb[inxt[i%3]] = cbs[i][1];
        cb[iprv[i%3]] = cbs[i][2];
      //next point = foot of the characteristic line
      if ( i < 3 ) {
        c[0] = ppt->c[0];
        c[1] = ppt->c[1];
      }
      else {
        i1  = inxt[i-3];
				p1 = &mesh->point[pt->v[i1]];
				c[0] = 0.5 * (ppt->c[0] + p1->c[0]);
				c[1] = 0.5 * (ppt->c[1] + p1->c[1]);
	    }  
      kprv = k;    
	    dte  = dt;
      for (iel=k,j=0; j<nstep; j++) {
        kprv = iel;
        if ( nxtptEu_2d(mesh,sol,&iel,c,cb,step,v) < 1 )  break;
        //if ( nxtptRK4_2d(mesh,sol,&iel,c,cb,step,v) < 1 )  break;
        dte -= step;
      }
      if ( j < nstep || !iel ) {
	    //if ( j < nstep ) {
        iel = kprv;
        while ( travel_2d(mesh,sol,cb,&iel,&dte) );
      }
      //check if characteristic remains inside domain
     /// if ( dte > ST_EPS ) {
        ///if ( iel < 0 )  iel = kprv;
        ///iel = locelt_2d(mesh,iel,c,cb);
        ///assert(iel>0);
      ///}
      // interpolate value at foot
			///assert(iel>0);
      pt1 = &mesh->tria[iel];
      assert(pt1->v[0]);
//if (ip == 5) printf("cb=%E,%E,%E\n",cb[0],cb[1],cb[2]);
//if (ip == 700) fprintf (stdout, "check for final triangle of 700:%i; cb:%E,%E,%E\n",iel,cb[0],cb[1],cb[2]);
     
/*
      u0 = &sol->u0[2*(pt1->v[0]-1)];
      u1 = &sol->u0[2*(pt1->v[1]-1)];
      u2 = &sol->u0[2*(pt1->v[2]-1)];
      sol->u[2*(ip-1)+0] = cb[0]*u0[0] + cb[1]*u1[0] + cb[2]*u2[0];
      sol->u[2*(ip-1)+1] = cb[0]*u0[1] + cb[1]*u1[1] + cb[2]*u2[1];
*/
/*
      vecint_2d(sol,mesh->tria[iel].v,cb,v);
			sol->u[2*(ip-1)+0] = v[0];
			sol->u[2*(ip-1)+1] = v[1];
*/			
			

      u0 = &sol->u0[2*(pt1->v[0]-1)];
      u1 = &sol->u0[2*(pt1->v[1]-1)];
      u2 = &sol->u0[2*(pt1->v[2]-1)];
      u3 = &sol->u0[2*(pt1->v[3]-1)];
      u4 = &sol->u0[2*(pt1->v[4]-1)];
      u5 = &sol->u0[2*(pt1->v[5]-1)]; 
      p[0] = &mesh->point[pt1->v[0]];
		  p[1] = &mesh->point[pt1->v[1]];
		  p[2] = &mesh->point[pt1->v[2]];
			x[0] = p[0]->c[0]; y[0] = p[1]->c[0]; z[0] = p[2]->c[0];
	    x[1] = p[0]->c[1]; y[1] = p[1]->c[1]; z[1] = p[2]->c[1];
      cg[0] = cb[0]*x[0] + cb[1]*y[0] + cb[2]*z[0];
      cg[1] = cb[0]*x[1] + cb[1]*y[1] + cb[2]*z[1];
//fprintf (stdout, "check for iel:%i; cg:%E,%E,\n",iel,cg[0],cg[1]);
      //if (ptloc_2d(x,y,z,cg,cl)<1) return(0);

//if ( sqrt((cl[0]-cb[1])*(cl[0]-cb[1])+(cl[1]-cb[2])*(cl[1]-cb[2])) > 0.00001 )
//fprintf (stdout, "check for cl: iel %i; cl %E,%E,  %E %E   d = %E\n",
//iel,cl[0],cl[1],cb[1],cb[2],sqrt((cl[0]-cb[1])*(cl[0]-cb[1])+(cl[1]-cb[2])*(cl[1]-cb[2])));
			cl[0] = cb[1]; cl[1] = cb[2];
      sol->u[2*(ip-1)+0] = u0[0]*(1-cl[0]-cl[1])*(1-2*cl[0]-2*cl[1])+u1[0]*cl[0]*(2*cl[0]-1)+u2[0]*cl[1]*(2*cl[1]-1)
                           +u3[0]*4*cl[0]*(1-cl[0]-cl[1]) + u4[0]*4*cl[0]*cl[1]+ u5[0]*4*cl[1]*(1-cl[0]-cl[1]) ;      
			sol->u[2*(ip-1)+1] = u0[1]*(1-cl[0]-cl[1])*(1-2*cl[0]-2*cl[1])+u1[1]*cl[0]*(2*cl[0]-1)+u2[1]*cl[1]*(2*cl[1]-1)
  								         +u3[1]*4*cl[0]*(1-cl[0]-cl[1]) + u4[1]*4*cl[0]*cl[1]+ u5[1]*4*cl[1]*(1-cl[0]-cl[1]) ;    	 
/*
			vecintP2_2d(mesh,sol,iel,cb,v);
			sol->u[2*(ip-1)+0] = v[0];
			sol->u[2*(ip-1)+1] = v[1];
*/			
		}
  }
  return(1);
}

// save velocity profiles along x=cte and y=cte 
int ghiaProf(pMesh mesh,pSol sol) {
  FILE   *out;
  double  dd,xp[2],cb[3],v[2];
  int     k,iel,nbp;
  char   *ptr,data[128],xout[128],yout[128];

  if ( sol->dim != 2 )  return(0);

  for (k=1; k<=mesh->np; k++)  mesh->point[k].flag = 0;
  ++mesh->mark;

  strcpy(data,sol->nameout);
  ptr = strstr(data,".mesh");
  if ( ptr )  *ptr = '\0';
  ptr = strstr(data,".sol");
  if ( ptr )  *ptr = '\0';
  sprintf(xout,"%s.xprof.m%1d.t%1d_dt%.2f",data,info.solver,info.typ,info.dt);

  nbp   = 100;
  sol->u0 = sol->u;

  // x component of velocity
  out = fopen(xout,"w");
  if ( !out )  return(0);
  xp[0] = 0.5;
  xp[1] = 0.0;
  dd  = (info.max[1] - info.min[1]) / (double)nbp;
  fprintf(out,"%f %f\n",xp[1],0.0);
  iel = 1;
  for (k=1; k<nbp; k++) {
    xp[1] += dd;
    iel = locelt_2d(mesh,iel,xp,cb);
    if ( iel > 0 ) {
      vecint_2d(sol,mesh->tria[iel].v,cb,v);
      fprintf(out,"%f %f\n",xp[1],v[0]);
    }
  }
  fprintf(out,"%f %f\n",1.0,1.0);
  fclose(out);

  // y component of velocity 
  sprintf(yout,"%s.yprof.m%1d.t%1d_dt%.2f",data,info.solver,info.typ,info.dt);
  out = fopen(yout,"w");
  if ( !out )  return(0);

  xp[0] = 0.0;
  xp[1] = 0.5;
  dd    = (info.max[1] - info.min[1]) / (double)nbp;
  fprintf(out,"%f %f\n",xp[0],0.0);
  iel = 1;
  for (k=1; k<nbp; k++) {
    xp[0] += dd;
    iel = locelt_2d(mesh,iel,xp,cb);
    if ( iel > 0 ) {
      vecint_2d(sol,mesh->tria[iel].v,cb,v);
      fprintf(out,"%f %f\n",xp[0],v[1]);
    }
  }
  fprintf(out,"%f %f\n",1.0,0.0);
  fclose(out);
  return(1);
}
      