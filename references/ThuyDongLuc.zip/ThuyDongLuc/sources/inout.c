#include "stokes.h"

extern Info   info;

/* read mesh */
int loadMesh(pMesh mesh) {
  pPoint     ppt;
  pEdge      pa;
  pTria      pt1;
  pTetra     pt;
  double    *a,*b,*c,*d,aire,vol;
  float      fp1,fp2,fp3;
  int        i,k,inm,nf,tmp;
  char      *ptr,data[256];

  strcpy(data,mesh->name);
  ptr = strstr(data,".mesh");
  if ( !ptr ) {
    strcat(data,".meshb");
    if( !(inm = GmfOpenMesh(data,GmfRead,&mesh->ver,&mesh->dim)) ) {
      ptr = strstr(data,".mesh");
      *ptr = '\0';
      strcat(data,".mesh");
      if (!(inm = GmfOpenMesh(data,GmfRead,&mesh->ver,&mesh->dim)) ) {
        fprintf(stderr,"  ** %s  NOT FOUND.\n",data);
        return(0);
      }
    }
  }
  else if (!(inm = GmfOpenMesh(data,GmfRead,&mesh->ver,&mesh->dim)) ) {
    fprintf(stderr,"  ** %s  NOT FOUND.\n",data);
    return(0);
  }
  if ( abs(info.imprim) > 0 ) {
    fprintf(stdout,"  %%%% %s OPENED\n",data);
    if ( abs(info.imprim) > 3 )
      fprintf(stdout,"  -- READING DATA FILE %s\n",data);
  }

  mesh->np = GmfStatKwd(inm,GmfVertices);
  mesh->nai= GmfStatKwd(inm,GmfEdges);
  mesh->nt = GmfStatKwd(inm,GmfTriangles);
  mesh->ne = GmfStatKwd(inm,GmfTetrahedra);

  if ( !mesh->np || (mesh->dim == 2 && !mesh->nt) || (mesh->dim == 3 && !mesh->ne) ) {
    fprintf(stdout,"  ** MISSING DATA\n");
    return(0);
  }
  /* memory allocation */
  mesh->point = (pPoint)calloc(mesh->np+1,sizeof(Point));
  assert(mesh->point);
  if ( mesh->nai ) {
    mesh->edge = (pEdge)calloc(mesh->nai+1,sizeof(Edge));
    assert(mesh->edge);
  }
  if ( mesh->nt ) {
    mesh->nti  = mesh->nt;
    mesh->tria = (pTria)calloc(mesh->nt+1,sizeof(Tria));
    assert(mesh->tria);
  }
  if ( mesh->ne ) {
    mesh->tetra = (pTetra)calloc(mesh->ne+1, sizeof(Tetra));
    assert(mesh->tetra);
  }

  if ( mesh->dim == 2 ) {
    GmfGotoKwd(inm,GmfVertices);
    for (k=1; k<=mesh->np; k++) {
      ppt = &mesh->point[k];
      if ( mesh->ver == GmfFloat ) {
        GmfGetLin(inm,GmfVertices,&fp1,&fp2,&ppt->ref);
        ppt->c[0] = fp1;
        ppt->c[1] = fp2;
      }
      else
        GmfGetLin(inm,GmfVertices,&ppt->c[0],&ppt->c[1],&ppt->ref);
      ppt->ref = abs(ppt->ref);
    }
    /* read mesh edges */
    GmfGotoKwd(inm,GmfEdges);
    for (k=1; k<=mesh->nai; k++) {
      pa = &mesh->edge[k];
      GmfGetLin(inm,GmfEdges,&pa->v[0],&pa->v[1],&pa->ref);
      /*if ( pa->ref && pa->ref != ST_Interface ) {
        ppt = &mesh->point[pa->v[0]];
        ppt->ref = pa->ref;
        ppt = &mesh->point[pa->v[1]];
        ppt->ref = pa->ref;
      }*/
    }
    /* read mesh triangles */
    nf = 0;
    GmfGotoKwd(inm,GmfTriangles);
    for (k=1; k<=mesh->nt; k++) {
      pt1 = &mesh->tria[k];
      GmfGetLin(inm,GmfTriangles,&pt1->v[0],&pt1->v[1],&pt1->v[2],&pt1->ref);
      for (i=0; i<3; i++) {    
        ppt = &mesh->point[pt1->v[i]];
        if ( !ppt->s )  ppt->s = k;
      }
      /* check orientation */
      a = &mesh->point[pt1->v[0]].c[0];
      b = &mesh->point[pt1->v[1]].c[0];
      c = &mesh->point[pt1->v[2]].c[0];
      aire = area_2d(a,b,c);
      if ( aire < 0.0 ) {
        nf++;
        tmp = pt1->v[1];
        pt1->v[1] = pt1->v[2];
        pt1->v[2] = tmp;
      }
    }

    if ( abs(info.imprim) > 4 ) {
      fprintf(stdout,"  %%%% NUMBER OF VERTICES  %8d\n",mesh->np);
      if ( mesh->na )  fprintf(stdout,"  %%%% NUMBER OF EDGES     %8d\n",mesh->na);
      if ( nf > 0 )
        fprintf(stdout,"  %%%% NUMBER OF TRIANGLES %8d  (%d flipped)\n",mesh->nt,nf);    
      else
        fprintf(stdout,"  %%%% NUMBER OF TRIANGLES %8d\n",mesh->nt);
    }
  }
  else {
    GmfGotoKwd(inm,GmfVertices);
    for (k=1; k<=mesh->np; k++) {
      ppt = &mesh->point[k];
      if ( mesh->ver == GmfFloat ) {
        GmfGetLin(inm,GmfVertices,&fp1,&fp2,&fp3,&ppt->ref);
        ppt->c[0] = fp1;
        ppt->c[1] = fp2;
        ppt->c[2] = fp3;
      }
      else
        GmfGetLin(inm,GmfVertices,&ppt->c[0],&ppt->c[1],&ppt->c[2],&ppt->ref);
    }
    /* read triangles */
    GmfGotoKwd(inm,GmfTriangles);
    for (k=1; k<=mesh->nt; k++) {
      pt1 = &mesh->tria[k];
      GmfGetLin(inm,GmfTriangles,&pt1->v[0],&pt1->v[1],&pt1->v[2],&pt1->ref);
      for (i=0; i<3; i++) {    
        ppt = &mesh->point[pt1->v[i]];
        if ( !ppt->s )  ppt->s = k;
      }
    }
    /* read tetrahedra */
    nf = 0;
    GmfGotoKwd(inm,GmfTetrahedra);
    for (k=1; k<=mesh->ne; k++) {
      pt = &mesh->tetra[k];
      GmfGetLin(inm,GmfTetrahedra,&pt->v[0],&pt->v[1],&pt->v[2],&pt->v[3],&pt->ref);
      for (i=0; i<4; i++) {    
        ppt = &mesh->point[pt->v[i]];
        if ( !ppt->s )  ppt->s = k;
      }
      /* check orientation */
      a = &mesh->point[pt->v[0]].c[0];
      b = &mesh->point[pt->v[1]].c[0];
      c = &mesh->point[pt->v[2]].c[0];
      d = &mesh->point[pt->v[3]].c[0];
      vol = volu_3d(a,b,c,d);
      if ( vol < 0.0 ) {
        nf++;
        tmp = pt->v[2];
        pt->v[2] = pt->v[3];
        pt->v[3] = tmp;
      }
    }
    if ( abs(info.imprim) > 4 ) {
      fprintf(stdout,"  %%%% NUMBER OF VERTICES   %8d\n",mesh->np);
      fprintf(stdout,"  %%%% NUMBER OF TRIANGLES  %8d\n",mesh->nt);  
      if ( nf > 0 )
        fprintf(stdout,"  %%%% NUMBER OF TETRAHEDRA %8d (%d flipped)\n",mesh->ne,nf);
      else
        fprintf(stdout,"  %%%% NUMBER OF TETRAHEDRA %8d\n",mesh->ne);
    }
  }
  GmfCloseMesh(inm);
  return(1);
}

/* load initial solution */
int loadSol(pSol sol) {
  float       buf[GmfMaxTyp];
  double      bufd[GmfMaxTyp];
  int         i,k,type,inm,typtab[GmfMaxTyp],offset,keyword;
  char       *ptr,data[128];
  
  if ( !sol->namein )  return(-1);
  strcpy(data,sol->namein);
  ptr = strstr(data,".sol");
  if ( !ptr ) {
    strcat(data,".solb");
    if ( !(inm = GmfOpenMesh(data,GmfRead,&sol->ver,&sol->dim)) ) {
      ptr = strstr(data,".sol");
      *ptr = '\0';
      strcat(data,".sol");
      if ( !(inm = GmfOpenMesh(data,GmfRead,&sol->ver,&sol->dim)) )
        return(-1);
    }
  }
  else {
		if ( !(inm = GmfOpenMesh(data,GmfRead,&sol->ver,&sol->dim)) )
      return(-1);
	}
				
  if ( abs(info.imprim) > 0 ) {
    fprintf(stdout,"  %%%% %s OPENED\n",data);
    if ( abs(info.imprim) > 3 )
      fprintf(stdout,"  -- READING SOLUTION %s\n",data);
  }

  sol->np = GmfStatKwd(inm,GmfSolAtVertices,&type,&offset,&typtab);
  keyword = sol->dim == 2 ? GmfSolAtTriangles : GmfSolAtTetrahedra;
  sol->ne = GmfStatKwd(inm,keyword,&type,&offset,&typtab);
  if ( !sol->np )  return(-1);
  
  sol->u0 = (double*)calloc(sol->dim*(sol->np+sol->ne),sizeof(double));
  assert(sol->u0);
  sol->p0 = (double*)calloc(sol->dim*sol->np,sizeof(double));
  assert(sol->p0);
  /* read mesh solutions u_1,..,u_d,p */
  GmfGotoKwd(inm,GmfSolAtVertices);
  if ( sol->ver == GmfFloat ) {
    for (k=0; k<sol->np; k++) {
      GmfGetLin(inm,GmfSolAtVertices,buf);
      for (i=0; i<sol->dim; i++)
        sol->u0[sol->dim*k+i] = buf[i];
      sol->p0[k] = buf[i];     
    }
    /* bubble */
    if ( sol->ne ) {
      GmfGotoKwd(inm,keyword);
      for (k=sol->np; k<sol->np+sol->ne; k++) {
        GmfGetLin(inm,keyword,buf);
        for (i=0; i<sol->dim; i++)
          sol->u0[sol->dim*k+i] = buf[i];
      }
    }
  }
  else {
    for (k=0; k<sol->np; k++) {
      GmfGetLin(inm,GmfSolAtVertices,bufd);
      for (i=0; i<sol->dim; i++)      
        sol->u0[sol->dim*k+i] = bufd[i];         
      sol->p0[k] = bufd[i];     
    }
    /* bubble */
    if ( sol->ne ) {
      GmfGotoKwd(inm,keyword);
      for (k=sol->np; k<sol->np+sol->ne; k++) {
        GmfGetLin(inm,keyword,bufd);
        for (i=0; i<sol->dim; i++)
          sol->u0[sol->dim*k+i] = bufd[i];      
      }
    }
  }

  if ( GmfStatKwd(inm,GmfIterations) ) {
    GmfGotoKwd(inm,GmfIterations);
    GmfGetLin(inm,GmfIterations,&sol->iter);
  }
printf("iter %d\n",sol->iter);
  if ( GmfStatKwd(inm,GmfTime) ) {
    GmfGotoKwd(inm,GmfTime);
    if ( sol->ver == GmfFloat ) {
      GmfGetLin(inm,GmfTime,&buf[0]);
      sol->time = (double)buf[0];
printf("sol->time %f\n",sol->time);
    }
    else {
      GmfGetLin(inm,GmfTime,&sol->time);
	  }
  }
  if ( abs(info.imprim) > 4 )
    fprintf(stdout,"  %%%% NUMBER OF SOLUTIONS  %8d\n",sol->np+sol->ne);
  GmfCloseMesh(inm); 
  return(1);
}


/* load Dirichlet boundary conditions */
int loadBC(pSol sol) {
  float       buf[GmfMaxTyp];
  double      bufd[GmfMaxTyp];
  int         i,k,type,inm,typtab[GmfMaxTyp],offset;
  char        data[128];

  if ( !sol->data )  return(-1);
  strcpy(data,sol->data);
  if ( !(inm = GmfOpenMesh(data,GmfRead,&sol->ver,&sol->dim)) ) {
    fprintf(stdout,"  ## Unable to open %s\n",data);
    return(-1);
  }
  if ( abs(info.imprim) > 0 ) {
    fprintf(stdout,"  %%%% %s OPENED\n",data);
    if ( abs(info.imprim) > 3 )
      fprintf(stdout,"  -- READING BOUNDARY CONDITIONS %s\n",data);
  }

  sol->np = GmfStatKwd(inm,GmfSolAtVertices,&type,&offset,&typtab);
  if ( !sol->np )  return(-1);

  /* memory alloc P1 */
  sol->bc = (double*)calloc(sol->dim*sol->np,sizeof(double));
  assert(sol->bc);

  /* read mesh solutions u_1,..u_d */
  GmfGotoKwd(inm,GmfSolAtVertices);
  if ( sol->ver == GmfFloat ) {
    for (k=0; k<sol->np; k++) {
      GmfGetLin(inm,GmfSolAtVertices,buf);
      for (i=0; i<sol->dim; i++)
        sol->bc[sol->dim*k+i] = buf[i];     
    }
  }
  else {
    for (k=0; k<sol->np; k++) {
      GmfGetLin(inm,GmfSolAtVertices,bufd);
      for (i=0; i<sol->dim; i++)      
        sol->bc[sol->dim*k+i] = bufd[i];         
    }
  }

  if ( abs(info.imprim) > 4 )
    fprintf(stdout,"  %%%% NUMBER OF CONDITIONS  %8d\n",sol->np);
  GmfCloseMesh(inm);
  return(1);
}

/* save solution */
int saveSol(pSol sol) {
  double       dd,dbuf[GmfMaxTyp];
  float        fbuf[GmfMaxTyp],tmpf;
  int          i,k,inm,type,typtab[GmfMaxTyp],keyword;
  char        *ptr,data[128];

  strcpy(data,sol->nameout);
  ptr = strstr(data,".mesh");
  if ( ptr )  {
    *ptr = '\0';
    strcat(data,".sol");
  }
  else {
    ptr = strstr(data,".sol");
    if ( !ptr )  strcat(data,".sol");
  }

  if ( !(inm = GmfOpenMesh(data,GmfWrite,sol->ver,sol->dim)) ) {
    fprintf(stderr,"  ** UNABLE TO OPEN %s\n",data);
    return(0);
  }
  if ( abs(info.imprim) > 0 )
    fprintf(stdout,"  %%%% %s OPENED\n",data);

  type = 2;
  typtab[0] = GmfVec;
  typtab[1] = GmfSca;
  keyword   = sol->dim == 2 ? GmfSolAtTriangles : GmfSolAtTetrahedra;

  /* write P1 sol */
  GmfSetKwd(inm,GmfSolAtVertices,sol->np,type,typtab);
  if ( sol->ver == GmfFloat ) {
    for (k=0; k<sol->np; k++) {
      for (i=0; i<sol->dim; i++)      
        fbuf[i] = sol->u[sol->dim*k+i];
      fbuf[i] = sol->p[k];
      //if ( k==228 ) printf("point 229 vel %f %f  pres %f\n",sol->u[2*228+0],sol->u[2*228+1],sol->p[228]);
      GmfSetLin(inm,GmfSolAtVertices,fbuf);
    }
    if ( info.typ == P1bP1 ) {
      /* bubble */
      type = 1;
      GmfSetKwd(inm,keyword,sol->ne,type,typtab);
      for (k=sol->np; k<sol->np+sol->ne; k++) {
        for (i=0; i<sol->dim; i++)      
          fbuf[i] = sol->u[sol->dim*k+i];
        GmfSetLin(inm,keyword,fbuf);
      }
    }
  }
  else {
    for (k=0; k<sol->np; k++) {
      for (i=0; i<sol->dim; i++)      
        dbuf[i] = sol->u[sol->dim*k+i];
      dbuf[i] = sol->p[k];
      GmfSetLin(inm,GmfSolAtVertices,dbuf);
    }
    if ( info.typ == P1bP1 ) {
      /* bubble */
      type = 1;
      GmfSetKwd(inm,keyword,sol->ne,type,typtab);
      for (k=sol->np; k<sol->np+sol->ne; k++) {
        for (i=0; i<sol->dim; i++)      
          dbuf[i] = sol->u[sol->dim*k+i];
        GmfSetLin(inm,keyword,dbuf);
      }
    }
  }

  /* unsteady case */
  if ( info.nit > 0 ) {
    GmfSetKwd(inm,GmfIterations);
    GmfSetLin(inm,GmfIterations,sol->iter);
  }
  if ( sol->time > 0.0 ) {
    GmfSetKwd(inm,GmfTime);
    if ( sol->ver == GmfFloat ) {
      tmpf = sol->time;
printf("sol->time %f   tmpf %f\n",sol->time,tmpf);
      GmfSetLin(inm,GmfTime,tmpf);
    }
    else
      GmfSetLin(inm,GmfTime,sol->time);
  }
  GmfCloseMesh(inm);

  if ( info.ddebug ) {
    sol->ver = GmfFloat;
    if ( !(inm = GmfOpenMesh("pressure.sol",GmfWrite,sol->ver,sol->dim)) ) {
      fprintf(stderr,"  ** UNABLE TO OPEN pression.sol\n");
      return(0);
    }
    type = 1;
    typtab[0] = GmfSca;
    GmfSetKwd(inm,GmfSolAtVertices,sol->np,type,typtab);
    for (k=0; k<sol->np; k++) {
      fbuf[0] = sol->p[k];
      GmfSetLin(inm,GmfSolAtVertices,fbuf);
    }
    GmfCloseMesh(inm);

    /* write velocity field */
    if ( !(inm = GmfOpenMesh("velocity.sol",GmfWrite,sol->ver,sol->dim)) ) {
      fprintf(stderr,"  ** UNABLE TO OPEN velocity.sol\n");
      return(0);
    }
    type = 2;
    typtab[0] = GmfVec;
    GmfSetKwd(inm,GmfSolAtVertices,sol->np,type,typtab);
    for (k=0; k<sol->np; k++) {
      for (i=0; i<sol->dim; i++)      
        fbuf[i] = sol->u[sol->dim*k+i];
      GmfSetLin(inm,GmfSolAtVertices,fbuf);
    }
    GmfCloseMesh(inm);

    /* write velocity norm */
    if ( !(inm = GmfOpenMesh("normv.sol",GmfWrite,sol->ver,sol->dim)) ) {
      fprintf(stderr,"  ** UNABLE TO OPEN velocity.sol\n");
      return(0);
    }
    type = 1;
    typtab[0] = GmfSca;
    GmfSetKwd(inm,GmfSolAtVertices,sol->np,type,typtab);
    for (k=0; k<sol->np; k++) {
      dd = 0.0;
      for (i=0; i<sol->dim; i++)      
        dd += sol->u[sol->dim*k+i]*sol->u[sol->dim*k+i];
      fbuf[0] = dd;
      GmfSetLin(inm,GmfSolAtVertices,fbuf);
    }
    GmfCloseMesh(inm);
  }
  return(1);
}

/* save solution */
int saveIt(pSol sol,int it) {
  double       dbuf[GmfMaxTyp];
  float        fbuf[GmfMaxTyp],tmpf;
  int          i,k,inm,type,typtab[GmfMaxTyp],keyword;
  char        *ptr,data[128],name[128];

  strcpy(data,sol->nameout);
  ptr = strstr(data,".mesh");
  if ( !ptr )  ptr = strstr(data,".sol");
  if ( ptr )  *ptr = '\0';
	sprintf(name,"%s.%d.solb",data,it);

  if ( !(inm = GmfOpenMesh(name,GmfWrite,sol->ver,sol->dim)) ) {
    fprintf(stderr,"  ** UNABLE TO OPEN %s\n",name);
    return(0);
  }

  type = 2;
  typtab[0] = GmfVec;
  typtab[1] = GmfSca;
  keyword   = sol->dim == 2 ? GmfSolAtTriangles : GmfSolAtTetrahedra;

  /* write sol */
  GmfSetKwd(inm,GmfSolAtVertices,sol->np,type,typtab);
  if ( sol->ver == GmfFloat ) {
    for (k=0; k<sol->np; k++) {
      for (i=0; i<sol->dim; i++)      
        fbuf[i] = sol->u[sol->dim*k+i];
      fbuf[i] = sol->p[k];
      GmfSetLin(inm,GmfSolAtVertices,fbuf);
    }
    if ( info.typ == P1bP1 ) {
      /* bubble */
      type = 1;
      GmfSetKwd(inm,keyword,sol->ne,type,typtab);
      for (k=sol->np; k<sol->np+sol->ne; k++) {
        for (i=0; i<sol->dim; i++)      
          fbuf[i] = sol->u[sol->dim*k+i];
        GmfSetLin(inm,keyword,fbuf);
      }
    }
  }
  else {
    for (k=0; k<sol->np; k++) {
      for (i=0; i<sol->dim; i++)      
        dbuf[i] = sol->u[sol->dim*k+i];
      dbuf[i] = sol->p[k];
      GmfSetLin(inm,GmfSolAtVertices,dbuf);
    }
    if ( info.typ == P1bP1 ) {
      /* bubble */
      type = 1;
      GmfSetKwd(inm,keyword,sol->ne,type,typtab);
      for (k=sol->np; k<sol->np+sol->ne; k++) {
        for (i=0; i<sol->dim; i++)      
          dbuf[i] = sol->u[sol->dim*k+i];
        GmfSetLin(inm,keyword,dbuf);
      }
    }
  }

  /* unsteady case */
  if ( info.nit > 0 ) {
    GmfSetKwd(inm,GmfIterations);
    GmfSetLin(inm,GmfIterations,sol->iter);
    GmfSetKwd(inm,GmfTime);
    if ( sol->ver == GmfFloat ) {
      tmpf = sol->time;
      GmfSetLin(inm,GmfTime,tmpf);
    }
    else
      GmfSetLin(inm,GmfTime,sol->time);
  }
  GmfCloseMesh(inm);
	return(1);
}

/* save solution */
int saveVor(pSol sol) {
  float        fbuf[GmfMaxTyp];
  int          k,inm,type,typtab[GmfMaxTyp];

/* save vorticity */
  if ( sol->u0 ) {
    sol->ver = GmfFloat;
    if ( !(inm = GmfOpenMesh("vorticity.sol",GmfWrite,sol->ver,sol->dim)) ) {
      fprintf(stderr,"  ** UNABLE TO OPEN vorticity.sol\n");
      return(0);
    }
    type = 1;
    typtab[0] = GmfSca;
    GmfSetKwd(inm,GmfSolAtVertices,sol->np,type,typtab);
    for (k=0; k<sol->np; k++) {
      fbuf[0] = sol->u0[k];
      GmfSetLin(inm,GmfSolAtVertices,fbuf);
    }
    GmfCloseMesh(inm);
		free(sol->u0);
		sol->u0 = 0;
	}
  return(1);
}
