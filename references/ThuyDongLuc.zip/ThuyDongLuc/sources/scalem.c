#include "stokes.h"

extern Info  info;


/* just for translation */
int scaleMesh(pMesh mesh,pSol sol) {
  pPoint    ppt,p1,p2;
	pTria     pt;
	pTetra    pe;
	Mat      *pm;
  double    dd,numax,numin,nurap;
  int       k;
	char      i,i1,j;

  /* compute bounding box */
  for (i=0; i<mesh->dim; i++) {
    info.min[i] =  FLT_MAX;
    info.max[i] = -FLT_MAX;
  }

  for (k=1; k<=mesh->np; k++) {
    ppt = &mesh->point[k];
    for (i=0; i<mesh->dim; i++) {
      if ( ppt->c[i] > info.max[i] )  info.max[i] = ppt->c[i];
      if ( ppt->c[i] < info.min[i] )  info.min[i] = ppt->c[i];
    }
  }
  info.delta = 0.0;
  for (i=0; i<mesh->dim; i++) {
    dd = fabs(info.max[i]-info.min[i]);
    if ( dd > info.delta )  info.delta = dd;
  }
  if ( info.delta < ST_EPSD ) {
    fprintf(stdout,"  ## Unable to scale mesh\n");
    return(0);
  }

  /* translate coordinates */
  for (k=1; k<=mesh->np; k++) {
    ppt = &mesh->point[k];
    for (i=0; i<mesh->dim; i++)
      ppt->c[i] = (ppt->c[i] - info.min[i]);
  }

  /* compute hmin */
	info.hmin = info.delta*info.delta;
  if ( mesh->dim == 2 ) {
		for (k=1; k<=mesh->nt; k++) {
			pt = &mesh->tria[k];
			if ( !pt->v[0] )  continue;
			for (i=0; i<3; i++) {
				i1 = inxt[i];
				p1 = &mesh->point[pt->v[i]];
				p2 = &mesh->point[pt->v[i1]];
				dd = (p2->c[0]-p1->c[0])*(p2->c[0]-p1->c[0]) + (p2->c[1]-p1->c[1])*(p2->c[1]-p1->c[1]);
				if ( dd < info.hmin )  info.hmin = dd;
			}
		}
	}
	else {
		for (k=1; k<=mesh->ne; k++) {
			pe = &mesh->tetra[k];
			if ( !pe->v[0] )  continue;
			for (i=0; i<3; i++) {
				p1 = &mesh->point[pe->v[i]];
				for (j=i+1; j<4; j++) {
					p2 = &mesh->point[pe->v[j]];
				  dd = (p2->c[0]-p1->c[0])*(p2->c[0]-p1->c[0]) + (p2->c[1]-p1->c[1])*(p2->c[1]-p1->c[1]) \
						+ (p2->c[2]-p1->c[2])*(p2->c[2]-p1->c[2]);
				  if ( dd < info.hmin )  info.hmin = dd;
				}
			}
		}
	}
	info.hmin = sqrt(info.hmin);

  /* for RHS method */
	numax = 0.0;
	numin = ST_TGV;
  for (i=0; i<sol->nmat; i++) {
    pm = &sol->mat[i];
		numax = ST_MAX(pm->nu,numax);
		numin = ST_MIN(pm->nu,numax);
	}
	nurap = numin / numax;
	info.rhs = nurap < ST_NURHS;  

  return(1);
}

int unscaleMesh(pSol sol) {
	Mat     *pm;
	double   numax;
  int      k;

	numax = 0.0;
  for (k=0; k<sol->nmat; k++) {
    pm = &sol->mat[k];
		numax = ST_MAX(pm->nu,numax);
	}
	numax = 1.0 / numax;
  /* rescale solution */
  for (k=0; k<sol->np; k++)
    sol->p[k] *= numax;

  return(1);
}



