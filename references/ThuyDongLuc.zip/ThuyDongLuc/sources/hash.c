#include "stokes.h"

extern Info  info;

#define KTA     7
#define KTB    11

#define KA     31
#define KB     57
#define KC     79

unsigned char inxt[3]     = {1,2,0};
unsigned char iprv[3]     = {2,0,1};
unsigned char idirt[4][3] = { {1,2,3}, {0,3,2}, {0,1,3}, {0,2,1} };

int hashel_2d(pMesh mesh) {
  pTria     pt,pt1;
  int       k,kk,pp,l,ll,mins,mins1,maxs,maxs1,iadr;
  int      *hcode,*link,inival,hsize;
  char      i,ii,i1,i2;
  int       key;

  if ( mesh->adja )  return(1);
  if ( abs(info.imprim) > 4 )
    fprintf(stdout,"  ** SETTING STRUCTURE\n");

  /* memory alloc */
  mesh->adja = (int*)calloc(3*mesh->nt+5,sizeof(int));
  assert(mesh->adja);
  hcode = (int*)calloc(mesh->nt+1,sizeof(int));
  assert(hcode);
  link  = mesh->adja;
  hsize = mesh->nt;

  /* init */
  inival = 2147483647;
  for (k=0; k<=mesh->nt; k++)
    hcode[k] = -inival;

  /* build hash table */
  iadr = 0;
  for (k=1; k<=mesh->nt; k++) {
    pt = &mesh->tria[k];
    if ( !pt->v[0] )  continue;

    for (i=0; i<3; i++) {
      i1 = inxt[i];
      i2 = inxt[i1];
      mins = ST_MIN(pt->v[i1],pt->v[i2]);
      maxs = ST_MAX(pt->v[i1],pt->v[i2]);

      /* compute key */
      key = KTA*mins + KTB*maxs;
      key = key % hsize + 1;
      /* insert */
      iadr++;
      link[iadr] = hcode[key];
      hcode[key] = -iadr;
    }
  }

  /* set adjacency */
  for (l=iadr; l>0; l--) {
    if ( link[l] >= 0 )  continue;
    k = (l-1) / 3 + 1;
    i = (l-1) % 3;
    i1 = inxt[i];
    i2 = inxt[i1];
    pt = &mesh->tria[k];

    mins = ST_MIN(pt->v[i1],pt->v[i2]);
    maxs = ST_MAX(pt->v[i1],pt->v[i2]);

    /* accross link */
    ll = -link[l];
    pp = 0;
    link[l] = 0;
    while ( ll != inival ) {
      kk = (ll-1) / 3 + 1;
      ii = (ll-1) % 3;
      i1 = inxt[ii];
      i2 = inxt[i1];
      pt1  = &mesh->tria[kk];
      mins1 = ST_MIN(pt1->v[i1],pt1->v[i2]);
      maxs1 = ST_MAX(pt1->v[i1],pt1->v[i2]);

      if ( mins1 == mins  && maxs1 == maxs ) {
        /* adjacent found */
        if ( pp != 0 )  link[pp] = link[ll];
        link[l] = 3*kk + ii;
        link[ll]= 3*k + i;
        break;
      }
      pp = ll;
      ll = -link[ll];
    }
  }
  free(hcode);
  return(1);
}

/* store seed triangle to boundary point */
int seedel_2d(pMesh mesh,pSol sol) {
  Mat   *pm;
  pTria  pt,pt1;
  int   *adj,k,iv,kk;
  char   i;

  pm = &sol->mat[0];
  for (k=1; k<=mesh->nt; k++) {
    pt  = &mesh->tria[k];
    adj = &mesh->adja[3*(k-1)+1];
    for (i=0; i<3; i++) {
      iv = pt->v[inxt[i]];
      if ( !adj[i] ) {
        mesh->point[iv].s = k;
      }
      else {
        kk  = adj[i] / 3;
        pt1 = &mesh->tria[kk];
        if ( (pt->ref == pm->ref) && (pt->ref != pt1->ref) )
          mesh->point[iv].s = k;
      }
    }
  }
  return(1);
}

int hashel_3d(pMesh mesh) {
  pTetra    pt,pt1;
  int       k,kk,pp,l,ll,mins,mins1,maxs,maxs1,sum,sum1,iadr;
  int      *hcode,*link,inival,hsize;
  unsigned char  i,ii,i1,i2,i3;
  unsigned int    key;

  /* avoid building */
  if ( 4*sizeof(char) != sizeof(int) )  exit(1);

  /* memory alloc */
  mesh->adja = (int*)calloc(4*mesh->ne+5,sizeof(int));
  assert(mesh->adja);
  hcode = (int*)calloc(mesh->ne+1,sizeof(int));
  assert(hcode);
  link  = mesh->adja;
  hsize = mesh->ne;

  /* init */
  inival = 2147483647;
  for (k=0; k<=mesh->ne; k++)
    hcode[k] = -inival;

  /* build hash table */
  for (k=1; k<=mesh->ne; k++) {
    pt = &mesh->tetra[k];
    if ( !pt->v[0] )  continue;
    for (i=0; i<4; i++) {
      i1 = idirt[i][0];
      i2 = idirt[i][1];
      i3 = idirt[i][2];
      mins = ST_MIN(pt->v[i1],pt->v[i2]);
      mins = ST_MIN(mins,pt->v[i3]);
      maxs = ST_MAX(pt->v[i1],pt->v[i2]);
      maxs = ST_MAX(maxs,pt->v[i3]);

      /* compute key */
      sum = pt->v[i1] + pt->v[i2] + pt->v[i3];
      key = KA*mins + KB*maxs + KC*sum;
      key = key % hsize + 1;

      /* insert */
      iadr = 4*(k-1) + i+1;
      link[iadr] = hcode[key];
      hcode[key] = -iadr;
    }
  }

  /* set adjacency */
  for (l=4*mesh->ne; l>0; l--) {
    if ( link[l] >= 0 )  continue;
    k = ((l-1) >> 2) + 1;
    i = (l-1) % 4;
    i1 = idirt[i][0];
    i2 = idirt[i][1];
    i3 = idirt[i][2];
    pt = &mesh->tetra[k];

    sum  = pt->v[i1] + pt->v[i2] + pt->v[i3];
    mins = ST_MIN(pt->v[i1],pt->v[i2]);
    mins = ST_MIN(mins,pt->v[i3]);
    maxs = ST_MAX(pt->v[i1],pt->v[i2]);
    maxs = ST_MAX(maxs,pt->v[i3]);

    /* accross link */
    ll = -link[l];
    pp = 0;
    link[l] = 0;
    while ( ll != inival ) {
      kk = ((ll-1) >> 2) + 1;
      ii = (ll-1) % 4;
      i1 = idirt[ii][0];
      i2 = idirt[ii][1];
      i3 = idirt[ii][2];
      pt1  = &mesh->tetra[kk];
      sum1 = pt1->v[i1] + pt1->v[i2] + pt1->v[i3];
      if ( sum1 == sum ) {
        mins1 = ST_MIN(pt1->v[i1],pt1->v[i2]);
        mins1 = ST_MIN(mins1,pt1->v[i3]);
        if ( mins1 == mins ) {
          maxs1 = ST_MAX(pt1->v[i1],pt1->v[i2]);
          maxs1 = ST_MAX(maxs1,pt1->v[i3]);
          if ( maxs1 == maxs ) {
            /* adjacent found */
            if ( pp != 0 )  link[pp] = link[ll];
            link[l] = 4*kk + ii;
            link[ll]= 4*k + i;
            break;
          }
        }
      }
      pp = ll;
      ll = -link[ll];
    }
  }
  free(hcode);
  return(1);
}

/* store seed triangle to boundary point */
int seedel_3d(pMesh mesh,pSol sol) {
  Mat    *pm;
  pTetra  pt,pt1;
  int    *adj,k,iv,kk;
  char    i;

  pm = &sol->mat[0];
  for (k=1; k<=mesh->ne; k++) {
    pt  = &mesh->tetra[k];
    adj = &mesh->adja[4*(k-1)+1];
    for (i=0; i<4; i++) {
      iv = pt->v[inxt3[i]];
      if ( !adj[i] ) {
        mesh->point[iv].s = k;
      }
      else {
        kk  = adj[i] / 4;
        pt1 = &mesh->tetra[kk];
        if ( (pt->ref == pm->ref) && (pt->ref != pt1->ref) )
          mesh->point[iv].s = k;
      }
    }
  }
  return(1);
}

static int hashPut(Hash *hash,int a,int b,int *na) {
  hedge  *ph;
  int     j,ia,ib,key;

  ia  = ST_MIN(a,b);
  ib  = ST_MAX(a,b);
  key = (KTA*ia + KTB*ib) % hash->siz;
  ph  = &hash->item[key];

  if ( ph->ia == ia && ph->ib == ib )
    return(ph->k);
  else if ( ph->ia ) {
    while ( ph->nxt && ph->nxt < hash->max ) {
      ph = &hash->item[ph->nxt];
      if ( ph->ia == ia && ph->ib == ib )  return(ph->k);
    }
    /* insert new midpoint */
    *na = *na + 1;
    ph->nxt = hash->nxt;
    ph      = &hash->item[hash->nxt];
    ph->ia  = ia;
    ph->ib  = ib;
    ph->k   = *na;
    ph->nxt = 0;
    ++hash->nxt;
    /* check for overflow */
    if ( hash->nxt >= hash->max ) {
      if ( info.ddebug )  fprintf(stdout,"  ## Memory realloc (edge): %d,%d\n",hash->max,(int)(1.2*hash->max));
      hash->max *= 1.2;
      hash->item  = (hedge*)realloc(hash->item,hash->max*sizeof(hedge));
      assert(hash->item);
      for (j=hash->nxt; j<hash->max; j++)  hash->item[j].nxt = j+1;
    }
    return(ph->k);
  }
  /* insert new midpoint */
  *na = *na + 1;
  ph->ia = ia;
  ph->ib = ib;
  ph->k  = *na;
  ph->nxt= 0;
  return(ph->k);
}

/* store P2 nodes or bubble for P1b */
int hashar_3d(pMesh mesh) {
  pTetra  pt;
  pEdge   pa;
  Hash    hash;
  int     k,im,na;
  char    i,j,ia;

  if ( info.typ == P1P1 )
    return(1);
  else if ( info.typ == P1bP1 ) {
    for (k=1; k<=mesh->ne; k++) {
      pt = &mesh->tetra[k];
      pt->v[4] = mesh->np + k;
    }
    return(1);
  }

  /* adjust hash table params */
  hash.siz  = mesh->np;
  hash.nxt  = mesh->np;
  hash.max  = 4.2*mesh->np + 1;
printf("hmax = %d\n",hash.max);
  hash.item = (hedge*)calloc(hash.max,sizeof(hedge));
  assert(hash.item);
  for (k=hash.siz; k<hash.max; k++)  hash.item[k].nxt = k+1;

  /* loop over tetrahedra */
  mesh->na = 0;
  for (k=1; k<=mesh->ne; k++) {
    pt = &mesh->tetra[k];
    if ( !pt->v[0] )  continue;
    for (ia=0,i=0; i<3; i++) {
      for (j=i+1; j<4; j++,ia++) {
        im = hashPut(&hash,pt->v[i],pt->v[j],&mesh->na);
        pt->v[ia+4] = mesh->np + im;
			}
    }
  }

  /* loop over edges */
  na = 0;
  for (k=1; k<=mesh->nai; k++) {
    pa = &mesh->edge[k];
    im = hashPut(&hash,pa->v[0],pa->v[1],&na);
    pa->v[2] = mesh->np + im;
  }

  free(hash.item);
  return(1);
}

/* store P2 nodes or bubble for P1b */
int hashar_2d(pMesh mesh) {
  pTria   pt;
  pEdge   pa;
  Hash    hash;
  int     k,im,na;
  char    i,i1;

  if ( info.typ == P1P1 )
    return(1);
  else if ( info.typ == P1bP1 ) {
    for (k=1; k<=mesh->nt; k++) {
      pt = &mesh->tria[k];
      pt->v[3] = mesh->np + k;
    }
    return(1);
  }

  /* adjust hash table params */
  hash.siz  = mesh->np;
  hash.nxt  = mesh->np;
  hash.max  = 3.2*mesh->np + 1;
  hash.item = (hedge*)calloc(hash.max,sizeof(hedge));
  assert(hash.item);
  for (k=hash.siz; k<hash.max; k++)  hash.item[k].nxt = k+1;

  /* loop over triangles */
  mesh->na = 0;
  for (k=1; k<=mesh->nt; k++) {
    pt = &mesh->tria[k];
    if ( !pt->v[0] )  continue;
    for (i=0; i<3; i++) {
      i1 = inxt[i];
      im = hashPut(&hash,pt->v[i],pt->v[i1],&mesh->na);
      pt->v[i+3] = mesh->np + im;
    }
  }

  /* loop over edges */
  na = 0;
  for (k=1; k<=mesh->nai; k++) {
    pa = &mesh->edge[k];
    im = hashPut(&hash,pa->v[0],pa->v[1],&na);
    pa->v[2] = mesh->np + im;
  }

  free(hash.item);
  return(1);
} 

