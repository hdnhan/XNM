#ifndef _STOKES_H
#define _STOKES_H

#include <assert.h>
#include <stdlib.h>
#include <stdio.h>
#include <limits.h>
#include <math.h>
#include <string.h>
#include <signal.h>
#include <ctype.h>
#include <float.h>

#include "chrono.h"
#include "libmesh5.h"
#include "sparse.h"

#define ST_VER   "4.1a"
#define ST_REL   "Nov. 17, 2012"
#define ST_CPY   "Copyright (c) LJLL, 2006-2012"
#define ST_STR   "&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&"

#define ST_MAX(a,b) (((a) > (b)) ? (a) : (b))
#define ST_MIN(a,b) (((a) < (b)) ? (a) : (b))

#define ST_EPSA   1.e-200
#define ST_EPSD   1.e-30
#define A_EPSV    1.e-14
#define ST_TGV    1.e+30
#define ST_EPS2   1.e-12
#define ST_EPST   1.e-6
#define ST_EPS    1.e-6
#define ST_RES    1.e-6
#define ST_CVG    1.e-8
#define ST_NURHS  1.e-3
#define ST_PRECI  1.0
#define ST_MAXIT  5000
#define ST_NU     1.
#define ST_RHO    1.
#define ST_CL       50
#define ST_MAT      50
#define ST_LMAX2D  128
#define ST_LMAX3D 1024

#define ST_Ver     (1<<0)
#define ST_Edg     (1<<1)
#define ST_Tri     (1<<2)
#define ST_Tet     (1<<3)
#define ST_SuTe    (1<<4)
#define ST_GRV     (1<<0)
#define ST_BDY     (1<<1)

#define ST_DomInt      3
#define ST_DomExt      2
#define ST_Interface   5

/* boundary conditions, methods, FE types */
enum {Dirichlet=1, Neumann, Tension, Slip, Symmetry};
enum {Mono=0, Uzawa, Penalty, Schur};
enum {P1P1=0, P1bP1, P1P1st, P2P1};

extern unsigned char inxt[3],iprv[3],inxt3[4];

/* mesh structure */
typedef struct {
  double    c[3];
  int       ref,s;
	char      flag;
} Point;
typedef Point * pPoint;

typedef struct {
  int       v[3],ref;
} Edge;
typedef Edge * pEdge;
  
typedef struct {
  int       v[6],ref,mark;
} Tria;
typedef Tria * pTria;

typedef struct {
  int       v[10],ref,mark;
} Tetra;
typedef Tetra * pTetra;

typedef struct {
  double   delta,hmin,min[3],max[3],gr[3],dt,step,maxtim;
	int      nit,sav;
  char     imprim,ddebug,load,rhs,ns,typ,ncpu,solver;
  mytime   ctim[TIMEMAX];
} Info;

typedef struct {
  int       np,na,nai,nt,nti,ne,ver,dim,mark;
  int      *adja;
  char     *name;
  pPoint    point;
  pEdge     edge;
  pTria     tria;
  pTetra    tetra;
} Mesh;
typedef Mesh * pMesh;

/* for solution */
typedef struct {
  double   u[3];
  int      ref;
  char     typ,elt,att;
} Cl;
typedef Cl * pCl;

typedef struct {
  double  nu,rho;
  int     ref;
} Mat;
typedef Mat * pMat;

typedef struct {
  int       dim,ver,np,na,ne,nit,iter,nbcl,nmat;
  double   *u,*p,*bc,*u0,*p0,err,time;
  char     *namein,*nameout,*data,cltyp;
  pCl       cl;
  pMat      mat;
} Sol;
typedef Sol * pSol;

typedef struct {
  double   n[2],kappa,kappb,len;
} Deriv;
typedef Deriv  * pDeriv;

typedef struct {
  int   ia,ib,k,nxt;
} hedge;

typedef struct {
  int     siz,max,nxt;
  hedge  *item;
} Hash;

/* prototypes */
double area_2d(double *a,double *b,double *c);
double volu_3d(double *a,double *b,double *c,double *d);
double kappa_2d(pMesh mesh,int ip,double *n,double *len);
int  invmatg(double m[9],double mi[9]);
int  loadMesh(pMesh );
int  loadSol(pSol );
int  loadBC(pSol );
int  saveSol(pSol );
int  saveIt(pSol sol,int it);
int  saveVor(pSol );
int  ghiaProf(pMesh mesh,pSol sol);
int  scaleMesh(pMesh ,pSol );
int  unscaleMesh(pSol );
int  hashel_2d(pMesh mesh);
int  hashel_3d(pMesh mesh);
pCl  getCl(pSol ,int ,int );
int  getMat(pSol ,int ,double *,double *);
int  ST_Uzawa(pMesh mesh,pSol sol,pCsr A,pCsr B,pCsr S,double *F,double *er,int *ni);
int  ST_Penalty(pMesh mesh,pSol sol,pCsr A,pCsr B,double *F,double *er,int *ni);
int  ST_Schur(pSol sol,pCsr A,pCsr B,double *F,double *er,int *ni);

/* dim: function pointers */
int  hashel_2d(pMesh mesh);
int  hashel_3d(pMesh mesh);
int  hashar_2d(pMesh mesh);
int  hashar_3d(pMesh mesh);
int  seedel_2d(pMesh mesh,pSol sol);
int  seedel_3d(pMesh mesh,pSol sol);
void rhside_2d(pMesh mesh,pSol sol,double *F);
void rhside_3d(pMesh mesh,pSol sol,double *F);
void rhsTGV_2d(pMesh mesh,pSol sol,double *F);
void rhsTGV_3d(pMesh mesh,pSol sol,double *F);
void rhsupd_2d(pMesh mesh,pSol sol, double *Fk);
void rhsupd_3d(pMesh mesh,pSol sol,double *Fk);
void matAB_2d(pMesh mesh,pSol sol,pCsr A,pCsr B);
void matAB_3d(pMesh mesh,pSol sol,pCsr A,pCsr B);
void matM_2d(pMesh mesh,pSol sol,pCsr A,pCsr B);
void matM_3d(pMesh mesh,pSol sol,pCsr A,pCsr B);
void updbub_2d(pMesh mesh,double *u);
void updbub_3d(pMesh mesh,double *u);
int  advectRK4_P1_2d(pMesh mesh,pSol sol);
int  advectRK4_P2_2d(pMesh mesh,pSol sol);
int  advectRK41_P2_2d(pMesh mesh,pSol sol);
int  advectRK4_P1_3d(pMesh mesh,pSol sol);
int  advectRK4_P2_3d(pMesh mesh,pSol sol);
int  normal_2d(pMesh mesh,int ip,int ref,double *n);
void errors_2d(pMesh mesh,int size,double *u1,double *u2,double *eli,double *el1,double *el2);
void errors_3d(pMesh mesh,int size,double *u1,double *u2,double *eli,double *el1,double *el2);
int  boulep_2d(pMesh mesh,int start,int ip,int *list,char *open);
void taylorgreen(pPoint ,double *,double );

/* function pointers */
int  (*hashel)(pMesh );
int  (*seedel)(pMesh ,pSol );
int  (*hashar)(pMesh mesh);
void (*rhside)(pMesh mesh,pSol sol,double *F);
void (*rhsTGV)(pMesh mesh,pSol sol,double *F);
void (*rhsupd)(pMesh mesh,pSol sol,double *Fk);
void (*assmat)(pMesh mesh,pSol sol,pCsr A,pCsr B);
void (*updbub)(pMesh mesh,double *u);
int  (*advect)(pMesh mesh,pSol sol);
void (*stokesCL)(pPoint ,double *,double );

#endif


