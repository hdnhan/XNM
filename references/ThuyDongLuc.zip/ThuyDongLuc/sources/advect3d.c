#include "stokes.h"

extern Info  info;

unsigned char inxt3[4] = {1,2,3,0};

static double det_3d(double *cp0,double *cp1,double *cp2,double *cp3) {
  double  det,x01,x02,x03,y01,y02,y03,z01,z02,z03; 

  x01 = cp1[0] - cp0[0];  y01 = cp1[1] - cp0[1];  z01 = cp1[2] - cp0[2];
  x02 = cp2[0] - cp0[0];  y02 = cp2[1] - cp0[1];  z02 = cp2[2] - cp0[2];
  x03 = cp3[0] - cp0[0];  y03 = cp3[1] - cp0[1];  z03 = cp3[2] - cp0[2];

  det = x01*(y02*z03-y03*z02) + y01*(z02*x03-z03*x02) + z01*(x02*y03-x03*y02);
  return(det);  
}

/* barycentric coordinates of point c[] in iel=p0,p1,p2 */
static inline int bar_3d(pPoint pp[4],double *c,int iel,double *cb) {
  double    det,cp0[3],cp1[3],cp2[3],cp3[3];
  char      i;

  for (i=0; i<3; i++) {
    cp0[i] = pp[0]->c[i];
    cp1[i] = pp[1]->c[i];
    cp2[i] = pp[2]->c[i];
    cp3[i] = pp[3]->c[i];
  }
  det = det_3d(cp0,cp1,cp2,cp3);
  if ( fabs(det) < ST_EPSA )  return(0);
  det = 1.0 / det;

  /* barycentric coordinate */
  cb[0] =  det_3d(c,cp1,cp2,cp3) * det;
  cb[1] = -det_3d(c,cp2,cp3,cp0) * det;
  cb[2] =  det_3d(c,cp3,cp0,cp1) * det;
  cb[3] = 1.0 - cb[0] - cb[1] - cb[2];
  return(1);
}

/* return velocity interpolation in v in element iv[3] */
static double vecint_3d(pSol sol,int *iv,double *cb,double *v) {
  double   *u0,*u1,*u2,*u3,dd;

  u0 = &sol->u[3*(iv[0]-1)];
  u1 = &sol->u[3*(iv[1]-1)];
  u2 = &sol->u[3*(iv[2]-1)];
  u3 = &sol->u[3*(iv[3]-1)];

  /* P1 interpolate of the speed */   
  v[0] = cb[0]*u0[0] + cb[1]*u1[0] + cb[2]*u2[0] + cb[3]*u3[0];
  v[1] = cb[0]*u0[1] + cb[1]*u1[1] + cb[2]*u2[1] + cb[3]*u3[1];
  v[2] = cb[0]*u0[2] + cb[1]*u1[2] + cb[2]*u2[2] + cb[3]*u3[2];

  dd = sqrt(v[0]*v[0] + v[1]*v[1] + v[2]*v[2]);
  return(dd);
}

/* find element containing c, starting from nsdep, return baryc. coord */
static int locelt_3d(pMesh mesh,int nsdep,double *c,double *cb) {
  pTetra   pt;
  pPoint   p0,p1,p2,p3;
  double   bx,by,bz,cx,cy,cz,dx,dy,dz,vx,vy,vz,apx,apy,apz;
  double   eps,vol1,vol2,vol3,vol4,dd; 
  int     *adj,iadr,it,nsfin,nsprv,base;
  char     i;

	for (i=0; i<mesh->dim; i++) {
    if ( c[i] < -ST_EPST*info.delta )
			return(-1);
	  else if ( c[i] < 0.0 )
			c[i] = 0.0;
	  if ( c[i] > info.max[i]+ST_EPST*info.delta )
		  return(-1);
		else if ( c[i] > info.max[i] )
			c[i] = info.max[i];
	}

  it    = 0;
  nsfin = nsdep;
  nsprv = 0;
  base  = ++mesh->mark;
  do {
    pt = &mesh->tetra[nsfin];
    if ( !pt->v[0] || (it > 0 && nsfin == nsdep) )  return(nsprv);
    if ( pt->mark == base )  break;
    pt->mark = base;
    iadr = 4*(nsfin-1)+1;
    adj  = &mesh->adja[iadr];

    /* measure of element */
    p0 = &mesh->point[pt->v[0]];
    p1 = &mesh->point[pt->v[1]];
    p2 = &mesh->point[pt->v[2]];
    p3 = &mesh->point[pt->v[3]];

    /* barycentric and volume */
    bx  = p1->c[0] - p0->c[0];
    by  = p1->c[1] - p0->c[1];
    bz  = p1->c[2] - p0->c[2];
    cx  = p2->c[0] - p0->c[0];
    cy  = p2->c[1] - p0->c[1];
    cz  = p2->c[2] - p0->c[2];
    dx  = p3->c[0] - p0->c[0];
    dy  = p3->c[1] - p0->c[1];
    dz  = p3->c[2] - p0->c[2];

    /* test volume */
    vx  = cy*dz - cz*dy;
    vy  = cz*dx - cx*dz;
    vz  = cx*dy - cy*dx;
		dd  = bx*vx + by*vy + bz*vz;
    //epsra = EPST*(bx*vx + by*vy + bz*vz);
		eps = ST_EPST*dd;

    /* barycentric */
    apx = c[0] - p0->c[0];
    apy = c[1] - p0->c[1];
    apz = c[2] - p0->c[2];

    /* p in 2 */
    vol2  = apx*vx + apy*vy + apz*vz;
    if ( vol2 < eps ) {
      nsprv = nsfin;
      nsfin = adj[1] / 4;
      continue;
    }
    /* p in 3 */
    vx  = by*apz - bz*apy;
    vy  = bz*apx - bx*apz;
    vz  = bx*apy - by*apx;
    vol3 = dx*vx + dy*vy + dz*vz;
    if ( vol3 < eps ) {
			nsprv = nsfin;
      nsfin = adj[2] / 4;
      continue;
    }
    /* p in 4 */
    vol4 = -cx*vx - cy*vy - cz*vz;
    if ( vol4 < eps ) {
			nsprv = nsfin;
      nsfin = adj[3] / 4;
      continue;
    }
    /* p in 1 */
    vol1 = dd - vol2 - vol3 - vol4;
    if ( vol1 < eps ) {
			nsprv = nsfin;
      nsfin = adj[0] / 4;
      continue;
    }

    dd = vol1+vol2+vol3+vol4;
    if ( fabs(dd) > ST_EPSA ) {
	    dd = 1.0 / dd;
      cb[0] = fabs(vol1) * dd;
      cb[1] = fabs(vol2) * dd;
      cb[2] = fabs(vol3) * dd;
      cb[3] = fabs(vol4) * dd;
    }
    return(nsfin);
  }
  while ( nsfin && ++it <= mesh->ne );

  /* no need for exhaustive search */
  return(nsprv);
}

/* computes the characteristic line emerging from point with barycentric coordinates cb
 in triangle iel and follows the characteristic on a length dt at most. Most often has to 
 cross the boundary of the current triangle, thus stores in it the new triangle, in cb
 the barycentric coordinates in the new triangle of the crossing point, and updates dt 
 with the remaining time to follow characteristic line */
static int travel_3d(pMesh mesh,pSol sol,double *cb,int *iel,double *dt) {
  pTetra        pt;
  pPoint        p[4];
  double        m[4],ddt,tol,ux,uy,uz,c[3],cb1[4],cbold[4];
  double       *u0,*u1,*u2,*u3;
  unsigned char i,i0,i1,i2,i3;
  int           k,kprv,*adj;

  if ( *dt < ST_EPS * info.step )  return(0);
  tol  = ST_MIN(0.1*info.step,*dt);
  k    = *iel;
	kprv = *iel;
  pt   = &mesh->tetra[k];
  
  p[0] = &mesh->point[pt->v[0]];
  p[1] = &mesh->point[pt->v[1]];
  p[2] = &mesh->point[pt->v[2]];
  p[3] = &mesh->point[pt->v[3]];
  
  /* the speed at each vertex of iel */
  u0 = &sol->u[3*(pt->v[0]-1)+1];
  u1 = &sol->u[3*(pt->v[1]-1)+1];
  u2 = &sol->u[3*(pt->v[2]-1)+1];
  u3 = &sol->u[3*(pt->v[3]-1)+1];
  
  /* u = P1 velocity at the point of barycentric coordinates cb */
  ux = cb[0]*u0[0] + cb[1]*u1[0] + cb[2]*u2[0] + cb[3]*u3[0];
  uy = cb[0]*u0[1] + cb[1]*u1[1] + cb[2]*u2[1] + cb[3]*u3[1];
  uz = cb[0]*u0[2] + cb[1]*u1[2] + cb[2]*u2[2] + cb[3]*u3[2];  
  if ( ux*ux+uy*uy+uz*uz < ST_EPSD )  return(0);
  
  /* endpoint of the characteristic line starting from cb */
  /* segment is of norm sqrt(ux*ux+uy*uy+uz*uz), and is to be followed for time dt, in the - direction */ 
  c[0] = (cb[0]*p[0]->c[0] + cb[1]*p[1]->c[0] + cb[2]*p[2]->c[0] + cb[3]*p[3]->c[0]) - ux;
  c[1] = (cb[0]*p[0]->c[1] + cb[1]*p[1]->c[1] + cb[2]*p[2]->c[1] + cb[3]*p[3]->c[1]) - uy;
  c[2] = (cb[0]*p[0]->c[2] + cb[1]*p[1]->c[2] + cb[2]*p[2]->c[2] + cb[3]*p[3]->c[2]) - uz;

  /* barycentric coordinate of uu in the current tetra */
  if ( !bar_3d(p,c,k,cb1) )  return(0);

  /* ddt = least value of cb[i]/m[i] = (weighted) distance to lambda_i0 = 0 */
  /* ddt = interval of time elapsed before going out of the current element */
  /* condition m[i] > 0 ensures going out of element in "marching direction"*/  
  ddt = ST_TGV;
  i0  = -1;
  for (i=0; i<4; i++) {
    m[i] = cb[i] - cb1[i];
    if ( m[i] > 0.0 ) {
      if ( cb[i]/m[i] < ddt ) {
        ddt = cb[i]/m[i];
        i0  = i;
      } 
    }
  }

  /* incomplete advection remain in element */
  if ( ddt >= tol ) {
    for (i=0; i<4; i++)  cb[i] = cb[i] - tol*m[i];
    *dt -= tol;
  }
  /* advection goes out of element */  
  else {
    /* advect a minimum value */
    if ( ddt < ST_EPS*tol ) {
      c[0] = cb[0]*p[0]->c[0] + cb[1]*p[1]->c[0] + cb[2]*p[2]->c[0] - ST_EPS*ux;
      c[1] = cb[0]*p[0]->c[1] + cb[1]*p[1]->c[1] + cb[2]*p[2]->c[1] - ST_EPS*uy;
      c[2] = cb[0]*p[0]->c[2] + cb[1]*p[1]->c[2] + cb[2]*p[2]->c[2] - ST_EPS*uz;
      /* find the new element */
			memcpy(cbold,cb,4*sizeof(double));
      k = locelt_3d(mesh,k,c,cb); 
      if ( k < 1 ) {
      	*iel = kprv;
				memcpy(cb,cbold,4*sizeof(double)); 
        return(0);
			}
			else {
        *iel = k;
        *dt -= ST_EPS;
			}
    }
    else {
      i1 = inxt3[i0];
      i2 = inxt3[i1];
      i3 = inxt3[i2];

      /* barycentric coordinates of the exit point */ 
      cb1[i0] = 0;
      cb1[i1] = cb[i1] - ddt * m[i1];
      cb1[i2] = cb[i2] - ddt * m[i2];
      cb1[i3] = 1.0 - cb1[i1] - cb1[i2];
      if ( cb1[i1] < ST_EPS2 ) {
	      cb1[i2] -= (ST_EPS2-cb1[i1]) / 2;
        cb1[i3] -= (ST_EPS2-cb1[i1]) / 2;
        cb1[i1]  =  ST_EPS2;
      }
      else if ( cb1[i1] > 1.0-ST_EPS2 ) {
	      cb1[i2] += (cb1[i1]-1.0+ST_EPS2) / 2;
        cb1[i3] += (cb1[i1]-1.0+ST_EPS2) / 2;
        cb1[i1]  = 1.0-ST_EPS2;
      }
      if ( cb1[i2] < ST_EPS2 ) {
	      cb1[i3] -= (ST_EPS2-cb1[i2]) / 2;
        cb1[i1] -= (ST_EPS2-cb1[i2]) / 2;
        cb1[i2]  = ST_EPS2;
      }
      else if ( cb1[i2] > 1.0-ST_EPS2 ) {
	      cb1[i3] += (cb1[i2]-1.0+ST_EPS2) / 2;
        cb1[i1] += (cb1[i2]-1.0+ST_EPS2) / 2;
        cb1[i2]  = 1.0-ST_EPS2;
      }
      *dt -= ddt;

      /* coordinates of the point of barycentric coordinates cb1 */
      c[0] = cb1[0]*p[0]->c[0] + cb1[1]*p[1]->c[0] + cb1[2]*p[2]->c[0] + cb1[3]*p[3]->c[0];
      c[1] = cb1[0]*p[0]->c[1] + cb1[1]*p[1]->c[1] + cb1[2]*p[2]->c[1] + cb1[3]*p[3]->c[1];
      c[2] = cb1[0]*p[0]->c[2] + cb1[1]*p[1]->c[2] + cb1[2]*p[2]->c[2] + cb1[3]*p[3]->c[2];

      adj = &mesh->adja[4*(k-1) + 1];
      if ( !adj[i0] ) {
        memcpy(cb,cb1,4*sizeof(double));
        return(0);
      }
      else {
        *iel = adj[i0] / 4;
        if ( !bar_3d(p,c,*iel,cb) )  return(0);
      }
    }
  }
  return(*dt > 0.0);
}

/* 4th order Runge-Kutta: for backtracking characteristic line, step is <0 */ 
/* v = initial speed at point c */
static int nxtpt_3d(pMesh mesh,pSol sol,int *iel,double *c,double *cb,double step,double *v) {
  double  h6,v1[3],v2[3],v3[3];
  double  xp1[3],xp2[3],xp3[3],cc[3];
  int     k;

  k = *iel;
  xp1[0] = c[0] - 0.5*step*v[0];
  xp1[1] = c[1] - 0.5*step*v[1];
  xp1[2] = c[2] - 0.5*step*v[2];
  ++mesh->mark;
  k = locelt_3d(mesh,k,xp1,cb);
  if ( k < 1 )   return(k);
  vecint_3d(sol,mesh->tetra[k].v,cb,v1);

  xp2[0] = c[0] - 0.5*step*v1[0];
  xp2[1] = c[1] - 0.5*step*v1[1];
  xp2[2] = c[2] - 0.5*step*v1[2];
  ++mesh->mark;
  k = locelt_3d(mesh,k,xp2,cb);
  if ( k < 1 )   return(k);
  vecint_3d(sol,mesh->tetra[k].v,cb,v2);

  xp3[0] = c[0] - step*v2[0];
  xp3[1] = c[1] - step*v2[1];
  xp3[2] = c[2] - step*v2[2];
  ++mesh->mark;
  k = locelt_3d(mesh,k,xp3,cb);
  if ( k < 1 )   return(k);
  vecint_3d(sol,mesh->tetra[k].v,cb,v3);

  /* final RK4 step */  
  h6 = step / 6.0;
  cc[0] = c[0] - h6 * (v[0] + 2*(v1[0] + v2[0]) + v3[0]);
  cc[1] = c[1] - h6 * (v[1] + 2*(v1[1] + v2[1]) + v3[1]);
  cc[2] = c[2] - h6 * (v[2] + 2*(v1[2] + v2[2]) + v3[2]);
  ++mesh->mark;
  k = locelt_3d(mesh,k,cc,cb);
  if ( k < 1 )   return(k);
  
  /* update */
  c[0] = cc[0];
  c[1] = cc[1];
  c[2] = cc[2];
  vecint_3d(sol,mesh->tetra[k].v,cb,v);

  *iel = k;
  return(1);
}

/*Euler method for backtracking characteristic line*/
/* v = initial speed at point c */
static int nxtpt1_3d(pMesh mesh,pSol sol,int *iel,double *c,double *cb,double step,double *v) {
  double  h6,v1[3],v2[3],v3[3];
  double  xp1[3],xp2[3],xp3[3],cc[3];
  int     k;

  k = *iel;
  cc[0] = c[0] - step * v[0];
  cc[1] = c[1] - step * v[1];
  cc[2] = c[2] - step * v[2];
  ++mesh->mark;
  k = locelt_3d(mesh,k,cc,cb);
  if ( k < 1 )   return(k);
  
  /* update */
  c[0] = cc[0];
  c[1] = cc[1];
  c[2] = cc[2];
  vecint_3d(sol,mesh->tetra[k].v,cb,v);

  *iel = k;
  return(1);
}


int advectRK4_P2_3d(pMesh mesh,pSol sol) {
  return(1);
}

/* advect P1 solution u0, result in u */
int advectRK4_P1_3d(pMesh mesh,pSol sol) {
  pTetra   pt,pt1;	
  pPoint   ppt;
  double  *u0,*u1,*u2,*u3,cb[4],v[3],c[3],dt,dte,norm,tol,step;	
  int      j,k,ip,iel,kprv,nstep;
	char     i;

  dt    = info.dt;
  tol   = info.step;
  nstep = (int)(dt / tol);
  step  = dt / nstep;
  
  /* reset field */
  for (k=1; k<=mesh->np; k++)  mesh->point[k].flag = 0;

  ++mesh->mark;
	for (k=1; k<=mesh->ne; k++) {
		pt = &mesh->tetra[k];  
		if ( !pt->v[0] )  continue;

		for (i=0; i<4; i++) {
      ip  = pt->v[i];
      ppt = &mesh->point[ip];
      if ( ppt->flag )  continue;   
      ppt->flag = 1;
      kprv = k;

      /* coordinate and velocity at starting point */
      v[0] = sol->u0[3*(ip-1)+0];
      v[1] = sol->u0[3*(ip-1)+1];
      v[2] = sol->u0[3*(ip-1)+2];
      norm = sqrt(v[0]*v[0] + v[1]*v[1] + v[2]*v[2]);
      if ( norm < ST_EPSD ) {
      	sol->u[3*(ip-1)+0] = sol->u0[3*(ip-1)+0];
      	sol->u[3*(ip-1)+1] = sol->u0[3*(ip-1)+1];
      	sol->u[3*(ip-1)+2] = sol->u0[3*(ip-1)+2];
        continue;
      }
			/* barycentric coordinates of point p in element k */
      memset(cb,0,4*sizeof(double));
			cb[i] = 1.0;
				
      /* next point = foot of the characteristic line */
      c[0] = ppt->c[0];
      c[1] = ppt->c[1];
			c[2] = ppt->c[2];
      dte  = dt;
      for (iel=k,j=0; j<nstep; j++) {
        kprv = iel;
        if ( nxtpt1_3d(mesh,sol,&iel,c,cb,step,v) < 1 )  break;
        //if ( nxtpt_3d(mesh,sol,&iel,c,cb,step,v) < 1 )  break;
        dte -= step;
      }
      if ( j < nstep ) {
        if ( !iel )  iel = kprv;
        while ( travel_3d(mesh,sol,cb,&iel,&dte) );
      }

      /* interpolate value at foot  */
			assert(iel>0);
      pt1 = &mesh->tetra[iel];
      assert(pt1->v[0]);
      u0 = &sol->u0[3*(pt1->v[0]-1)];
      u1 = &sol->u0[3*(pt1->v[1]-1)];
      u2 = &sol->u0[3*(pt1->v[2]-1)];
			u3 = &sol->u0[3*(pt1->v[3]-1)];
      sol->u[3*(ip-1)+0] = cb[0]*u0[0] + cb[1]*u1[0] + cb[2]*u2[0] + cb[3]*u3[0];
      sol->u[3*(ip-1)+1] = cb[0]*u0[1] + cb[1]*u1[1] + cb[2]*u2[1] + cb[3]*u3[1];
      sol->u[3*(ip-1)+2] = cb[0]*u0[2] + cb[1]*u1[2] + cb[2]*u2[2] + cb[3]*u3[2];
		}
	}
	return(1);
}

/*
int ghiaProf(pMesh mesh,pSol sol) {
  FILE   *out;
  double  dd,xp[3],cb[4],v[3];
  int     k,iel,nbp;
  char   *ptr,data[128],xout[128],yout[128];

  if ( sol->dim != 3 )  return(0);

  //for (k=1; k<=mesh->np; k++)  mesh->point[k].flag = 0;
  //++mesh->mark;

  strcpy(data,sol->nameout);
  ptr = strstr(data,".mesh");
  if ( ptr )  *ptr = '\0';
  ptr = strstr(data,".sol");
  if ( ptr )  *ptr = '\0';
  sprintf(xout,"%s.yprof.m%1d.t%1d_dt%.2f",data,info.solver,info.typ,info.dt);

  nbp   = 57;
  sol->u0 = sol->u;


  //y component of velocity

  out = fopen(xout,"w");
  if ( !out )  return(0);
  xp[0] = 0.5;
  xp[1] = 0.5;
	xp[2] = 0.0;
  dd  = (info.max[1] - info.min[1]) / (double)nbp;
  fprintf(out,"%f %f\n",xp[2],0.0);
  iel = 1;
  for (k=1; k<nbp; k++) {
    xp[2] += dd;
    iel = locelt_3d(mesh,iel,xp,cb);
    if ( iel > 0 ) {
      vecint_3d(sol,mesh->tetra[iel].v,cb,v);
      fprintf(out,"%f %f\n",xp[2],v[1]);
    }
  }
  fprintf(out,"%f %f\n",1.0,1.0);
  fclose(out);


  // z component of velocity

	sprintf(yout,"%s.zprof.m%1d.t%1d_dt%.2f",data,info.solver,info.typ,info.dt);
  out = fopen(yout,"w");
  if ( !out )  return(0);

  xp[0] = 0.5;
  xp[1] = 0.0;
  xp[2] = 0.5;
  dd    = (info.max[1] - info.min[1]) / (double)nbp;
  fprintf(out,"%f %f\n",xp[1],0.0);
  iel = 1;
  for (k=1; k<nbp; k++) {
    xp[1] += dd;
    iel = locelt_3d(mesh,iel,xp,cb);
    if ( iel > 0 ) {
      vecint_3d(sol,mesh->tetra[iel].v,cb,v);
      fprintf(out,"%f %f\n",xp[1],v[2]);
    }
  }
  fprintf(out,"%f %f\n",1.0,0.0);
  fclose(out);
  return(1);
}
*/

